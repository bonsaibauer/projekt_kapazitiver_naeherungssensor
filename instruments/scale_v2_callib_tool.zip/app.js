"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
// Websocket based client for koheron-server...
// (c) Koheron
var Driver = /** @class */ (function () {
    function Driver(name, id, cmds) {
        this.name = name;
        this.id = id;
        this.cmds = cmds;
    }
    Driver.prototype.getCmdRef = function (cmdName) {
        for (var _i = 0, _a = this.cmds; _i < _a.length; _i++) {
            var cmd = _a[_i];
            if (cmdName === cmd.name) {
                return cmd.id;
            }
        }
        throw new ReferenceError(cmdName + ': command not found');
    };
    Driver.prototype.getCmds = function () {
        var cmdsDict = {};
        for (var _i = 0, _a = this.cmds; _i < _a.length; _i++) {
            var cmd = _a[_i];
            cmdsDict[cmd.name] = cmd;
        }
        return cmdsDict;
    };
    return Driver;
}());
var WebSocketPool = /** @class */ (function () {
    function WebSocketPool(poolSize, url, onOpenCallback) {
        var _this = this;
        this.poolSize = poolSize;
        this.url = url;
        this.onOpenCallback = onOpenCallback;
        this.poolSize = poolSize;
        this.url = url;
        this.pool = [];
        this.freeSockets = [];
        this.dedicatedSockets = [];
        this.socketCounter = 0;
        this.exiting = false;
        for (var i = 0, end = this.poolSize - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            var websocket = this._newWebSocket();
            this.pool.push(websocket);
            websocket.onopen = function (evt) {
                return _this.waitForConnection(websocket, 100, function () {
                    console.assert(websocket.readyState === 1, 'Websocket not ready');
                    _this.freeSockets.push(_this.socketCounter);
                    if (_this.socketCounter === 0) {
                        onOpenCallback();
                    }
                    websocket.ID = _this.socketCounter;
                    websocket.onclose = function (evt) {
                        setTimeout(function () { location.reload(); }, 1000);
                    };
                    websocket.onerror = function (evt) {
                        console.error("error: ".concat(evt.data, "\n"));
                        return websocket.close();
                    };
                    return _this.socketCounter++;
                });
            };
        }
    }
    WebSocketPool.prototype._newWebSocket = function () {
        var websocket;
        if (typeof window !== 'undefined' && window !== null) {
            websocket = new WebSocket(this.url);
        }
        else { // Node
            var clientConfig = {};
            clientConfig.fragmentOutgoingMessages = false;
            var __WebSocket = require('websocket').w3cwebsocket;
            websocket = new __WebSocket(this.url, null, null, null, null, clientConfig);
        }
        websocket.binaryType = 'arraybuffer';
        return websocket;
    };
    WebSocketPool.prototype.waitForConnection = function (websocket, interval, callback) {
        var _this = this;
        if (websocket.readyState === 1) {
            // If the client has been set to exit while establishing the connection
            // we don't initialize the socket
            if (this.exiting) {
                return;
            }
            return callback();
        }
        else {
            return setTimeout(function () {
                return _this.waitForConnection(websocket, interval, callback);
            }, interval);
        }
    };
    WebSocketPool.prototype.getSocket = function (sockid) {
        if (this.exiting) {
            return null;
        }
        if (!(this.freeSockets.some(function (x) { return x == sockid; })) && (sockid >= 0) && (sockid < this.poolSize)) {
            return this.pool[sockid];
        }
        else {
            throw new ReferenceError("Socket ID ".concat(sockid.toString(), " not available"));
        }
    };
    // Obtain a socket for a dedicated task.
    // This function is provided for long term use.
    // A new socket is opened and returned to the caller.
    // This socket is not shared and can be used for a
    // dedicated task.
    // TODO: Caller close dedicated socket
    WebSocketPool.prototype.getDedicatedSocket = function (callback) {
        var _this = this;
        var websocket = this._newWebSocket();
        this.dedicatedSockets.push(websocket);
        return websocket.onopen = function (evt) {
            return _this.waitForConnection(websocket, 100, function () {
                console.assert(websocket.readyState === 1, 'Websocket not ready');
                websocket.onclose = function (evt) {
                    var idx = _this.dedicatedSockets.indexOf(websocket);
                    if (idx > -1) {
                        return _this.dedicatedSockets.splice(idx, 1);
                    }
                };
                websocket.onerror = function (evt) {
                    console.error("error: ".concat(evt.data, "\n"));
                    return websocket.close();
                };
                return callback(websocket);
            });
        };
    };
    // Retrieve a socket from the pool.
    // This function is provided for short term socket use
    // and the socket must be given back to the pool by
    // calling freeeSocket.
    WebSocketPool.prototype.requestSocket = function (callback) {
        var _this = this;
        if (this.exiting) {
            callback(-1);
            return;
        }
        if ((this.freeSockets != null) && (this.freeSockets.length > 0)) {
            var sockid_1 = this.freeSockets[this.freeSockets.length - 1];
            this.freeSockets.pop();
            return this.waitForConnection(this.pool[sockid_1], 100, function () {
                console.assert(_this.pool[sockid_1].readyState === 1, 'Websocket not ready');
                return callback(sockid_1);
            });
        }
        else { // All sockets are busy. We wait a bit and retry.
            console.assert(this.freeSockets.length === 0, 'Non empty freeSockets');
            return setTimeout(function () {
                return _this.requestSocket(callback);
            }, 100);
        }
    };
    // Give back a socket to the pool
    WebSocketPool.prototype.freeSocket = function (sockid) {
        if (this.exiting) {
            return;
        }
        if (!(this.freeSockets.some(function (x) { return x == sockid; })) && (sockid >= 0) && (sockid < this.poolSize)) {
            return this.freeSockets.push(sockid);
        }
        else {
            if (sockid != null) {
                return console.error("Invalid Socket ID ".concat(sockid.toString()));
            }
            else {
                return console.error('Undefined Socket ID');
            }
        }
    };
    WebSocketPool.prototype.exit = function () {
        this.exiting = true;
        this.freeSockets = [];
        this.socketCounter = 0;
        for (var _i = 0, _a = this.pool; _i < _a.length; _i++) {
            var websocket = _a[_i];
            websocket.close();
        }
        return this.dedicatedSockets.map(function (socket) {
            return socket.close();
        });
    };
    return WebSocketPool;
}());
// === Helper functions to build binary buffer ===
var appendInt8 = function (buffer, value) {
    buffer.push(value & 0xff);
    return 1;
};
var appendUint8 = function (buffer, value) {
    buffer.push(value & 0xff);
    return 1;
};
var appendInt16 = function (buffer, value) {
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 2;
};
var appendUint16 = function (buffer, value) {
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 2;
};
var appendInt32 = function (buffer, value) {
    buffer.push((value >> 24) & 0xff);
    buffer.push((value >> 16) & 0xff);
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 4;
};
var appendUint32 = function (buffer, value) {
    buffer.push((value >> 24) & 0xff);
    buffer.push((value >> 16) & 0xff);
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 4;
};
var floatToBytes = function (f) {
    var buf = new ArrayBuffer(4);
    (new Float32Array(buf))[0] = f;
    return (new Uint32Array(buf))[0];
};
var bytesTofloat = function (bytes) {
    var buffer = new ArrayBuffer(4);
    (new Uint32Array(buffer))[0] = bytes;
    return new Float32Array(buffer)[0];
};
var appendFloat32 = function (buffer, value) { return appendUint32(buffer, floatToBytes(value)); };
var appendFloat64 = function (buffer, value) {
    var buf = new ArrayBuffer(8);
    (new Float64Array(buf))[0] = value;
    appendUint32(buffer, (new Uint32Array(buf, 4))[0]);
    appendUint32(buffer, (new Uint32Array(buf, 0))[0]);
    console.assert(buf.byteLength === 8, 'Invalid float64 size');
    return buf.byteLength;
};
var appendArray = function (buffer, array) {
    var bytes = new Uint8Array(array.buffer);
    return bytes.map(function (_byte) { return buffer.push(_byte); });
};
var appendVector = function (buffer, array) {
    appendUint32(buffer, array.buffer.byteLength);
    var bytes = new Uint8Array(array.buffer);
    return bytes.map(function (_byte) { return buffer.push(_byte); });
};
var appendString = function (buffer, str) {
    appendUint32(buffer, str.length);
    for (var i = 0; i < str.length; i++) {
        buffer.push(str.charCodeAt(i));
    }
};
var isStdArray = function (type) { return type.split('<')[0].trim() === 'std::array'; };
var isStdVector = function (type) { return type.split('<')[0].trim() === 'std::vector'; };
var isStdString = function (type) { return type.trim() === 'std::string'; };
var isStdTuple = function (type) { return type.split('<')[0].trim() === 'std::tuple'; };
var getStdVectorType = function (type) { return type.split('<')[1].split('>')[0].trim(); };
function Command(devId, cmd) {
    var params = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        params[_i - 2] = arguments[_i];
    }
    var buffer = [];
    appendUint32(buffer, 0); // RESERVED
    appendUint16(buffer, devId);
    appendUint16(buffer, cmd.id);
    if (cmd.args.length === 0) {
        return {
            devid: devId,
            cmd: cmd,
            data: new Uint8Array(buffer)
        };
    }
    if (cmd.args.length !== params.length) {
        throw new Error("Invalid number of arguments. Expected ".concat(cmd.args.length, " receive ").concat(params.length, "."));
    }
    var buildPayload = function (args, params) {
        if (args == null) {
            args = [];
        }
        var payload = [];
        for (var i = 0; i < args.length; i++) {
            var arg = args[i];
            switch (arg.type) {
                case 'uint8_t':
                    appendUint8(payload, params[i]);
                    break;
                case 'int8_t':
                    appendInt8(payload, params[i]);
                    break;
                case 'uint16_t':
                    appendUint16(payload, params[i]);
                    break;
                case 'int16_t':
                    appendInt16(payload, params[i]);
                    break;
                case 'uint32_t':
                    appendUint32(payload, params[i]);
                    break;
                case 'int32_t':
                    appendInt32(payload, params[i]);
                    break;
                case 'float':
                    appendFloat32(payload, params[i]);
                    break;
                case 'double':
                    appendFloat64(payload, params[i]);
                    break;
                case 'bool':
                    if (params[i]) {
                        appendUint8(payload, 1);
                    }
                    else {
                        appendUint8(payload, 0);
                    }
                    break;
                default:
                    if (isStdArray(arg.type)) {
                        appendArray(payload, params[i]);
                    }
                    else if (isStdVector(arg.type)) {
                        appendVector(payload, params[i]);
                    }
                    else if (isStdString(arg.type)) {
                        appendString(payload, params[i]);
                    }
                    else {
                        throw new TypeError("Unknown type ".concat(arg.type));
                    }
            }
        }
        return payload;
    };
    return {
        devid: devId,
        cmd: cmd,
        data: new Uint8Array(buffer.concat(buildPayload(cmd.args, params)))
    };
}
var Client = /** @class */ (function () {
    function Client(IP, websockPoolSize) {
        this.IP = IP;
        this.websockPoolSize = websockPoolSize;
        if (websockPoolSize == null) {
            websockPoolSize = 5;
        }
        this.websockPoolSize = websockPoolSize;
        this.url = "ws://".concat(IP, ":8080");
        this.driversList = [];
    }
    Client.prototype.init = function (callback) {
        return this.websockpool = new WebSocketPool(this.websockPoolSize, this.url, (function () {
            return this.loadCmds(callback);
        }.bind(this)));
    };
    Client.prototype.exit = function () {
        this.websockpool.exit();
        return delete this.websockpool;
    };
    // ------------------------
    //  Send
    // ------------------------
    Client.prototype.send = function (cmd) {
        var _this = this;
        if (this.websockpool === null || typeof this.websockpool === 'undefined') {
            return;
        }
        this.websockpool.requestSocket(function (sockid) {
            if (sockid < 0) {
                return;
            }
            var websocket = _this.websockpool.getSocket(sockid);
            websocket.send(cmd.data);
            if (_this.websockpool !== null && typeof _this.websockpool !== 'undefined') {
                _this.websockpool.freeSocket(sockid);
            }
        });
    };
    // ------------------------
    //  Receive
    // ------------------------
    Client.prototype.redirectError = function (errTest, errMsg, onSuccess, onError) {
        if (errTest) {
            if (onError === null) {
                throw new TypeError(errMsg);
            }
            else {
                return onError(errMsg);
            }
        }
        else {
            return onSuccess();
        }
    };
    Client.prototype.getPayload = function (mode, evt) {
        var buffer, dvBuff, i, len;
        var dv = new DataView(evt.data);
        var reserved = dv.getUint32(0);
        var classId = dv.getUint16(4);
        var funcId = dv.getUint16(6);
        if (mode === 'static') {
            len = dv.byteLength - 8;
            buffer = new ArrayBuffer(len);
            dvBuff = new DataView(buffer);
            for (i = 0, end = len - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
                var asc, end;
                dvBuff.setUint8(i, dv.getUint8(8 + i));
            }
        }
        else { // 'dynamic'
            len = dv.getUint32(8);
            console.assert(dv.byteLength === (len + 12));
            buffer = new ArrayBuffer(len);
            dvBuff = new DataView(buffer);
            for (i = 0, end1 = len - 1, asc1 = 0 <= end1; asc1 ? i <= end1 : i >= end1; asc1 ? i++ : i--) {
                var asc1, end1;
                dvBuff.setUint8(i, dv.getUint8(12 + i));
            }
        }
        return [dvBuff, classId, funcId];
    };
    Client.prototype._readBase = function (mode, cmd, fn) {
        var _this = this;
        if ((this.websockpool === null || typeof (this.websockpool) === 'undefined')) {
            return fn(null);
        }
        this.websockpool.requestSocket(function (sockid) {
            if (sockid < 0) {
                return fn(null);
            }
            var websocket = _this.websockpool.getSocket(sockid);
            websocket.send(cmd.data);
            websocket.onmessage = function (evt) {
                fn(_this.getPayload(mode, evt)[0]);
                if (_this.websockpool !== null && typeof _this.websockpool !== 'undefined') {
                    _this.websockpool.freeSocket(sockid);
                }
            };
        });
    };
    Client.prototype.readUint32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Uint32Array(data.buffer));
        });
    };
    Client.prototype.readInt32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Int32Array(data.buffer));
        });
    };
    Client.prototype.readFloat32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Float32Array(data.buffer));
        });
    };
    Client.prototype.readFloat64Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Float64Array(data.buffer));
        });
    };
    Client.prototype.readUint32Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Uint32Array(data.buffer));
        });
    };
    Client.prototype.readFloat32Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Float32Array(data.buffer));
        });
    };
    Client.prototype.readFloat64Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Float64Array(data.buffer));
        });
    };
    Client.prototype.readUint32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getUint32(0));
        });
    };
    Client.prototype.readInt32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getInt32(0));
        });
    };
    Client.prototype.readFloat32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getFloat32(0));
        });
    };
    Client.prototype.readFloat64 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getFloat64(0));
        });
    };
    Client.prototype.readBool = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getUint8(0) === 1);
        });
    };
    Client.prototype.readTuple = function (cmd, fmt, fn) {
        var _this = this;
        this._readBase('static', cmd, function (data) {
            fn(_this.deserialize(fmt, data));
        });
    };
    Client.prototype.deserialize = function (fmt, dv, onError) {
        if (onError == null) {
            onError = null;
        }
        var tuple = [];
        var offset = 0;
        for (var i = 0, end = fmt.length - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            switch (fmt[i]) {
                case 'B':
                    tuple.push(dv.getUint8(offset));
                    offset += 1;
                    break;
                case 'b':
                    tuple.push(dv.getInt8(offset));
                    offset += 1;
                    break;
                case 'H':
                    tuple.push(dv.getUint16(offset));
                    offset += 2;
                    break;
                case 'h':
                    tuple.push(dv.getInt16(offset));
                    offset += 2;
                    break;
                case 'I':
                    tuple.push(dv.getUint32(offset));
                    offset += 4;
                    break;
                case 'i':
                    tuple.push(dv.getInt32(offset));
                    offset += 4;
                    break;
                case 'f':
                    tuple.push(dv.getFloat32(offset));
                    offset += 4;
                    break;
                case 'd':
                    tuple.push(dv.getFloat64(offset));
                    offset += 8;
                    break;
                case '?':
                    if (dv.getUint8(offset) === 0) {
                        tuple.push(false);
                    }
                    else {
                        tuple.push(true);
                    }
                    offset += 1;
                    break;
                default:
                    this.redirectError(true, "Unknown or unsupported type ".concat(fmt[i]), (function () { }), onError);
            }
        }
        return tuple;
    };
    Client.prototype.parseString = function (data, offset) {
        if (offset == null) {
            offset = 0;
        }
        return (__range__(0, data.byteLength - offset - 1, true).map(function (i) { return (String.fromCharCode(data.getUint8(offset + i))); })).join('');
    };
    Client.prototype.readString = function (cmd, fn) {
        var _this = this;
        this._readBase('dynamic', cmd, function (data) {
            fn(_this.parseString(data));
        });
    };
    Client.prototype.readJSON = function (cmd, fn) {
        this.readString(cmd, function (str) {
            fn(JSON.parse(str));
        });
    };
    // ------------------------
    //  Drivers
    // ------------------------
    Client.prototype.loadCmds = function (callback) {
        var _this = this;
        this.readJSON(Command(1, { 'id': 1, 'args': [] }), function (data) {
            for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
                var driver = data_1[_i];
                var dev = new Driver(driver.class, driver.id, driver.functions);
                // dev.show()
                _this.driversList.push(dev);
            }
            callback();
        });
    };
    Client.prototype.getDriver = function (name) {
        for (var _i = 0, _a = this.driversList; _i < _a.length; _i++) {
            var driver = _a[_i];
            if (driver.name === name) {
                return driver;
            }
        }
        throw new Error("Driver ".concat(name, " not found"));
    };
    Client.prototype.getDriverById = function (id) {
        for (var _i = 0, _a = this.driversList; _i < _a.length; _i++) {
            var driver = _a[_i];
            if (driver.id === id) {
                return driver;
            }
        }
        throw new ReferenceError("Driver ID ".concat(id, " not found"));
    };
    return Client;
}());
;
function __range__(left, right, inclusive) {
    var range = [];
    var ascending = left < right;
    var end = !inclusive ? right : ascending ? right + 1 : right - 1;
    for (var i = left; ascending ? i < end : i > end; ascending ? i++ : i--) {
        range.push(i);
    }
    return range;
}
var Imports = /** @class */ (function () {
    function Imports(document) {
        this.importLinks = document.querySelectorAll('link[rel="import"]');
        for (var i = 0; i < this.importLinks.length; i++) {
            var template = this.importLinks[i].import.querySelector('.template');
            var clone = document.importNode(template.content, true);
            var parentId = this.importLinks[i].dataset.parent;
            document.getElementById(parentId).appendChild(clone);
        }
    }
    return Imports;
}());
// ----------------------------
// Module: App Controller
// ----------------------------
var App = /** @class */ (function () {
    // ----------------------------
    // Module: Initialization + Lifecycle
    // ----------------------------
    function App(window, document, ip, plot_placeholder) {
        var _this = this;
        // ----------------------------
        // State: Signal Source Controls
        // ----------------------------
        this.sampleRateHz = 125000000;
        this.signalSourceDefaultFrequencyHz = 100000;
        this.signalSourceDefaultAmplitudeVpp = 1.0;
        this.signalSourceMaxFrequencyHz = 10000000;
        this.signalSourceMaxAmplitudeVpp = 2.0;
        this.appliedOutputChannel = 2;
        this.appliedFrequencyHz = this.signalSourceDefaultFrequencyHz;
        this.appliedAmplitudeVpp = this.signalSourceDefaultAmplitudeVpp;
        this.driverAutoTimer = null;
        this.driverRequestInFlight = false;
        this.appliedPhase2Input = 'in1';
        this.lastManualPhase2Input = 'in1';
        this.appliedPhase3Feature = 'iq_in2';
        this.appliedPhase4Calibration = 'tare_scale';
        this.appliedPhase5Smoothing = 'ema';
        this.appliedWindowSamples = 8000;
        this.iqReferenceMinAmplitudeDefault = 0.05;
        this.appliedIqReferenceMinAmplitude = this.iqReferenceMinAmplitudeDefault;
        this.appliedSmoothingWindow = 5;
        this.appliedSmoothingAlpha = 0.10;
        this.appliedDivisionEpsilon = 0.01;
        this.appliedDivisionClip = 100.0;
        this.expCalibrationA = 5.5777;
        this.expCalibrationBgPerGram = 0.001142;
        this.expCalibrationBkg = this.expCalibrationBgPerGram * 1000.0;
        this.expCalibrationC = -5.9575;
        this.expCalibrationArgumentEpsilon = 1e-9;
        this.featureTare = 0;
        this.calibrationToolStorageKey = 'scale_v2_calibration_tool_measurements_v1';
        this.calibrationMeasurements = [];
        this.nextCalibrationMeasurementId = 1;
        this.calibrationMeasurementRunning = false;
        // ----------------------------
        // State: Data Buffers
        // ----------------------------
        this.latestIn1 = [];
        this.latestIn2 = [];
        this.latestIn1Plot = [];
        this.latestIn2Plot = [];
        this.out1Cache = [];
        this.out2Cache = [];
        this.out1Plot = [];
        this.out2Plot = [];
        // ----------------------------
        // State: Derived Scalars
        // ----------------------------
        this.featureTraceValue = 0;
        this.weightTraceValue = 0;
        this.lastActiveCalibrationOffset = 0;
        this.lastPipelineResult = {
            featureRaw: 0,
            featureUsed: 0,
            weightRaw: 0,
            weightUsed: 0,
            rmsIn1: 0,
            rmsIn2: 0,
            rmsOut1: 0,
            rmsOut2: 0,
            iqI: 0,
            iqQ: 0,
            iqA: 0,
            iqARef: 0,
            iqANorm: 0,
            iqRefPhaseDeg: 0
        };
        // ----------------------------
        // State: Smoothing Runtime
        // ----------------------------
        this.smoothingHistory = [];
        this.emaWeight = 0;
        this.emaInitialized = false;
        this.lastSmoothingEvaluationText = 'Off';
        this.iqNormalizationEpsilon = 0.000001;
        this.iqProjectionBaseI = 0;
        this.iqProjectionBaseQ = 0;
        this.iqProjectionBaseInitialized = false;
        this.iqSProjHold = 0;
        this.iqSProjHoldInitialized = false;
        this.lastIqI = 0;
        this.lastIqQ = 0;
        // ----------------------------
        // State: Plot Runtime
        // ----------------------------
        this.lastPlotRangeUs = { from: 0, to: 0 };
        this.runningPlotFrameStartUs = 0;
        this.adcRawSize = 16384;
        this.adcDecimationStep = 1;
        this.dacDecimationStep = 1;
        this.curveVisible = {
            in1: true,
            in2: true,
            out1: true,
            out2: true,
            feature: true,
            weight: true
        };
        var client = new Client(ip, 5);
        window.addEventListener('HTMLImportsLoaded', function () {
            client.init(function () {
                new Imports(document);
                _this.connector = new Connector(client);
                _this.plotBasics = new PlotBasics(document, plot_placeholder, 4096, 0, 4096, -11, 11, _this.connector, '', '');
                _this.bindCurveControls(document);
                _this.bindPlotActions(document);
                _this.bindSignalSource(document);
                _this.bindDriverPanel(document);
                _this.bindWorkflowControls(document);
                _this.bindScalePanel(document);
                _this.applyPhase1Settings();
                _this.applyPhase2Settings();
                _this.applyPhase3Settings();
                _this.applyPhase4Settings();
                _this.applyPhase5Settings();
                _this.updateFormulaAndParameterVisibility();
                _this.updateDiagnosticsPlot();
            });
        }, false);
        window.onbeforeunload = function () {
            if (_this.driverAutoTimer !== null) {
                window.clearInterval(_this.driverAutoTimer);
            }
            client.exit();
        };
    }
    // ----------------------------
    // Module: Plot + Curve UI
    // ----------------------------
    App.prototype.bindCurveControls = function (document) {
        this.bindCurveToggle(document, 'curve-in1', 'in1');
        this.bindCurveToggle(document, 'curve-in2', 'in2');
        this.bindCurveToggle(document, 'curve-out1', 'out1');
        this.bindCurveToggle(document, 'curve-out2', 'out2');
        this.bindCurveToggle(document, 'curve-feature', 'feature');
        this.bindCurveToggle(document, 'curve-weight', 'weight');
    };
    App.prototype.bindCurveToggle = function (document, elementId, key) {
        var _this = this;
        var checkbox = document.getElementById(elementId);
        checkbox.checked = this.curveVisible[key];
        checkbox.addEventListener('change', function () {
            _this.curveVisible[key] = checkbox.checked;
        });
    };
    App.prototype.bindPlotActions = function (document) {
        var _this = this;
        this.plotDecimationMethodSelect = document.getElementById('plot-decimation-method');
        var onPlotSettingsChanged = function () {
            _this.updateFormulaAndParameterVisibility();
        };
        this.plotDecimationMethodSelect.addEventListener('change', onPlotSettingsChanged);
        var plotPlaceholder = $('#plot-placeholder');
        plotPlaceholder.on('click', '.legendLabel', function (event) {
            var label = ($(event.currentTarget).text() || '').trim();
            var key = _this.getSeriesKeyFromLabel(label);
            if (!key) {
                return;
            }
            _this.curveVisible[key] = !_this.curveVisible[key];
            _this.setCheckboxFromKey(document, key, _this.curveVisible[key]);
        });
        var resetBtn = document.getElementById('btn-plot-reset-view');
        if (resetBtn) {
            resetBtn.addEventListener('click', function () {
                _this.plotBasics.resetView(_this.lastPlotRangeUs.from, _this.lastPlotRangeUs.to);
            });
        }
    };
    // ----------------------------
    // Module: Source + Driver Panel UI
    // ----------------------------
    App.prototype.bindSignalSource = function (document) {
        var _this = this;
        this.outputChannelSelect = document.getElementById('output-channel');
        this.amplitudeInput = document.getElementById('signal-amplitude');
        this.frequencyInput = document.getElementById('signal-frequency');
        this.phase1SaveBtn = document.getElementById('btn-phase1-save');
        var applyPhase1 = function () { return _this.applyPhase1Settings(); };
        this.phase1SaveBtn.addEventListener('click', applyPhase1);
        this.amplitudeInput.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                applyPhase1();
            }
        });
        this.frequencyInput.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                applyPhase1();
            }
        });
    };
    App.prototype.bindDriverPanel = function (document) {
        var _this = this;
        this.driverActionSelect = document.getElementById('driver-action');
        this.driverRefreshModeSelect = document.getElementById('driver-refresh-mode');
        this.driverSamplesInput = document.getElementById('driver-samples');
        this.driverRunBtn = document.getElementById('btn-driver-run');
        this.driverOutputEl = document.getElementById('driver-output');
        this.driverActionSelect.addEventListener('change', function () { return _this.updateDriverAutoRun(); });
        this.driverRefreshModeSelect.addEventListener('change', function () { return _this.updateDriverAutoRun(); });
        this.driverSamplesInput.addEventListener('change', function () { return _this.clampDriverSamplesInput(); });
        this.driverRunBtn.addEventListener('click', function () { return _this.executeDriverAction(); });
        this.driverOutputEl.innerText = 'Ready.';
        if (this.liveDriverActionEl) {
            this.liveDriverActionEl.innerText = this.getDriverAction();
        }
        if (this.liveDriverResultEl) {
            this.liveDriverResultEl.innerText = 'Ready.';
        }
        this.clampDriverSamplesInput();
        this.updateDriverAutoRun();
    };
    App.prototype.updateDriverAutoRun = function () {
        var _this = this;
        if (this.driverAutoTimer !== null) {
            window.clearInterval(this.driverAutoTimer);
            this.driverAutoTimer = null;
        }
        var mode = this.getDriverRefreshMode();
        if (mode === 'off') {
            return;
        }
        var intervalMs = mode === '1hz' ? 1000 : 200;
        this.driverAutoTimer = window.setInterval(function () { return _this.executeDriverAction(); }, intervalMs);
    };
    App.prototype.getDriverRefreshMode = function () {
        var mode = this.driverRefreshModeSelect.value;
        if (mode === 'off' || mode === '1hz' || mode === '5hz') {
            return mode;
        }
        return 'off';
    };
    App.prototype.getDriverAction = function () {
        var action = this.driverActionSelect.value;
        if (action === 'rms' || action === 'true_rms') {
            return action;
        }
        return 'rms';
    };
    App.prototype.getDriverSamples = function () {
        return 8000;
    };
    App.prototype.clampDriverSamplesInput = function () {
        this.driverSamplesInput.value = this.getDriverSamples().toString();
    };
    App.prototype.writeDriverOutput = function (text) {
        var ts = new Date().toLocaleTimeString();
        this.driverOutputEl.innerText = '[' + ts + '] ' + text;
        if (this.liveDriverResultEl) {
            this.liveDriverResultEl.innerText = text;
        }
    };
    App.prototype.executeDriverAction = function () {
        var _this = this;
        var action = this.getDriverAction();
        if (this.liveDriverActionEl) {
            this.liveDriverActionEl.innerText = action;
        }
        if (this.driverRequestInFlight) {
            return;
        }
        var n = this.getDriverSamples();
        this.driverRequestInFlight = true;
        var finalize = function () {
            _this.driverRequestInFlight = false;
        };
        if (action === 'rms') {
            this.connector.getAdcRmsData(n, function (rms0, rms1) {
                _this.writeDriverOutput('RMS (' + n.toString() + ' samples): IN1=' + rms0.toFixed(4) +
                    ', IN2=' + rms1.toFixed(4) +
                    ' counts');
                finalize();
            });
            return;
        }
        if (action === 'true_rms') {
            this.connector.getAdcTrueRmsData(function (rms0, rms1, nPos, nNeg) {
                _this.writeDriverOutput('True RMS (8000 samples, +4000/-4000): IN1=' + rms0.toFixed(4) +
                    ', IN2=' + rms1.toFixed(4) +
                    ' counts, N+=' + nPos.toString() +
                    ', N-=' + nNeg.toString());
                finalize();
            });
            return;
        }
        this.writeDriverOutput('Unknown driver action: ' + action);
        finalize();
    };
    // ----------------------------
    // Module: Workflow Panel UI
    // ----------------------------
    App.prototype.bindWorkflowControls = function (document) {
        var _this = this;
        this.phase2InputSelect = document.getElementById('phase2-input');
        this.phase3FeatureSelect = document.getElementById('phase3-feature');
        this.phase4CalibrationSelect = document.getElementById('phase4-calibration');
        this.phase5SmoothingSelect = document.getElementById('phase5-smoothing');
        this.phase2SaveBtn = document.getElementById('btn-phase2-save');
        this.phase3SaveBtn = document.getElementById('btn-phase3-save');
        this.phase4SaveBtn = document.getElementById('btn-phase4-save');
        this.phase5SaveBtn = document.getElementById('btn-phase5-save');
        this.rmsWindowSamplesInput = document.getElementById('rms-window-samples');
        this.iqRefGateInput = document.getElementById('iq-ref-gate');
        this.smoothingWindowInput = document.getElementById('smoothing-window');
        this.smoothingAlphaInput = document.getElementById('smoothing-alpha');
        this.divisionEpsilonInput = document.getElementById('division-epsilon');
        this.divisionClipInput = document.getElementById('division-clip');
        this.plotMaxPointsInput = document.getElementById('plot-max-points');
        this.iqRefGateGroup = document.getElementById('iq-ref-gate-group');
        this.smoothingWindowGroup = document.getElementById('smoothing-window-group');
        this.smoothingAlphaGroup = document.getElementById('smoothing-alpha-group');
        this.divisionEpsilonGroup = document.getElementById('division-epsilon-group');
        this.divisionClipGroup = document.getElementById('division-clip-group');
        this.phase2SaveBtn.addEventListener('click', function () { return _this.applyPhase2Settings(); });
        this.phase3SaveBtn.addEventListener('click', function () { return _this.applyPhase3Settings(); });
        this.phase4SaveBtn.addEventListener('click', function () { return _this.applyPhase4Settings(); });
        this.phase5SaveBtn.addEventListener('click', function () { return _this.applyPhase5Settings(); });
        this.plotMaxPointsInput.addEventListener('change', function () { return _this.updateFormulaAndParameterVisibility(); });
    };
    App.prototype.applyPhase2Settings = function () {
        var featureMethod = this.getPhase3FeatureMethod();
        var mode = this.phase2InputSelect.value;
        if (featureMethod === 'iq_in2') {
            this.appliedPhase2Input = 'iq_pair';
        }
        else if (mode === 'in1' || mode === 'in2' || mode === 'in1_minus_in2' || mode === 'in1_div_in2') {
            this.appliedPhase2Input = mode;
            this.lastManualPhase2Input = mode;
        }
        this.appliedDivisionEpsilon = this.clampDivisionEpsilon(this.parseNumber(this.divisionEpsilonInput.value, this.appliedDivisionEpsilon));
        this.appliedDivisionClip = this.clampDivisionClip(this.parseNumber(this.divisionClipInput.value, this.appliedDivisionClip));
        this.enforcePhase2MappingForFeatureMethod();
        this.divisionEpsilonInput.value = this.appliedDivisionEpsilon.toFixed(6);
        this.divisionClipInput.value = this.appliedDivisionClip.toFixed(3);
        this.updateFormulaAndParameterVisibility();
    };
    App.prototype.applyPhase3Settings = function () {
        var previousMode = this.appliedPhase3Feature;
        var wasIq = previousMode === 'iq_in2';
        var mode = this.phase3FeatureSelect.value;
        if (mode === 'rms' || mode === 'true_rms' || mode === 'iq_in2') {
            this.appliedPhase3Feature = mode;
        }
        var isIq = this.appliedPhase3Feature === 'iq_in2';
        this.appliedWindowSamples = this.clampWindowSamples(this.parseNumber(this.rmsWindowSamplesInput.value, this.appliedWindowSamples));
        this.appliedIqReferenceMinAmplitude = this.clampIqReferenceMinAmplitude(this.parseNumber(this.iqRefGateInput.value, this.appliedIqReferenceMinAmplitude));
        this.phase3FeatureSelect.value = this.appliedPhase3Feature;
        this.rmsWindowSamplesInput.value = this.appliedWindowSamples.toString();
        this.iqRefGateInput.value = this.appliedIqReferenceMinAmplitude.toFixed(3);
        if (!wasIq && isIq) {
            this.iqProjectionBaseInitialized = false;
            this.iqSProjHoldInitialized = false;
        }
        this.enforcePhase2MappingForFeatureMethod();
        this.updateFormulaAndParameterVisibility();
    };
    App.prototype.applyPhase4Settings = function () {
        var mode = this.phase4CalibrationSelect.value;
        if (mode === 'off' || mode === 'tare_only' || mode === 'scale_only' || mode === 'tare_scale') {
            this.appliedPhase4Calibration = mode;
        }
        this.phase4CalibrationSelect.value = this.appliedPhase4Calibration;
        this.updateFormulaAndParameterVisibility();
    };
    App.prototype.applyPhase5Settings = function () {
        var mode = this.phase5SmoothingSelect.value;
        if (mode === 'none' || mode === 'moving_average' || mode === 'rms_window' || mode === 'true_rms_window' || mode === 'ema') {
            this.appliedPhase5Smoothing = mode;
        }
        this.appliedSmoothingWindow = this.clampSmoothingWindow(this.parseNumber(this.smoothingWindowInput.value, this.appliedSmoothingWindow));
        this.appliedSmoothingAlpha = this.clampSmoothingAlpha(this.parseNumber(this.smoothingAlphaInput.value, this.appliedSmoothingAlpha));
        this.phase5SmoothingSelect.value = this.appliedPhase5Smoothing;
        this.smoothingWindowInput.value = this.appliedSmoothingWindow.toString();
        this.smoothingAlphaInput.value = this.appliedSmoothingAlpha.toFixed(2);
        this.resetSmoothingState();
        this.updateFormulaAndParameterVisibility();
    };
    App.prototype.enforcePhase2MappingForFeatureMethod = function () {
        var isIq = this.getPhase3FeatureMethod() === 'iq_in2';
        var iqPairOption = this.phase2InputSelect.querySelector('option[value="iq_pair"]');
        if (iqPairOption) {
            iqPairOption.disabled = !isIq;
        }
        if (isIq) {
            if (this.appliedPhase2Input !== 'iq_pair') {
                this.lastManualPhase2Input = this.appliedPhase2Input;
                this.appliedPhase2Input = 'iq_pair';
            }
            this.phase2InputSelect.value = 'iq_pair';
            this.phase2InputSelect.disabled = true;
            return;
        }
        this.phase2InputSelect.disabled = false;
        if (this.appliedPhase2Input === 'iq_pair') {
            this.appliedPhase2Input = this.lastManualPhase2Input;
        }
        this.phase2InputSelect.value = this.appliedPhase2Input;
    };
    // ----------------------------
    // Module: Scale Panel UI
    // ----------------------------
    App.prototype.bindScalePanel = function (document) {
        var _this = this;
        this.weightEl = document.getElementById('weight-value');
        this.weightUnitEl = document.getElementById('weight-unit');
        this.scaleTareFeatureEl = document.getElementById('scale-tare-feature');
        this.liveFeatureFormulaEl = document.getElementById('live-feature-formula');
        this.liveCalibrationFormulaEl = document.getElementById('live-calibration-formula');
        this.liveCalibrationEvalEl = document.getElementById('live-calibration-eval');
        this.liveSourceEl = document.getElementById('live-source');
        this.liveDriverActionEl = document.getElementById('live-driver-action');
        this.liveDriverResultEl = document.getElementById('live-driver-result');
        this.liveInputEl = document.getElementById('live-input');
        this.liveAdcFormulaEl = document.getElementById('live-adc-formula');
        this.liveSourceClampEl = document.getElementById('live-source-clamp');
        this.liveDacFormulaEl = document.getElementById('live-dac-formula');
        this.liveInputFormulaEl = document.getElementById('live-input-formula');
        this.liveInputGuardEl = document.getElementById('live-input-guard');
        this.liveInputMappingSourceEl = document.getElementById('live-input-mapping-source');
        this.liveLockinParamsEl = document.getElementById('live-lockin-params');
        this.liveSmoothingFormulaEl = document.getElementById('live-smoothing-formula');
        this.liveSmoothingEvalEl = document.getElementById('live-smoothing-eval');
        this.livePlotDecimationEl = document.getElementById('live-plot-decimation');
        this.liveFeatureRawEl = document.getElementById('live-feature-raw');
        this.liveFeatureUsedEl = document.getElementById('live-feature-used');
        this.liveFeatureTareEl = document.getElementById('live-feature-tare');
        this.liveOffsetDefinitionEl = document.getElementById('live-offset-definition');
        this.liveKFactorEl = document.getElementById('live-k-factor');
        this.liveWeightRawEl = document.getElementById('live-weight-raw');
        this.liveWeightUsedEl = document.getElementById('live-weight-used');
        this.liveRmsIn12El = document.getElementById('live-rms-in12');
        this.liveRmsOut12El = document.getElementById('live-rms-out12');
        this.liveIqIEl = document.getElementById('live-iq-i');
        this.liveIqQEl = document.getElementById('live-iq-q');
        this.liveIqAEl = document.getElementById('live-iq-a');
        this.liveIqARefEl = document.getElementById('live-iq-aref');
        this.liveIqANormEl = document.getElementById('live-iq-anorm');
        this.liveIqRefPhaseEl = document.getElementById('live-iq-ref-phase');
        this.liveIqI0El = document.getElementById('live-iq-i0');
        this.liveIqQ0El = document.getElementById('live-iq-q0');
        this.calibrationAddMeasurementBtn = document.getElementById('btn-calibration-add-measurement');
        this.calibrationDownloadCsvBtn = document.getElementById('btn-calibration-download-csv');
        this.calibrationToolStatusEl = document.getElementById('calibration-tool-status');
        this.calibrationToolAvgKEl = document.getElementById('calibration-tool-k-avg');
        this.calibrationToolBodyEl = document.getElementById('calibration-tool-body');
        this.calibrationAddMeasurementBtn.addEventListener('click', function () { return _this.runCalibrationMeasurementSequence(); });
        this.calibrationDownloadCsvBtn.addEventListener('click', function () { return _this.downloadCalibrationCsv(); });
        this.tareBtn = document.getElementById('btn-tare');
        this.tareBtn.addEventListener('click', function () {
            var mode = _this.getPhase4CalibrationMode();
            if (!_this.usesTare(mode)) {
                return;
            }
            if (_this.getPhase3FeatureMethod() === 'iq_in2') {
                // In IQ signed projection mode, tare defines the projection origin in I/Q space.
                _this.iqProjectionBaseI = _this.lastIqI;
                _this.iqProjectionBaseQ = _this.lastIqQ;
                _this.iqProjectionBaseInitialized = true;
                _this.iqSProjHold = 0;
                _this.iqSProjHoldInitialized = true;
                _this.featureTare = 0;
            }
            else {
                _this.featureTare = _this.featureTraceValue;
            }
            _this.scaleTareFeatureEl.innerText = _this.featureTare.toFixed(4);
            _this.liveFeatureTareEl.innerText = _this.getActiveCalibrationOffset().toFixed(4);
            _this.liveIqI0El.innerText = _this.iqProjectionBaseI.toFixed(4);
            _this.liveIqQ0El.innerText = _this.iqProjectionBaseQ.toFixed(4);
        });
        this.scaleTareFeatureEl.innerText = this.featureTare.toFixed(4);
        this.loadCalibrationMeasurements();
        this.renderCalibrationMeasurements();
        this.updateCalibrationUiState();
        this.liveDriverActionEl.innerText = this.getDriverAction();
        this.liveDriverResultEl.innerText = this.driverOutputEl ? this.driverOutputEl.innerText : 'Ready.';
    };
    App.prototype.runCalibrationMeasurementSequence = function () {
        var _this = this;
        if (this.calibrationMeasurementRunning) {
            return;
        }
        var countdownSeconds = 3;
        var measurementSeconds = 5;
        var startedAtIso = new Date().toISOString();
        this.calibrationMeasurementRunning = true;
        this.updateCalibrationToolButtonsState();
        var countdownRemaining = countdownSeconds;
        this.setCalibrationToolStatus('Measurement starts in ' + countdownRemaining.toString() + ' s');
        var countdownTimer = window.setInterval(function () {
            countdownRemaining -= 1;
            if (countdownRemaining > 0) {
                _this.setCalibrationToolStatus('Measurement starts in ' + countdownRemaining.toString() + ' s');
                return;
            }
            window.clearInterval(countdownTimer);
            _this.collectCalibrationSamples(measurementSeconds, function (samples) {
                var completedAtIso = new Date().toISOString();
                var record = _this.buildCalibrationMeasurementRecord(startedAtIso, completedAtIso, countdownSeconds, measurementSeconds, samples);
                _this.calibrationMeasurements.push(record);
                _this.saveCalibrationMeasurements();
                _this.renderCalibrationMeasurements();
                _this.setCalibrationToolStatus('Measurement #' + record.id.toString() + ' saved.');
                _this.calibrationMeasurementRunning = false;
                _this.updateCalibrationToolButtonsState();
            });
        }, 1000);
    };
    App.prototype.collectCalibrationSamples = function (durationSeconds, callback) {
        var _this = this;
        var durationMs = Math.max(1, Math.round(durationSeconds * 1000));
        var samplePeriodMs = 100;
        var samples = [];
        var remainingSeconds = durationSeconds;
        this.setCalibrationToolStatus('Measuring... ' + remainingSeconds.toString() + ' s left');
        samples.push(this.captureCalibrationSample());
        var samplingTimer = window.setInterval(function () {
            samples.push(_this.captureCalibrationSample());
        }, samplePeriodMs);
        var statusTimer = window.setInterval(function () {
            remainingSeconds -= 1;
            if (remainingSeconds > 0) {
                _this.setCalibrationToolStatus('Measuring... ' + remainingSeconds.toString() + ' s left');
            }
        }, 1000);
        window.setTimeout(function () {
            window.clearInterval(samplingTimer);
            window.clearInterval(statusTimer);
            callback(samples);
        }, durationMs);
    };
    App.prototype.captureCalibrationSample = function () {
        var p = this.lastPipelineResult;
        var activeOffset = this.lastActiveCalibrationOffset;
        return {
            timestampMs: Date.now(),
            featureRaw: this.sanitizeFinite(p.featureRaw),
            featureUsed: this.sanitizeFinite(p.featureUsed),
            featureForScale: this.sanitizeFinite(p.featureUsed - activeOffset),
            activeOffset: this.sanitizeFinite(activeOffset),
            calibrationFactor: 0,
            weightRaw: this.sanitizeFinite(p.weightRaw),
            weightUsed: this.sanitizeFinite(p.weightUsed),
            rmsIn1: this.sanitizeFinite(p.rmsIn1),
            rmsIn2: this.sanitizeFinite(p.rmsIn2),
            rmsOut1: this.sanitizeFinite(p.rmsOut1),
            rmsOut2: this.sanitizeFinite(p.rmsOut2),
            iqI: this.sanitizeFinite(p.iqI),
            iqQ: this.sanitizeFinite(p.iqQ),
            iqA: this.sanitizeFinite(p.iqA),
            iqARef: this.sanitizeFinite(p.iqARef),
            iqANorm: this.sanitizeFinite(p.iqANorm),
            iqRefPhaseDeg: this.sanitizeFinite(p.iqRefPhaseDeg),
            iqI0: this.sanitizeFinite(this.iqProjectionBaseI),
            iqQ0: this.sanitizeFinite(this.iqProjectionBaseQ)
        };
    };
    App.prototype.buildCalibrationMeasurementRecord = function (startedAtIso, completedAtIso, countdownSeconds, measurementSeconds, samples) {
        var _this = this;
        var safeSamples = samples.length > 0 ? samples : [this.captureCalibrationSample()];
        var avg = function (selector) {
            return _this.getMeasurementAverage(safeSamples, selector);
        };
        return {
            id: this.nextCalibrationMeasurementId++,
            startedAtIso: startedAtIso,
            completedAtIso: completedAtIso,
            countdownSeconds: countdownSeconds,
            measurementSeconds: measurementSeconds,
            sampleCount: safeSamples.length,
            realWeightKg: null,
            suggestedCalibrationFactor: null,
            featureRawAvg: avg(function (sample) { return sample.featureRaw; }),
            featureUsedAvg: avg(function (sample) { return sample.featureUsed; }),
            featureForScaleAvg: avg(function (sample) { return sample.featureForScale; }),
            activeOffsetAvg: avg(function (sample) { return sample.activeOffset; }),
            calibrationFactorAtMeasurement: 0,
            weightRawAvg: avg(function (sample) { return sample.weightRaw; }),
            weightUsedAvg: avg(function (sample) { return sample.weightUsed; }),
            rmsIn1Avg: avg(function (sample) { return sample.rmsIn1; }),
            rmsIn2Avg: avg(function (sample) { return sample.rmsIn2; }),
            rmsOut1Avg: avg(function (sample) { return sample.rmsOut1; }),
            rmsOut2Avg: avg(function (sample) { return sample.rmsOut2; }),
            iqIAvg: avg(function (sample) { return sample.iqI; }),
            iqQAvg: avg(function (sample) { return sample.iqQ; }),
            iqAAvg: avg(function (sample) { return sample.iqA; }),
            iqARefAvg: avg(function (sample) { return sample.iqARef; }),
            iqANormAvg: avg(function (sample) { return sample.iqANorm; }),
            iqRefPhaseDegAvg: avg(function (sample) { return sample.iqRefPhaseDeg; }),
            iqI0Avg: avg(function (sample) { return sample.iqI0; }),
            iqQ0Avg: avg(function (sample) { return sample.iqQ0; }),
            outputChannel: this.appliedOutputChannel,
            frequencyHz: this.appliedFrequencyHz,
            amplitudeVpp: this.appliedAmplitudeVpp,
            phase2Input: this.getPhase2InputMode(),
            phase3Feature: this.getPhase3FeatureMethod(),
            phase4Calibration: this.getPhase4CalibrationMode(),
            phase5Smoothing: this.getPhase5SmoothingMethod(),
            windowSamples: this.getWindowSamples(),
            iqRefGate: this.appliedIqReferenceMinAmplitude,
            smoothingWindow: this.getSmoothingWindow(),
            smoothingAlpha: this.getSmoothingAlpha(),
            divisionEpsilon: this.getDivisionEpsilon(),
            divisionClip: this.getDivisionClip(),
            plotDecimationMethod: this.getPlotDecimationMethod(),
            plotMaxPoints: this.getPlotMaxPoints(),
            driverAction: this.getDriverAction(),
            driverRefreshMode: this.getDriverRefreshMode(),
            samples: safeSamples.map(function (sample) { return (__assign({}, sample)); })
        };
    };
    App.prototype.getMeasurementAverage = function (samples, selector) {
        if (samples.length === 0) {
            return 0;
        }
        var sum = 0;
        for (var i = 0; i < samples.length; i++) {
            sum += selector(samples[i]);
        }
        return sum / samples.length;
    };
    App.prototype.computeExponentialWeightFromFeature = function (featureUsed) {
        var feature = this.sanitizeFinite(featureUsed);
        var ratio = (feature - this.expCalibrationC) / this.expCalibrationA;
        var ratioSafe = Math.max(ratio, this.expCalibrationArgumentEpsilon);
        var weightRaw = Math.log(ratioSafe) / this.expCalibrationBkg;
        if (!Number.isFinite(weightRaw) || ratio <= 0 || weightRaw <= 0) {
            return { weightKg: 0, clamped: true, ratio: ratio };
        }
        return { weightKg: weightRaw, clamped: false, ratio: ratio };
    };
    App.prototype.renderCalibrationMeasurements = function () {
        var _this = this;
        if (!this.calibrationToolBodyEl) {
            return;
        }
        if (this.calibrationMeasurements.length <= 0) {
            this.calibrationToolBodyEl.innerHTML = '<tr><td colspan="8">No measurements yet.</td></tr>';
            this.calibrationToolAvgKEl.innerText = '-';
            this.updateCalibrationToolButtonsState();
            return;
        }
        var rows = this.calibrationMeasurements.slice().sort(function (a, b) { return b.id - a.id; });
        var absErrorsKg = [];
        var html = '';
        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var realWeightText = row.realWeightKg === null ? '' : row.realWeightKg.toString();
            var featureDisplay = row.phase3Feature === 'iq_in2'
                ? this.sanitizeFinite(row.featureUsedAvg)
                : this.sanitizeFinite(row.featureForScaleAvg);
            var predicted = this.computeExponentialWeightFromFeature(featureDisplay).weightKg;
            var predictedText = predicted.toFixed(4);
            var errorText = '-';
            var errorPctText = '-';
            if (row.realWeightKg !== null) {
                var errorKg = predicted - row.realWeightKg;
                errorText = errorKg.toFixed(4);
                absErrorsKg.push(Math.abs(errorKg));
                if (Math.abs(row.realWeightKg) > 1e-12) {
                    errorPctText = (100.0 * errorKg / row.realWeightKg).toFixed(2);
                }
                else {
                    errorPctText = predicted === 0 ? '0.00' : '-';
                }
            }
            html +=
                '<tr>' +
                    '<td>' + row.id.toString() + '</td>' +
                    '<td>' + this.formatMeasurementTime(row.completedAtIso) + '</td>' +
                    '<td>' + featureDisplay.toFixed(6) + '</td>' +
                    '<td><input type="text" class="form-control input-sm calibration-realweight-input" data-measurement-id="' + row.id.toString() + '" value="' + realWeightText + '" placeholder="kg"></td>' +
                    '<td><strong>' + predictedText + '</strong></td>' +
                    '<td>' + errorText + '</td>' +
                    '<td>' + errorPctText + '</td>' +
                    '<td>' +
                    '<button class="btn btn-xs btn-danger calibration-delete-measurement-btn" data-measurement-id="' + row.id.toString() + '">Delete</button>' +
                    '</td>' +
                    '</tr>';
        }
        this.calibrationToolBodyEl.innerHTML = html;
        var inputs = this.calibrationToolBodyEl.querySelectorAll('.calibration-realweight-input');
        var _loop_1 = function (i) {
            var input = inputs[i];
            var idAttr = input.getAttribute('data-measurement-id');
            if (!idAttr) {
                return "continue";
            }
            var measurementId = parseInt(idAttr, 10);
            input.addEventListener('change', function () { return _this.onCalibrationRealWeightChanged(measurementId, input.value); });
            input.addEventListener('blur', function () { return _this.onCalibrationRealWeightChanged(measurementId, input.value); });
        };
        for (var i = 0; i < inputs.length; i++) {
            _loop_1(i);
        }
        var deleteButtons = this.calibrationToolBodyEl.querySelectorAll('.calibration-delete-measurement-btn');
        var _loop_2 = function (i) {
            var button = deleteButtons[i];
            var idAttr = button.getAttribute('data-measurement-id');
            if (!idAttr) {
                return "continue";
            }
            var measurementId = parseInt(idAttr, 10);
            button.addEventListener('click', function () { return _this.deleteCalibrationMeasurement(measurementId); });
        };
        for (var i = 0; i < deleteButtons.length; i++) {
            _loop_2(i);
        }
        if (absErrorsKg.length <= 0) {
            this.calibrationToolAvgKEl.innerText = '-';
        }
        else {
            var sumAbsError = 0;
            for (var i = 0; i < absErrorsKg.length; i++) {
                sumAbsError += absErrorsKg[i];
            }
            this.calibrationToolAvgKEl.innerText = (sumAbsError / absErrorsKg.length).toFixed(4);
        }
        this.updateCalibrationToolButtonsState();
    };
    App.prototype.onCalibrationRealWeightChanged = function (measurementId, raw) {
        var record = this.calibrationMeasurements.find(function (item) { return item.id === measurementId; });
        if (!record) {
            return;
        }
        var parsed = this.parseLocalizedNumber(raw);
        record.realWeightKg = parsed === null ? null : parsed;
        this.saveCalibrationMeasurements();
        this.renderCalibrationMeasurements();
    };
    App.prototype.deleteCalibrationMeasurement = function (measurementId) {
        var index = this.calibrationMeasurements.findIndex(function (item) { return item.id === measurementId; });
        if (index < 0) {
            return;
        }
        var confirmed = window.confirm('Delete measurement #' + measurementId.toString() + '?');
        if (!confirmed) {
            return;
        }
        this.calibrationMeasurements.splice(index, 1);
        this.saveCalibrationMeasurements();
        this.renderCalibrationMeasurements();
        this.setCalibrationToolStatus('Measurement #' + measurementId.toString() + ' deleted.');
    };
    App.prototype.setCalibrationToolStatus = function (text) {
        if (this.calibrationToolStatusEl) {
            this.calibrationToolStatusEl.innerText = text;
        }
    };
    App.prototype.updateCalibrationToolButtonsState = function () {
        if (this.calibrationAddMeasurementBtn) {
            this.calibrationAddMeasurementBtn.disabled = this.calibrationMeasurementRunning;
        }
        if (this.calibrationDownloadCsvBtn) {
            this.calibrationDownloadCsvBtn.disabled = this.calibrationMeasurements.length <= 0;
        }
    };
    App.prototype.formatMeasurementTime = function (iso) {
        var date = new Date(iso);
        if (isNaN(date.getTime())) {
            return iso;
        }
        return date.toLocaleTimeString();
    };
    App.prototype.saveCalibrationMeasurements = function () {
        try {
            window.localStorage.setItem(this.calibrationToolStorageKey, JSON.stringify(this.calibrationMeasurements));
        }
        catch (error) {
            void error;
            this.setCalibrationToolStatus('Saving failed (localStorage unavailable).');
        }
    };
    App.prototype.loadCalibrationMeasurements = function () {
        this.calibrationMeasurements = [];
        this.nextCalibrationMeasurementId = 1;
        try {
            var raw = window.localStorage.getItem(this.calibrationToolStorageKey);
            if (!raw) {
                this.updateCalibrationToolButtonsState();
                return;
            }
            var parsed = JSON.parse(raw);
            if (!Array.isArray(parsed)) {
                this.updateCalibrationToolButtonsState();
                return;
            }
            for (var i = 0; i < parsed.length; i++) {
                var hydrated = this.hydrateCalibrationMeasurementRecord(parsed[i]);
                if (hydrated === null) {
                    continue;
                }
                hydrated.suggestedCalibrationFactor = null;
                this.calibrationMeasurements.push(hydrated);
                if (hydrated.id >= this.nextCalibrationMeasurementId) {
                    this.nextCalibrationMeasurementId = hydrated.id + 1;
                }
            }
        }
        catch (error) {
            void error;
            this.calibrationMeasurements = [];
            this.nextCalibrationMeasurementId = 1;
            this.setCalibrationToolStatus('Temporary measurement data could not be loaded.');
        }
        this.updateCalibrationToolButtonsState();
    };
    App.prototype.hydrateCalibrationMeasurementRecord = function (raw) {
        var _this = this;
        if (!raw || typeof raw !== 'object') {
            return null;
        }
        var rawSamples = Array.isArray(raw.samples) ? raw.samples : [];
        var samples = rawSamples.map(function (sampleRaw) { return ({
            timestampMs: _this.toFiniteNumber(sampleRaw.timestampMs),
            featureRaw: _this.toFiniteNumber(sampleRaw.featureRaw),
            featureUsed: _this.toFiniteNumber(sampleRaw.featureUsed),
            featureForScale: _this.toFiniteNumber(sampleRaw.featureForScale),
            activeOffset: _this.toFiniteNumber(sampleRaw.activeOffset),
            calibrationFactor: _this.toFiniteNumber(sampleRaw.calibrationFactor),
            weightRaw: _this.toFiniteNumber(sampleRaw.weightRaw),
            weightUsed: _this.toFiniteNumber(sampleRaw.weightUsed),
            rmsIn1: _this.toFiniteNumber(sampleRaw.rmsIn1),
            rmsIn2: _this.toFiniteNumber(sampleRaw.rmsIn2),
            rmsOut1: _this.toFiniteNumber(sampleRaw.rmsOut1),
            rmsOut2: _this.toFiniteNumber(sampleRaw.rmsOut2),
            iqI: _this.toFiniteNumber(sampleRaw.iqI),
            iqQ: _this.toFiniteNumber(sampleRaw.iqQ),
            iqA: _this.toFiniteNumber(sampleRaw.iqA),
            iqARef: _this.toFiniteNumber(sampleRaw.iqARef),
            iqANorm: _this.toFiniteNumber(sampleRaw.iqANorm),
            iqRefPhaseDeg: _this.toFiniteNumber(sampleRaw.iqRefPhaseDeg),
            iqI0: _this.toFiniteNumber(sampleRaw.iqI0),
            iqQ0: _this.toFiniteNumber(sampleRaw.iqQ0)
        }); });
        var featureForScaleAvgFallback = this.toFiniteNumber(raw.featureUsedAvg) - this.toFiniteNumber(raw.activeOffsetAvg);
        var realWeightKg = this.toNullableFiniteNumber(raw.realWeightKg);
        var id = Math.max(1, Math.round(this.toFiniteNumber(raw.id, 0)));
        var phase2Input = raw.phase2Input === 'in2' ||
            raw.phase2Input === 'in1_minus_in2' ||
            raw.phase2Input === 'in1_div_in2' ||
            raw.phase2Input === 'iq_pair'
            ? raw.phase2Input
            : 'in1';
        var phase3Feature = raw.phase3Feature === 'true_rms' || raw.phase3Feature === 'iq_in2'
            ? raw.phase3Feature
            : 'rms';
        var phase4Calibration = raw.phase4Calibration === 'off' ||
            raw.phase4Calibration === 'tare_only' ||
            raw.phase4Calibration === 'scale_only'
            ? raw.phase4Calibration
            : 'tare_scale';
        var phase5Smoothing = raw.phase5Smoothing === 'none' ||
            raw.phase5Smoothing === 'moving_average' ||
            raw.phase5Smoothing === 'rms_window' ||
            raw.phase5Smoothing === 'true_rms_window'
            ? raw.phase5Smoothing
            : 'ema';
        var plotDecimationMethod = raw.plotDecimationMethod === 'none' ||
            raw.plotDecimationMethod === 'minmax' ||
            raw.plotDecimationMethod === 'mean'
            ? raw.plotDecimationMethod
            : 'stride';
        var driverAction = raw.driverAction === 'true_rms' ? 'true_rms' : 'rms';
        var driverRefreshMode = raw.driverRefreshMode === '1hz' || raw.driverRefreshMode === '5hz'
            ? raw.driverRefreshMode
            : 'off';
        return {
            id: id,
            startedAtIso: String(raw.startedAtIso || raw.completedAtIso || ''),
            completedAtIso: String(raw.completedAtIso || raw.startedAtIso || ''),
            countdownSeconds: Math.max(0, Math.round(this.toFiniteNumber(raw.countdownSeconds, 3))),
            measurementSeconds: Math.max(0, Math.round(this.toFiniteNumber(raw.measurementSeconds, 5))),
            sampleCount: Math.max(0, Math.round(this.toFiniteNumber(raw.sampleCount, samples.length))),
            realWeightKg: realWeightKg,
            suggestedCalibrationFactor: this.toNullableFiniteNumber(raw.suggestedCalibrationFactor),
            featureRawAvg: this.toFiniteNumber(raw.featureRawAvg),
            featureUsedAvg: this.toFiniteNumber(raw.featureUsedAvg),
            featureForScaleAvg: this.toFiniteNumber(raw.featureForScaleAvg, featureForScaleAvgFallback),
            activeOffsetAvg: this.toFiniteNumber(raw.activeOffsetAvg),
            calibrationFactorAtMeasurement: this.toFiniteNumber(raw.calibrationFactorAtMeasurement),
            weightRawAvg: this.toFiniteNumber(raw.weightRawAvg),
            weightUsedAvg: this.toFiniteNumber(raw.weightUsedAvg),
            rmsIn1Avg: this.toFiniteNumber(raw.rmsIn1Avg),
            rmsIn2Avg: this.toFiniteNumber(raw.rmsIn2Avg),
            rmsOut1Avg: this.toFiniteNumber(raw.rmsOut1Avg),
            rmsOut2Avg: this.toFiniteNumber(raw.rmsOut2Avg),
            iqIAvg: this.toFiniteNumber(raw.iqIAvg),
            iqQAvg: this.toFiniteNumber(raw.iqQAvg),
            iqAAvg: this.toFiniteNumber(raw.iqAAvg),
            iqARefAvg: this.toFiniteNumber(raw.iqARefAvg),
            iqANormAvg: this.toFiniteNumber(raw.iqANormAvg),
            iqRefPhaseDegAvg: this.toFiniteNumber(raw.iqRefPhaseDegAvg),
            iqI0Avg: this.toFiniteNumber(raw.iqI0Avg),
            iqQ0Avg: this.toFiniteNumber(raw.iqQ0Avg),
            outputChannel: Math.max(0, Math.min(2, Math.round(this.toFiniteNumber(raw.outputChannel, 2)))),
            frequencyHz: this.toFiniteNumber(raw.frequencyHz, this.signalSourceDefaultFrequencyHz),
            amplitudeVpp: this.toFiniteNumber(raw.amplitudeVpp, this.signalSourceDefaultAmplitudeVpp),
            phase2Input: phase2Input,
            phase3Feature: phase3Feature,
            phase4Calibration: phase4Calibration,
            phase5Smoothing: phase5Smoothing,
            windowSamples: Math.max(1, Math.round(this.toFiniteNumber(raw.windowSamples, 8000))),
            iqRefGate: this.toFiniteNumber(raw.iqRefGate, this.iqReferenceMinAmplitudeDefault),
            smoothingWindow: Math.max(1, Math.round(this.toFiniteNumber(raw.smoothingWindow, 5))),
            smoothingAlpha: this.toFiniteNumber(raw.smoothingAlpha, 0.1),
            divisionEpsilon: this.toFiniteNumber(raw.divisionEpsilon, 0.01),
            divisionClip: this.toFiniteNumber(raw.divisionClip, 100.0),
            plotDecimationMethod: plotDecimationMethod,
            plotMaxPoints: Math.max(1, Math.round(this.toFiniteNumber(raw.plotMaxPoints, 2048))),
            driverAction: driverAction,
            driverRefreshMode: driverRefreshMode,
            samples: samples
        };
    };
    App.prototype.toFiniteNumber = function (value, fallback) {
        if (fallback === void 0) { fallback = 0; }
        var parsed = Number(value);
        if (Number.isFinite(parsed)) {
            return parsed;
        }
        return fallback;
    };
    App.prototype.toNullableFiniteNumber = function (value) {
        if (value === null || value === undefined || value === '') {
            return null;
        }
        var parsed = Number(value);
        if (Number.isFinite(parsed)) {
            return parsed;
        }
        return null;
    };
    App.prototype.downloadCalibrationCsv = function () {
        if (this.calibrationMeasurements.length <= 0) {
            this.setCalibrationToolStatus('No measurements available for CSV.');
            return;
        }
        var csv = this.buildCalibrationCsv();
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        var url = window.URL.createObjectURL(blob);
        var link = document.createElement('a');
        link.href = url;
        link.download = this.buildCalibrationCsvFilename();
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.setTimeout(function () { return window.URL.revokeObjectURL(url); }, 0);
        this.setCalibrationToolStatus('CSV exported.');
    };
    App.prototype.buildCalibrationCsv = function () {
        var _this = this;
        var headers = [
            'measurement_id',
            'completed_at_iso',
            'real_weight_kg',
            'feature_used_avg',
            'predicted_weight_kg',
            'error_kg',
            'error_percent',
            'calibration_a',
            'calibration_b_kg',
            'calibration_c',
            'frequency_hz',
            'amplitude_vpp',
            'iq_ref_gate',
            'output_channel',
            'phase3_feature',
            'phase4_calibration',
            'window_samples'
        ];
        var lines = [headers.join(',')];
        for (var i = 0; i < this.calibrationMeasurements.length; i++) {
            var measurement = this.calibrationMeasurements[i];
            var featureForPrediction = this.sanitizeFinite(measurement.featureForScaleAvg);
            var predictedWeight = this.computeExponentialWeightFromFeature(featureForPrediction).weightKg;
            var errorKg = null;
            var errorPercent = null;
            if (measurement.realWeightKg !== null) {
                errorKg = predictedWeight - measurement.realWeightKg;
                if (Math.abs(measurement.realWeightKg) > 1e-12) {
                    errorPercent = 100.0 * errorKg / measurement.realWeightKg;
                }
            }
            var row = [
                measurement.id,
                measurement.completedAtIso,
                measurement.realWeightKg,
                measurement.featureUsedAvg,
                predictedWeight,
                errorKg,
                errorPercent,
                this.expCalibrationA,
                this.expCalibrationBkg,
                this.expCalibrationC,
                measurement.frequencyHz,
                measurement.amplitudeVpp,
                measurement.iqRefGate,
                measurement.outputChannel,
                measurement.phase3Feature,
                measurement.phase4Calibration,
                measurement.windowSamples
            ];
            lines.push(row.map(function (value) { return _this.csvEscape(value); }).join(','));
        }
        return lines.join('\n');
    };
    App.prototype.csvEscape = function (value) {
        if (value === null || value === undefined) {
            return '';
        }
        var text = '';
        if (typeof value === 'number' && Number.isFinite(value)) {
            text = this.formatCsvNumber(value);
        }
        else {
            text = String(value);
        }
        if (text.indexOf('"') >= 0 || text.indexOf(',') >= 0 || text.indexOf('\n') >= 0) {
            return '"' + text.replace(/"/g, '""') + '"';
        }
        return text;
    };
    App.prototype.formatCsvNumber = function (value) {
        var rounded = Math.round(value * 10000) / 10000;
        var normalized = Math.abs(rounded) < 1e-12 ? 0 : rounded;
        return normalized.toString();
    };
    App.prototype.buildCalibrationCsvFilename = function () {
        var now = new Date();
        var yyyy = now.getFullYear().toString();
        var mm = (now.getMonth() + 1).toString().padStart(2, '0');
        var dd = now.getDate().toString().padStart(2, '0');
        var hh = now.getHours().toString().padStart(2, '0');
        var mi = now.getMinutes().toString().padStart(2, '0');
        var ss = now.getSeconds().toString().padStart(2, '0');
        return 'scale_v2_calibration_' + yyyy + mm + dd + '_' + hh + mi + ss + '.csv';
    };
    // ----------------------------
    // Module: Formula + Live Trace
    // ----------------------------
    App.prototype.applyPhase1Settings = function () {
        var signalType = 1; // Sine only
        var frequencyCmd = this.parseSignalSourceFrequencyHz(this.frequencyInput.value, this.signalSourceDefaultFrequencyHz);
        var outputChannel = Number(this.outputChannelSelect.value);
        var amplitudeCmdVpp = this.parseSignalSourceAmplitudeVpp(this.amplitudeInput.value, this.signalSourceDefaultAmplitudeVpp);
        var frequencyEff = this.clampFrequencyHz(frequencyCmd);
        var amplitudeEffVpp = this.clampAmplitudeVpp(amplitudeCmdVpp);
        var amplitudeEffVpk = amplitudeEffVpp / 2.0;
        this.appliedOutputChannel = Math.max(0, Math.min(2, Math.round(outputChannel)));
        this.appliedFrequencyHz = frequencyEff;
        this.appliedAmplitudeVpp = amplitudeEffVpp;
        this.connector.setFunction(signalType, this.appliedFrequencyHz);
        this.connector.setOutputChannel(this.appliedOutputChannel);
        this.connector.setAmplitude(amplitudeEffVpk);
        this.frequencyInput.value = this.formatFrequencyInputValue(this.appliedFrequencyHz);
        this.amplitudeInput.value = this.formatAmplitudeInputValue(this.appliedAmplitudeVpp);
        this.outputChannelSelect.value = this.appliedOutputChannel.toString();
        this.liveSourceEl.innerText = 'Sine -> ' + this.getOutputChannelLabel(this.appliedOutputChannel);
        this.liveSourceClampEl.innerText =
            'f_cmd=' + frequencyCmd.toFixed(1) +
                ' -> f_eff=' + this.appliedFrequencyHz.toFixed(1) +
                ' Hz, A_cmd=' + amplitudeCmdVpp.toFixed(3) +
                ' -> A_eff=' + this.appliedAmplitudeVpp.toFixed(3) + ' Vpp';
        this.liveDacFormulaEl.innerText =
            'sample14 = round(sin(2*pi*phase) * (2^14/2.1) * (A_vpk/1.0)), A_vpk=' +
                amplitudeEffVpk.toFixed(3) + ' Vpk';
        // Frequency changes invalidate IQ lock reference and held feature.
        this.iqProjectionBaseInitialized = false;
        this.iqSProjHoldInitialized = false;
    };
    App.prototype.updateFormulaAndParameterVisibility = function () {
        this.applyDriverDecimationSettings();
        var featureMethod = this.getPhase3FeatureMethod();
        var calibrationMode = this.getPhase4CalibrationMode();
        var smoothingMethod = this.getPhase5SmoothingMethod();
        var divisionEpsilon = this.getDivisionEpsilon();
        var divisionClip = this.getDivisionClip();
        var plotMaxPoints = this.getPlotMaxPoints();
        var plotDecimation = this.getPlotDecimationMethod();
        var isIq = featureMethod === 'iq_in2';
        this.enforcePhase2MappingForFeatureMethod();
        var inputMode = this.getPhase2InputMode();
        this.livePlotDecimationEl.innerText =
            'Method=' + this.getPlotDecimationMethodLabel(plotDecimation) +
                ', X=running time';
        var inputFormula = isIq
            ? 'x[i] = IN1_V[i] - mean(IN1), r[i] = IN2_V[i] - mean(IN2), Z = X / R'
            : this.getPhase2InputFormula(inputMode, divisionEpsilon, divisionClip);
        this.liveAdcFormulaEl.innerText = 'IN_V = ADC_code / 819.2 (14-bit signed, approx +/-10 V)';
        this.liveInputFormulaEl.innerText = inputFormula;
        if (isIq) {
            this.liveInputGuardEl.innerText = 'Forced mapping for IQ: IN1 signal + IN2 reference';
        }
        else if (inputMode === 'in1_div_in2') {
            this.liveInputGuardEl.innerText =
                'den_safe = sign(IN2_V) * max(|IN2_V|, ' +
                    divisionEpsilon.toFixed(6) +
                    '), clip = +/-' +
                    divisionClip.toFixed(3);
        }
        else {
            this.liveInputGuardEl.innerText = 'Off';
        }
        this.liveInputMappingSourceEl.innerText = isIq
            ? 'Forced by IQ method (IN1 signal, IN2 reference)'
            : 'Manual (Phase 2)';
        var featureFormula = 'RMS = sqrt((1/N) * sum(x^2)), x from Phase-2 input';
        if (featureMethod === 'true_rms') {
            featureFormula = 'True RMS = sqrt((sum(x_pos^2) + sum(x_neg^2)) / (N_pos + N_neg)), N_pos=4000, N_neg=4000';
        }
        else if (isIq) {
            featureFormula =
                'X=(Ix+jQx), R=(Ir+jQr), Z=X/R, ' +
                    'S_proj=-(dot((Re(Z)-I0,Im(Z)-Q0),u0)), u0=(I0,Q0)/|I0,Q0|';
        }
        this.liveFeatureFormulaEl.innerText = featureFormula;
        var calibrationFormula = 'Weight = Feature';
        if (calibrationMode === 'off') {
            calibrationFormula = 'Weight = Feature';
        }
        else if (calibrationMode === 'tare_only') {
            calibrationFormula = isIq
                ? 'Weight = Feature - Offset(Zero from IQ I0/Q0, active=0)'
                : 'Weight = Feature - Offset(Feature)';
        }
        else if (calibrationMode === 'scale_only') {
            calibrationFormula =
                'Weight_kg = ln((Feature - C) / A) / B_kg, A=' +
                    this.expCalibrationA.toFixed(4) +
                    ', B_kg=' +
                    this.expCalibrationBkg.toFixed(6) +
                    ', C=' +
                    this.expCalibrationC.toFixed(4);
        }
        else {
            calibrationFormula =
                'Weight_kg = ln(((Feature - Offset) - C) / A) / B_kg, A=' +
                    this.expCalibrationA.toFixed(4) +
                    ', B_kg=' +
                    this.expCalibrationBkg.toFixed(6) +
                    ', C=' +
                    this.expCalibrationC.toFixed(4);
        }
        this.liveCalibrationFormulaEl.innerText = calibrationFormula;
        this.liveOffsetDefinitionEl.innerText = isIq ? 'Offset (IQ I0/Q0)' : 'Offset (Feature)';
        this.liveFeatureTareEl.innerText = this.getActiveCalibrationOffset().toFixed(4);
        this.liveIqI0El.innerText = this.iqProjectionBaseI.toFixed(4);
        this.liveIqQ0El.innerText = this.iqProjectionBaseQ.toFixed(4);
        this.updateCalibrationUiState();
        this.smoothingWindowGroup.style.display = 'none';
        this.smoothingAlphaGroup.style.display = 'none';
        this.divisionEpsilonGroup.style.display = 'none';
        this.divisionClipGroup.style.display = 'none';
        this.iqRefGateGroup.style.display = 'none';
        if (!isIq && inputMode === 'in1_div_in2') {
            this.divisionEpsilonGroup.style.display = 'block';
            this.divisionClipGroup.style.display = 'block';
        }
        if (isIq) {
            this.iqRefGateGroup.style.display = 'block';
        }
        if (featureMethod === 'true_rms') {
            this.liveLockinParamsEl.innerText = 'N+=4000, N-=4000 around zero crossing';
        }
        else if (isIq) {
            this.liveLockinParamsEl.innerText =
                'f_ref=' + this.appliedFrequencyHz.toFixed(1) +
                    ' Hz, complex ratio X/R, signed projection, den_eps=' + this.iqNormalizationEpsilon.toFixed(6) +
                    ', ref_gate=' + this.appliedIqReferenceMinAmplitude.toFixed(3);
        }
        else {
            this.liveLockinParamsEl.innerText = 'Off';
        }
        if (smoothingMethod === 'none') {
            var smoothingFormula = 'Off';
            this.liveSmoothingFormulaEl.innerText = smoothingFormula;
        }
        else if (smoothingMethod === 'moving_average') {
            var smoothingFormula = 'y[n] = (1/M) * sum_{k=0..M-1}(x[n-k])';
            this.liveSmoothingFormulaEl.innerText = smoothingFormula;
            this.smoothingWindowGroup.style.display = 'block';
        }
        else if (smoothingMethod === 'rms_window') {
            var smoothingFormula = 'y[n] = sign(mu) * sqrt((1/M) * sum_{k=0..M-1}(x[n-k]^2)), mu=(1/M)sum(x)';
            this.liveSmoothingFormulaEl.innerText = smoothingFormula;
            this.smoothingWindowGroup.style.display = 'block';
        }
        else if (smoothingMethod === 'true_rms_window') {
            var smoothingFormula = 'y[n] = sign(mu) * true_rms(x), mu=(1/M)sum(x)';
            this.liveSmoothingFormulaEl.innerText = smoothingFormula;
            this.smoothingWindowGroup.style.display = 'block';
        }
        else {
            var smoothingFormula = 'y[n] = alpha * x[n] + (1 - alpha) * y[n-1]';
            this.liveSmoothingFormulaEl.innerText = smoothingFormula;
            this.smoothingAlphaGroup.style.display = 'block';
        }
        this.liveSmoothingEvalEl.innerText = this.lastSmoothingEvaluationText;
    };
    // ----------------------------
    // Module: Runtime Loops
    // ----------------------------
    App.prototype.updateDiagnosticsPlot = function () {
        var _this = this;
        this.connector.getAdcDualData(function (in1Raw, in2Raw) {
            _this.connector.getDecimatedDacDataChannel(0, function (out1Indexed) {
                _this.connector.getDecimatedDacDataChannel(1, function (out2Indexed) {
                    var nRaw = Math.max(0, Math.min(in1Raw.length, in2Raw.length));
                    var frameStartUs = _this.runningPlotFrameStartUs;
                    var frameSpanUs = _this.sampleIndexToMicroseconds(Math.max(1, nRaw - 1));
                    var frameEndUs = frameStartUs + frameSpanUs;
                    var plotMaxPoints = _this.getPlotMaxPoints();
                    var plotDecimation = _this.getPlotDecimationMethod();
                    var decimated = _this.buildDecimatedDualIndexedSeries(in1Raw, in2Raw, plotDecimation, plotMaxPoints);
                    var in1 = _this.sampleIndexPointsToTimeUs(decimated.in1, frameStartUs);
                    var in2 = _this.sampleIndexPointsToTimeUs(decimated.in2, frameStartUs);
                    _this.adcRawSize = Math.max(1, nRaw);
                    _this.latestIn1Plot = in1;
                    _this.latestIn2Plot = in2;
                    _this.latestIn1 = in1Raw.slice(0, nRaw);
                    _this.latestIn2 = in2Raw.slice(0, nRaw);
                    _this.out1Plot = _this.sampleIndexPointsToTimeUs(out1Indexed, frameStartUs);
                    _this.out2Plot = _this.sampleIndexPointsToTimeUs(out2Indexed, frameStartUs);
                    _this.out1Cache = _this.extractY(_this.out1Plot);
                    _this.out2Cache = _this.extractY(_this.out2Plot);
                    var result = _this.runPipeline(_this.latestIn1, _this.latestIn2, _this.out1Cache, _this.out2Cache);
                    _this.featureTraceValue = _this.sanitizeFinite(result.featureUsed);
                    _this.weightTraceValue = _this.sanitizeFinite(result.weightUsed);
                    var activeOffset = _this.getActiveCalibrationOffset();
                    _this.lastPipelineResult = result;
                    _this.lastActiveCalibrationOffset = activeOffset;
                    _this.weightEl.innerText = result.weightUsed.toFixed(3);
                    _this.scaleTareFeatureEl.innerText = _this.featureTare.toFixed(4);
                    _this.liveInputEl.innerText = _this.getPhase2InputLabel(_this.getPhase2InputMode());
                    _this.liveFeatureRawEl.innerText = result.featureRaw.toFixed(4);
                    _this.liveFeatureUsedEl.innerText = result.featureUsed.toFixed(4);
                    _this.liveFeatureTareEl.innerText = activeOffset.toFixed(4);
                    _this.liveKFactorEl.innerText =
                        _this.expCalibrationA.toFixed(4) + ', ' +
                            _this.expCalibrationBkg.toFixed(6) + ', ' +
                            _this.expCalibrationC.toFixed(4);
                    _this.liveWeightRawEl.innerText = result.weightRaw.toFixed(4);
                    _this.liveWeightUsedEl.innerText = result.weightUsed.toFixed(4);
                    _this.liveIqIEl.innerText = result.iqI.toFixed(4);
                    _this.liveIqQEl.innerText = result.iqQ.toFixed(4);
                    _this.lastIqI = result.iqI;
                    _this.lastIqQ = result.iqQ;
                    _this.liveIqAEl.innerText = result.iqA.toFixed(4);
                    _this.liveIqARefEl.innerText = result.iqARef.toFixed(4);
                    _this.liveIqANormEl.innerText = result.iqANorm.toFixed(4);
                    _this.liveIqRefPhaseEl.innerText = result.iqRefPhaseDeg.toFixed(2) + ' deg';
                    _this.liveIqI0El.innerText = _this.iqProjectionBaseI.toFixed(4);
                    _this.liveIqQ0El.innerText = _this.iqProjectionBaseQ.toFixed(4);
                    _this.liveCalibrationEvalEl.innerText = _this.buildCalibrationEvaluation(result.featureUsed, _this.getPhase4CalibrationMode());
                    _this.liveSmoothingEvalEl.innerText = _this.lastSmoothingEvaluationText;
                    var featureSeries = _this.buildConstantSeries(_this.latestIn1Plot.length, _this.featureTraceValue);
                    var featureSeriesNeg = _this.buildConstantSeries(_this.latestIn1Plot.length, -_this.featureTraceValue);
                    var weightSeries = _this.buildConstantSeries(_this.latestIn1Plot.length, _this.weightTraceValue);
                    var featurePlot = _this.mapSeriesToReferenceX(_this.latestIn1Plot, featureSeries);
                    var featurePlotNeg = _this.mapSeriesToReferenceX(_this.latestIn1Plot, featureSeriesNeg);
                    var weightPlot = _this.mapSeriesToReferenceX(_this.latestIn1Plot, weightSeries);
                    var adcStep = Math.max(1, decimated.step);
                    var dacStep = Math.max(1, _this.dacDecimationStep);
                    var range = {
                        from: frameStartUs,
                        to: frameEndUs
                    };
                    _this.lastPlotRangeUs = range;
                    var nPlotEstimate = _this.latestIn1Plot.length;
                    var series = [];
                    var featureLabel = _this.getFeatureSeriesLabel();
                    var featureLegend = 'Feature (' + featureLabel + ')';
                    var allSeries = {
                        in1: { label: 'IN1', data: _this.latestIn1Plot, color: '#1f77b4' },
                        in2: { label: 'IN2', data: _this.latestIn2Plot, color: '#ff7f0e' },
                        out1: { label: 'OUT1', data: _this.out1Plot, color: '#2ca02c' },
                        out2: { label: 'OUT2', data: _this.out2Plot, color: '#d62728' },
                        weight: { label: 'Weight', data: weightPlot, color: '#8c564b' }
                    };
                    for (var key in allSeries) {
                        if (!_this.curveVisible[key]) {
                            continue;
                        }
                        series.push(allSeries[key]);
                    }
                    if (_this.curveVisible.feature) {
                        series.push({ label: featureLegend + ' (+)', data: featurePlot, color: '#9467bd' });
                        series.push({ label: featureLegend + ' (-)', data: featurePlotNeg, color: '#9467bd' });
                    }
                    _this.livePlotDecimationEl.innerText =
                        'Method=' + _this.getPlotDecimationMethodLabel(plotDecimation) +
                            ', N_raw=' + _this.adcRawSize.toString() +
                            ', step_drv=' + adcStep.toString() +
                            ', step_dac=' + dacStep.toString() +
                            ', N_plot_max=' + plotMaxPoints.toString() +
                            ', N_plot=' + nPlotEstimate.toString() +
                            ', X=running time';
                    _this.plotBasics.setRangeX(range.from, range.to);
                    _this.plotBasics.redrawSeries(series, range, function () {
                        requestAnimationFrame(function () { return _this.updateDiagnosticsPlot(); });
                    });
                    _this.liveRmsIn12El.innerText =
                        result.rmsIn1.toFixed(4) + ' / ' + result.rmsIn2.toFixed(4);
                    _this.liveRmsOut12El.innerText =
                        result.rmsOut1.toFixed(4) + ' / ' + result.rmsOut2.toFixed(4);
                    _this.runningPlotFrameStartUs = frameEndUs;
                });
            });
        });
    };
    // ----------------------------
    // Module: Signal Processing Core
    // ----------------------------
    App.prototype.runPipeline = function (in1, in2, out1, out2) {
        var rmsIn1 = this.computeRms(in1);
        var rmsIn2 = this.computeRms(in2);
        var rmsOut1 = this.computeRms(out1);
        var rmsOut2 = this.computeRms(out2);
        var feature = this.computeFeature(in1, in2);
        var featureRaw = feature.feature;
        var featureUsed = feature.feature;
        var calibrationMode = this.getPhase4CalibrationMode();
        var weightRaw = this.applyCalibration(featureUsed, calibrationMode);
        var weightUsed = this.applySmoothing(weightRaw);
        return {
            featureRaw: featureRaw,
            featureUsed: featureUsed,
            weightRaw: weightRaw,
            weightUsed: weightUsed,
            rmsIn1: rmsIn1,
            rmsIn2: rmsIn2,
            rmsOut1: rmsOut1,
            rmsOut2: rmsOut2,
            iqI: feature.iqI,
            iqQ: feature.iqQ,
            iqA: feature.iqA,
            iqARef: feature.iqARef,
            iqANorm: feature.iqANorm,
            iqRefPhaseDeg: feature.iqRefPhaseDeg
        };
    };
    App.prototype.computeFeature = function (in1, in2) {
        var n = Math.min(in1.length, in2.length);
        if (n <= 0) {
            return {
                feature: 0,
                iqI: 0,
                iqQ: 0,
                iqA: 0,
                iqARef: 0,
                iqANorm: 0,
                iqRefPhaseDeg: 0
            };
        }
        var count = Math.max(1, Math.min(this.getWindowSamples(), n));
        var method = this.getPhase3FeatureMethod();
        if (method === 'iq_in2') {
            // IQ demodulation is much more stable when the window spans an
            // integer number of reference periods.
            count = this.getIqCoherentWindowSamples(count, n);
            var start_1 = n - count;
            return this.computeIqFeatureIn2(in1, in2, start_1, count);
        }
        var start = n - count;
        var x = this.getInputSeriesForWindow(in1, in2, start, count, this.getPhase2InputMode());
        if (method === 'true_rms') {
            var value_1 = this.computeTrueRmsBalanced(x, 4000);
            return {
                feature: value_1,
                iqI: 0,
                iqQ: 0,
                iqA: 0,
                iqARef: 0,
                iqANorm: 0,
                iqRefPhaseDeg: 0
            };
        }
        var value = this.computeRms(x);
        return {
            feature: value,
            iqI: 0,
            iqQ: 0,
            iqA: 0,
            iqARef: 0,
            iqANorm: 0,
            iqRefPhaseDeg: 0
        };
    };
    App.prototype.computeIqFeatureIn2 = function (in1, in2, start, count) {
        var twoPiFOverFs = 2.0 * Math.PI * this.appliedFrequencyHz / this.sampleRateHz;
        var meanIn1 = this.computeMean(in1, start, count);
        var meanIn2 = this.computeMean(in2, start, count);
        var scale = 2.0 / Math.max(1, count);
        var accXSin = 0;
        var accXCos = 0;
        var accRSin = 0;
        var accRCos = 0;
        for (var i = 0; i < count; i++) {
            var idx = start + i;
            var theta = twoPiFOverFs * i;
            var sinTheta = Math.sin(theta);
            var cosTheta = Math.cos(theta);
            var x = in1[idx] - meanIn1;
            var r = in2[idx] - meanIn2;
            accXSin += x * sinTheta;
            accXCos += x * cosTheta;
            accRSin += r * sinTheta;
            accRCos += r * cosTheta;
        }
        var xI = scale * accXSin;
        var xQ = scale * accXCos;
        var rI = scale * accRSin;
        var rQ = scale * accRCos;
        var refPhase = Math.atan2(rQ, rI);
        // Complex lock-in ratio: Z = X / R
        var den = rI * rI + rQ * rQ;
        var denSafe = Math.max(den, this.iqNormalizationEpsilon * this.iqNormalizationEpsilon);
        var iqI = (xI * rI + xQ * rQ) / denSafe;
        var iqQ = (xQ * rI - xI * rQ) / denSafe;
        var iqA = Math.sqrt(iqI * iqI + iqQ * iqQ);
        var iqARef = Math.sqrt(rI * rI + rQ * rQ);
        var iqANorm = iqA;
        if (!this.iqProjectionBaseInitialized) {
            this.iqProjectionBaseI = iqI;
            this.iqProjectionBaseQ = iqQ;
            this.iqProjectionBaseInitialized = true;
        }
        var baseI = this.iqProjectionBaseI;
        var baseQ = this.iqProjectionBaseQ;
        var baseMag = Math.sqrt(baseI * baseI + baseQ * baseQ);
        var uI = baseI / Math.max(baseMag, this.iqNormalizationEpsilon);
        var uQ = baseQ / Math.max(baseMag, this.iqNormalizationEpsilon);
        var deltaI = iqI - baseI;
        var deltaQ = iqQ - baseQ;
        var iqSProjRaw = -(deltaI * uI + deltaQ * uQ);
        var iqSProjUsed = iqSProjRaw;
        // Guard against unstable X/R updates when the reference is too weak.
        if (iqARef < this.appliedIqReferenceMinAmplitude) {
            iqSProjUsed = this.iqSProjHoldInitialized ? this.iqSProjHold : 0;
        }
        else {
            this.iqSProjHold = iqSProjRaw;
            this.iqSProjHoldInitialized = true;
        }
        return {
            feature: iqSProjUsed,
            iqI: iqI,
            iqQ: iqQ,
            iqA: iqA,
            iqARef: iqARef,
            iqANorm: iqANorm,
            iqRefPhaseDeg: refPhase * 180.0 / Math.PI
        };
    };
    App.prototype.getIqCoherentWindowSamples = function (requested, available) {
        var nAvail = Math.max(1, available);
        var fRef = Math.max(1.0, this.appliedFrequencyHz);
        var samplesPerPeriod = this.sampleRateHz / fRef;
        var requestedSamples = Math.max(1, Math.min(requested, nAvail));
        var requestedCycles = Math.max(1, Math.round(requestedSamples / samplesPerPeriod));
        var maxCycles = Math.max(1, Math.floor(nAvail / samplesPerPeriod));
        var cycles = Math.max(1, Math.min(requestedCycles, maxCycles));
        var coherentSamples = Math.max(1, Math.round(cycles * samplesPerPeriod));
        return Math.max(1, Math.min(coherentSamples, nAvail));
    };
    App.prototype.computeMean = function (values, start, count) {
        if (count <= 0) {
            return 0;
        }
        var sum = 0;
        for (var i = 0; i < count; i++) {
            sum += values[start + i];
        }
        return sum / count;
    };
    App.prototype.getInputSeriesForWindow = function (in1, in2, start, count, mode) {
        var x = new Array(count);
        var eps = this.getDivisionEpsilon();
        var clip = this.getDivisionClip();
        for (var i = 0; i < count; i++) {
            var idx = start + i;
            if (mode === 'in1' || mode === 'iq_pair') {
                x[i] = in1[idx];
            }
            else if (mode === 'in2') {
                x[i] = in2[idx];
            }
            else if (mode === 'in1_div_in2') {
                var denBase = in2[idx];
                var den = Math.abs(denBase) >= eps ? denBase : (denBase >= 0 ? eps : -eps);
                var ratio = in1[idx] / den;
                if (ratio > clip) {
                    ratio = clip;
                }
                else if (ratio < -clip) {
                    ratio = -clip;
                }
                x[i] = ratio;
            }
            else {
                x[i] = in1[idx] - in2[idx];
            }
        }
        return x;
    };
    // ----------------------------
    // Module: Post-Processing (Phase 5)
    // ----------------------------
    App.prototype.applySmoothing = function (weightRaw) {
        var method = this.getPhase5SmoothingMethod();
        if (method === 'none') {
            this.lastSmoothingEvaluationText = 'Off: y = x = ' + weightRaw.toFixed(4);
            return weightRaw;
        }
        if (method === 'moving_average') {
            var m = this.getSmoothingWindow();
            this.smoothingHistory.push(weightRaw);
            while (this.smoothingHistory.length > m) {
                this.smoothingHistory.shift();
            }
            var sum = 0;
            for (var i = 0; i < this.smoothingHistory.length; i++) {
                sum += this.smoothingHistory[i];
            }
            var y = sum / this.smoothingHistory.length;
            this.lastSmoothingEvaluationText =
                'y = (1/' +
                    this.smoothingHistory.length.toString() +
                    ') * sum = ' +
                    y.toFixed(4);
            return y;
        }
        if (method === 'rms_window') {
            var m = this.getSmoothingWindow();
            this.smoothingHistory.push(weightRaw);
            while (this.smoothingHistory.length > m) {
                this.smoothingHistory.shift();
            }
            var sumSq = 0;
            var sum = 0;
            for (var i = 0; i < this.smoothingHistory.length; i++) {
                var v = this.smoothingHistory[i];
                sumSq += v * v;
                sum += v;
            }
            var count = Math.max(1, this.smoothingHistory.length);
            var mu = sum / count;
            var rms = Math.sqrt(sumSq / count);
            var y = mu > 0 ? rms : (mu < 0 ? -rms : 0);
            this.lastSmoothingEvaluationText =
                'y = sign(mu=' +
                    mu.toFixed(4) +
                    ') * rms = ' +
                    y.toFixed(4);
            return y;
        }
        if (method === 'true_rms_window') {
            var m = this.getSmoothingWindow();
            this.smoothingHistory.push(weightRaw);
            while (this.smoothingHistory.length > m) {
                this.smoothingHistory.shift();
            }
            var targetPerSide = Math.max(1, Math.floor(this.smoothingHistory.length / 2));
            var sum = 0;
            for (var i = 0; i < this.smoothingHistory.length; i++) {
                sum += this.smoothingHistory[i];
            }
            var count = Math.max(1, this.smoothingHistory.length);
            var mu = sum / count;
            var trms = this.computeTrueRmsBalanced(this.smoothingHistory, targetPerSide);
            var y = mu > 0 ? trms : (mu < 0 ? -trms : 0);
            this.lastSmoothingEvaluationText =
                'y = sign(mu=' +
                    mu.toFixed(4) +
                    ') * true_rms(M=' +
                    this.smoothingHistory.length.toString() +
                    ', N_side=' +
                    targetPerSide.toString() +
                    ') = ' +
                    y.toFixed(4);
            return y;
        }
        var alpha = this.getSmoothingAlpha();
        if (!this.emaInitialized) {
            this.emaWeight = weightRaw;
            this.emaInitialized = true;
            this.lastSmoothingEvaluationText = 'EMA init: y = x = ' + weightRaw.toFixed(4);
        }
        else {
            var prev = this.emaWeight;
            this.emaWeight = alpha * weightRaw + (1 - alpha) * this.emaWeight;
            this.lastSmoothingEvaluationText =
                'y = ' +
                    alpha.toFixed(3) +
                    ' * ' +
                    weightRaw.toFixed(4) +
                    ' + ' +
                    (1 - alpha).toFixed(3) +
                    ' * ' +
                    prev.toFixed(4) +
                    ' = ' +
                    this.emaWeight.toFixed(4);
        }
        return this.emaWeight;
    };
    App.prototype.resetSmoothingState = function () {
        this.smoothingHistory = [];
        this.emaWeight = 0;
        this.emaInitialized = false;
        this.lastSmoothingEvaluationText = 'Off';
    };
    // ----------------------------
    // Module: Workflow Selection + Parameters
    // ----------------------------
    App.prototype.getPhase2InputMode = function () {
        return this.appliedPhase2Input;
    };
    App.prototype.getPhase3FeatureMethod = function () {
        return this.appliedPhase3Feature;
    };
    App.prototype.getPhase4CalibrationMode = function () {
        return this.appliedPhase4Calibration;
    };
    App.prototype.getPhase5SmoothingMethod = function () {
        return this.appliedPhase5Smoothing;
    };
    App.prototype.getPlotDecimationMethod = function () {
        var method = this.plotDecimationMethodSelect.value;
        if (method === 'none' || method === 'stride' || method === 'minmax' || method === 'mean') {
            return method;
        }
        return 'stride';
    };
    App.prototype.applyDriverDecimationSettings = function () {
        var _this = this;
        var method = this.getPlotDecimationMethod();
        var maxPoints = this.getPlotMaxPoints();
        var modeValue = this.getDriverDecimationModeValue(method);
        this.connector.setPlotDecimation(modeValue, maxPoints);
        this.connector.getAdcSize(function (size) {
            _this.adcRawSize = Math.max(1, Math.round(size));
        });
        this.connector.getAdcDecimationStep(function (step) {
            _this.adcDecimationStep = Math.max(1, Math.round(step));
        });
        this.connector.getDacDecimationStep(function (step) {
            _this.dacDecimationStep = Math.max(1, Math.round(step));
        });
    };
    App.prototype.getDriverDecimationModeValue = function (method) {
        if (method === 'none')
            return 0;
        if (method === 'stride')
            return 1;
        if (method === 'minmax')
            return 2;
        return 3;
    };
    // ----------------------------
    // Module: Calibration Mapping (Phase 4)
    // ----------------------------
    App.prototype.usesTare = function (mode) {
        return mode === 'tare_only' || mode === 'tare_scale';
    };
    App.prototype.usesScaleFactor = function (mode) {
        return mode === 'scale_only' || mode === 'tare_scale';
    };
    App.prototype.getActiveCalibrationOffset = function () {
        if (this.getPhase3FeatureMethod() === 'iq_in2') {
            // In IQ mode the zero offset is embedded in I0/Q0, feature-domain offset is 0.
            return 0;
        }
        return this.featureTare;
    };
    App.prototype.applyCalibration = function (featureUsed, mode) {
        var offset = this.getActiveCalibrationOffset();
        if (mode === 'off') {
            return featureUsed;
        }
        if (mode === 'tare_only') {
            return featureUsed - offset;
        }
        if (mode === 'scale_only') {
            return this.computeExponentialWeightFromFeature(featureUsed).weightKg;
        }
        var featureForScale = featureUsed - offset;
        return this.computeExponentialWeightFromFeature(featureForScale).weightKg;
    };
    App.prototype.buildCalibrationEvaluation = function (featureUsed, mode) {
        var offset = this.getActiveCalibrationOffset();
        if (mode === 'off') {
            return 'Weight = Feature = ' + featureUsed.toFixed(4);
        }
        if (mode === 'tare_only') {
            var result = featureUsed - offset;
            return 'Weight = ' + featureUsed.toFixed(4) + ' - ' + offset.toFixed(4) + ' = ' + result.toFixed(4);
        }
        if (mode === 'scale_only') {
            var exp_1 = this.computeExponentialWeightFromFeature(featureUsed);
            var ratio_1 = (featureUsed - this.expCalibrationC) / this.expCalibrationA;
            var ratioText_1 = Math.max(ratio_1, this.expCalibrationArgumentEpsilon).toFixed(6);
            if (exp_1.clamped) {
                return 'Weight_kg = ln(' + ratioText_1 + ') / ' + this.expCalibrationBkg.toFixed(6) + ' -> clamped to 0.0000';
            }
            return 'Weight_kg = ln(' + ratioText_1 + ') / ' + this.expCalibrationBkg.toFixed(6) + ' = ' + exp_1.weightKg.toFixed(4);
        }
        var featureForScale = featureUsed - offset;
        var exp = this.computeExponentialWeightFromFeature(featureForScale);
        var ratio = (featureForScale - this.expCalibrationC) / this.expCalibrationA;
        var ratioText = Math.max(ratio, this.expCalibrationArgumentEpsilon).toFixed(6);
        if (exp.clamped) {
            return 'Weight_kg = ln(' + ratioText + ') / ' + this.expCalibrationBkg.toFixed(6) + ' (from Feature-Offset) -> clamped to 0.0000';
        }
        return 'Weight_kg = ln(' + ratioText + ') / ' + this.expCalibrationBkg.toFixed(6) + ' (from Feature-Offset) = ' + exp.weightKg.toFixed(4);
    };
    App.prototype.updateCalibrationUiState = function () {
        var mode = this.getPhase4CalibrationMode();
        var tareEnabled = this.usesTare(mode);
        var scaleEnabled = this.usesScaleFactor(mode);
        this.tareBtn.disabled = !tareEnabled;
        this.weightUnitEl.innerText = scaleEnabled ? 'kg' : 'feature';
    };
    // ----------------------------
    // Module: Numeric Parameter Readers
    // ----------------------------
    App.prototype.getWindowSamples = function () {
        return this.appliedWindowSamples;
    };
    App.prototype.getSmoothingWindow = function () {
        return this.appliedSmoothingWindow;
    };
    App.prototype.getSmoothingAlpha = function () {
        return this.appliedSmoothingAlpha;
    };
    App.prototype.getPlotMaxPoints = function () {
        var parsed = this.parseNumber(this.plotMaxPointsInput.value, 2048);
        return Math.max(128, Math.min(20000, Math.round(parsed)));
    };
    App.prototype.getDivisionEpsilon = function () {
        return this.appliedDivisionEpsilon;
    };
    App.prototype.getDivisionClip = function () {
        return this.appliedDivisionClip;
    };
    // ----------------------------
    // Module: Formula Builder + Clamp Rules
    // ----------------------------
    App.prototype.getPhase2InputFormula = function (mode, epsilon, clip) {
        if (mode === 'in1') {
            return 'x[i] = IN1_V[i]';
        }
        if (mode === 'in2') {
            return 'x[i] = IN2_V[i]';
        }
        if (mode === 'iq_pair') {
            return 'x[i] = IN1_V[i], r[i] = IN2_V[i] (IQ pair)';
        }
        if (mode === 'in1_minus_in2') {
            return 'x[i] = IN1_V[i] - IN2_V[i]';
        }
        return ('x[i] = clip(IN1_V[i] / den_safe[i], +/-' +
            clip.toFixed(3) +
            '), den_safe[i] = sign(IN2_V[i]) * max(|IN2_V[i]|, ' +
            epsilon.toFixed(6) +
            ')');
    };
    App.prototype.clampFrequencyHz = function (frequencyHz) {
        return Math.max(1.0, Math.min(this.signalSourceMaxFrequencyHz, frequencyHz));
    };
    App.prototype.clampAmplitudeVpp = function (amplitudeVpp) {
        return Math.max(0.0, Math.min(this.signalSourceMaxAmplitudeVpp, amplitudeVpp));
    };
    App.prototype.clampWindowSamples = function (samples) {
        return Math.max(8000, Math.min(16384, Math.round(samples)));
    };
    App.prototype.clampIqReferenceMinAmplitude = function (amplitude) {
        return Math.max(0.0, Math.min(5.0, amplitude));
    };
    App.prototype.clampSmoothingWindow = function (samples) {
        return Math.max(1, Math.min(100, Math.round(samples)));
    };
    App.prototype.clampSmoothingAlpha = function (alpha) {
        return Math.max(0.01, Math.min(1.0, alpha));
    };
    App.prototype.clampDivisionEpsilon = function (epsilon) {
        return Math.max(0.000001, Math.min(5.0, epsilon));
    };
    App.prototype.clampDivisionClip = function (clip) {
        return Math.max(0.1, Math.min(1000000.0, clip));
    };
    // ----------------------------
    // Module: Math Helpers
    // ----------------------------
    App.prototype.computeRms = function (values) {
        if (values.length === 0) {
            return 0;
        }
        var sum = 0;
        for (var i = 0; i < values.length; i++) {
            sum += values[i] * values[i];
        }
        return Math.sqrt(sum / values.length);
    };
    App.prototype.computeTrueRmsBalanced = function (values, targetPerSide) {
        if (values.length === 0) {
            return 0;
        }
        var positive = [];
        var negative = [];
        for (var i = 0; i < values.length; i++) {
            if (values[i] >= 0 && positive.length < targetPerSide) {
                positive.push(values[i]);
            }
            else if (values[i] < 0 && negative.length < targetPerSide) {
                negative.push(values[i]);
            }
            if (positive.length >= targetPerSide && negative.length >= targetPerSide) {
                break;
            }
        }
        var merged = positive.concat(negative);
        if (merged.length === 0) {
            return 0;
        }
        var sumSq = 0;
        for (var i = 0; i < merged.length; i++) {
            sumSq += merged[i] * merged[i];
        }
        return Math.sqrt(sumSq / merged.length);
    };
    App.prototype.buildConstantSeries = function (length, value) {
        var n = Math.max(0, length);
        var result = new Array(n);
        for (var i = 0; i < n; i++) {
            result[i] = value;
        }
        return result;
    };
    App.prototype.sanitizeFinite = function (value) {
        if (Number.isFinite(value)) {
            return value;
        }
        return 0;
    };
    App.prototype.buildDecimatedDualIndexedSeries = function (in1, in2, method, maxPoints) {
        var n = Math.max(0, Math.min(in1.length, in2.length));
        var out1 = [];
        var out2 = [];
        if (n <= 0) {
            return { in1: out1, in2: out2, step: 1 };
        }
        var clampedMax = Math.max(1, maxPoints);
        var pushAtIndex = function (idx) {
            out1.push([idx, in1[idx]]);
            out2.push([idx, in2[idx]]);
        };
        if (method === 'none') {
            for (var i = 0; i < n; i++) {
                pushAtIndex(i);
            }
            return { in1: out1, in2: out2, step: 1 };
        }
        if (method === 'stride') {
            var step_1 = Math.max(1, Math.ceil(n / clampedMax));
            for (var i = 0; i < n; i += step_1) {
                pushAtIndex(i);
            }
            return { in1: out1, in2: out2, step: step_1 };
        }
        if (method === 'mean') {
            var step_2 = Math.max(1, Math.ceil(n / clampedMax));
            for (var start = 0; start < n; start += step_2) {
                var end = Math.min(n, start + step_2);
                var sum1 = 0;
                var sum2 = 0;
                for (var i = start; i < end; i++) {
                    sum1 += in1[i];
                    sum2 += in2[i];
                }
                var denom = Math.max(1, end - start);
                out1.push([start, sum1 / denom]);
                out2.push([start, sum2 / denom]);
            }
            return { in1: out1, in2: out2, step: step_2 };
        }
        var targetBuckets = Math.max(1, Math.floor(clampedMax / 2));
        var step = Math.max(1, Math.ceil(n / targetBuckets));
        for (var start = 0; start < n; start += step) {
            var end = Math.min(n, start + step);
            var minIdx = start;
            var maxIdx = start;
            var minVal = in1[start];
            var maxVal = in1[start];
            for (var i = start + 1; i < end; i++) {
                if (in1[i] < minVal) {
                    minVal = in1[i];
                    minIdx = i;
                }
                if (in1[i] > maxVal) {
                    maxVal = in1[i];
                    maxIdx = i;
                }
            }
            if (minIdx === maxIdx) {
                pushAtIndex(minIdx);
            }
            else if (minIdx < maxIdx) {
                pushAtIndex(minIdx);
                pushAtIndex(maxIdx);
            }
            else {
                pushAtIndex(maxIdx);
                pushAtIndex(minIdx);
            }
        }
        return { in1: out1, in2: out2, step: step };
    };
    App.prototype.sampleIndexPointsToTimeUs = function (points, offsetUs) {
        if (offsetUs === void 0) { offsetUs = 0; }
        var out = new Array(points.length);
        for (var i = 0; i < points.length; i++) {
            out[i] = [offsetUs + this.sampleIndexToMicroseconds(points[i][0]), points[i][1]];
        }
        return out;
    };
    App.prototype.extractY = function (points) {
        var values = new Array(points.length);
        for (var i = 0; i < points.length; i++) {
            values[i] = points[i][1];
        }
        return values;
    };
    App.prototype.mapSeriesToReferenceX = function (reference, values) {
        var n = Math.min(reference.length, values.length);
        var points = new Array(n);
        for (var i = 0; i < n; i++) {
            points[i] = [reference[i][0], values[i]];
        }
        return points;
    };
    App.prototype.sampleIndexToMicroseconds = function (sampleIndex) {
        return (sampleIndex / this.sampleRateHz) * 1e6;
    };
    // ----------------------------
    // Module: Parsing + UI Label Helpers
    // ----------------------------
    App.prototype.parseNumber = function (raw, fallback) {
        var parsed = this.parseLocalizedNumber(raw);
        if (parsed === null) {
            return fallback;
        }
        return parsed;
    };
    App.prototype.parseLocalizedNumber = function (raw) {
        var trimmed = (raw || '').trim();
        if (trimmed.length === 0) {
            return null;
        }
        var numberLike = trimmed.replace(/[^0-9,.\-+]/g, '');
        if (numberLike.length === 0) {
            return null;
        }
        var hasComma = numberLike.indexOf(',') >= 0;
        var hasDot = numberLike.indexOf('.') >= 0;
        var normalized = numberLike;
        if (hasComma && hasDot) {
            // Supports formats like 1.234,56 and 1,234.56
            var lastComma = normalized.lastIndexOf(',');
            var lastDot = normalized.lastIndexOf('.');
            if (lastComma > lastDot) {
                normalized = normalized.replace(/\./g, '').replace(',', '.');
            }
            else {
                normalized = normalized.replace(/,/g, '');
            }
        }
        else if (hasComma) {
            normalized = normalized.replace(',', '.');
        }
        var parsed = parseFloat(normalized);
        if (isNaN(parsed)) {
            return null;
        }
        return parsed;
    };
    App.prototype.parseSignalSourceAmplitudeVpp = function (raw, fallback) {
        var parsed = this.parseNumber(raw, fallback);
        var normalized = raw.toLowerCase();
        if (normalized.indexOf('vpp') >= 0) {
            return parsed;
        }
        if (normalized.indexOf('vpk') >= 0) {
            return parsed * 2.0;
        }
        return parsed;
    };
    App.prototype.parseSignalSourceFrequencyHz = function (raw, fallback) {
        var parsed = this.parseNumber(raw, fallback);
        var normalized = raw.toLowerCase();
        if (normalized.indexOf('khz') >= 0) {
            return parsed * 1000.0;
        }
        if (normalized.indexOf('mhz') >= 0) {
            return parsed * 1000000.0;
        }
        return parsed;
    };
    App.prototype.formatFrequencyInputValue = function (frequencyHz) {
        return (frequencyHz / 1000.0).toFixed(3) + ' kHz';
    };
    App.prototype.formatAmplitudeInputValue = function (amplitudeVpp) {
        return amplitudeVpp.toFixed(3) + ' Vpp';
    };
    App.prototype.getFeatureSeriesLabel = function () {
        var method = this.getPhase3FeatureMethod();
        if (method === 'true_rms')
            return 'True RMS';
        if (method === 'iq_in2')
            return 'IQ Sproj';
        return 'RMS';
    };
    App.prototype.getSeriesKeyFromLabel = function (label) {
        if (label === 'IN1')
            return 'in1';
        if (label === 'IN2')
            return 'in2';
        if (label === 'OUT1')
            return 'out1';
        if (label === 'OUT2')
            return 'out2';
        if (label === 'RMS' ||
            label === 'True RMS' ||
            label === 'IQ Sproj' ||
            label.indexOf('RMS (+)') === 0 ||
            label.indexOf('RMS (-)') === 0 ||
            label.indexOf('True RMS (+)') === 0 ||
            label.indexOf('True RMS (-)') === 0 ||
            label.indexOf('IQ Sproj (+)') === 0 ||
            label.indexOf('IQ Sproj (-)') === 0 ||
            label === 'Feature' ||
            label.indexOf('Feature (') === 0)
            return 'feature';
        if (label === 'Weight')
            return 'weight';
        return null;
    };
    App.prototype.setCheckboxFromKey = function (document, key, checked) {
        var elementMap = {
            in1: 'curve-in1',
            in2: 'curve-in2',
            out1: 'curve-out1',
            out2: 'curve-out2',
            feature: 'curve-feature',
            weight: 'curve-weight'
        };
        var elementId = elementMap[key];
        if (!elementId) {
            return;
        }
        var checkbox = document.getElementById(elementId);
        if (checkbox) {
            checkbox.checked = checked;
        }
    };
    App.prototype.getOutputChannelLabel = function (outputChannel) {
        if (outputChannel === 0)
            return 'OUT1';
        if (outputChannel === 1)
            return 'OUT2';
        return 'OUT1 + OUT2';
    };
    App.prototype.getPlotDecimationMethodLabel = function (method) {
        if (method === 'none')
            return 'Off (1:1)';
        if (method === 'stride')
            return 'Stride';
        if (method === 'minmax')
            return 'Min/Max envelope';
        return 'Mean Bucket';
    };
    App.prototype.getPhase2InputLabel = function (mode) {
        if (mode === 'in1')
            return 'IN1';
        if (mode === 'in2')
            return 'IN2';
        if (mode === 'iq_pair')
            return 'IQ pair (IN1 signal + IN2 ref)';
        if (mode === 'in1_div_in2')
            return 'IN1 / IN2';
        return 'IN1 - IN2';
    };
    return App;
}());
var app = new App(window, document, location.hostname, $('#plot-placeholder'));
// ----------------------------
// Module: Frontend Driver Connector
// ----------------------------
var Connector = /** @class */ (function () {
    // ----------------------------
    // Module: Initialization
    // ----------------------------
    function Connector(client) {
        this.client = client;
        this.driver = this.client.getDriver('AdcDacBram');
        this.cmds = this.driver.getCmds();
        this.client.send(Command(this.driver.id, this.cmds['set_dac_function'], 1, 100000.0));
        this.client.send(Command(this.driver.id, this.cmds['set_output_channel'], 2));
        this.client.send(Command(this.driver.id, this.cmds['set_dac_amplitude'], 0.5));
    }
    // ----------------------------
    // Module: DAC Control Commands
    // ----------------------------
    Connector.prototype.setFunction = function (data, freq) {
        this.client.send(Command(this.driver.id, this.cmds['set_dac_function'], data, freq));
    };
    Connector.prototype.setOutputChannel = function (channel) {
        this.client.send(Command(this.driver.id, this.cmds['set_output_channel'], channel));
    };
    Connector.prototype.setAmplitude = function (amplitudeVpk) {
        this.client.send(Command(this.driver.id, this.cmds['set_dac_amplitude'], amplitudeVpk));
    };
    Connector.prototype.setPlotDecimation = function (mode, maxPoints) {
        this.client.send(Command(this.driver.id, this.cmds['set_plot_decimation'], mode, maxPoints));
    };
    // ----------------------------
    // Module: Driver Measurement Reads
    // ----------------------------
    Connector.prototype.getAdcRmsData = function (nSamples, callback) {
        this.client.readTuple(Command(this.driver.id, this.cmds['get_adc_rms_data'], nSamples), 'ff', function (tup) { return callback(tup[0], tup[1]); });
    };
    Connector.prototype.getAdcTrueRmsData = function (callback) {
        this.client.readTuple(Command(this.driver.id, this.cmds['get_adc_true_rms_data']), 'ffii', function (tup) { return callback(tup[0], tup[1], tup[2], tup[3]); });
    };
    // ----------------------------
    // Module: Driver Metadata Reads
    // ----------------------------
    Connector.prototype.getAdcSize = function (callback) {
        this.client.readUint32(Command(this.driver.id, this.cmds['get_adc_size']), function (x) { return callback(x); });
    };
    Connector.prototype.getAdcDecimationStep = function (callback) {
        this.client.readUint32(Command(this.driver.id, this.cmds['get_adc_decimation_step']), function (x) { return callback(x); });
    };
    Connector.prototype.getDacDecimationStep = function (callback) {
        this.client.readUint32(Command(this.driver.id, this.cmds['get_dac_decimation_step']), function (x) { return callback(x); });
    };
    // ----------------------------
    // Module: ADC/DAC Waveform Reads for Plotting
    // ----------------------------
    Connector.prototype.getAdcDualData = function (callback) {
        var _this = this;
        this.client.readFloat32Vector(Command(this.driver.id, this.cmds['get_adc_dual_data']), function (array) {
            var pair = _this.parseInterleavedPairSeries(array);
            callback(pair[0], pair[1]);
        });
    };
    Connector.prototype.getDecimatedDacDataChannel = function (channel, callback) {
        var _this = this;
        this.client.readFloat32Vector(Command(this.driver.id, this.cmds['get_decimated_dac_data_xy'], channel), function (array) { return callback(_this.parseInterleavedXY(array)); });
    };
    Connector.prototype.parseInterleavedXY = function (array) {
        var n = Math.floor(array.length / 2);
        var points = new Array(n);
        for (var i = 0; i < n; i++) {
            points[i] = [array[2 * i], array[2 * i + 1]];
        }
        return points;
    };
    Connector.prototype.parseInterleavedPairSeries = function (array) {
        var n = Math.floor(array.length / 2);
        var in1 = new Array(n);
        var in2 = new Array(n);
        for (var i = 0; i < n; i++) {
            in1[i] = array[2 * i];
            in2[i] = array[2 * i + 1];
        }
        return [in1, in2];
    };
    return Connector;
}());
// Plot widget
// (c) Koheron
var PlotBasics = /** @class */ (function () {
    function PlotBasics(document, plot_placeholder, n_pts, x_min, x_max, y_min, y_max, driver, rangeFunction, plotTitle) {
        this.plot_placeholder = plot_placeholder;
        this.n_pts = n_pts;
        this.x_min = x_min;
        this.x_max = x_max;
        this.y_min = y_min;
        this.y_max = y_max;
        this.driver = driver;
        this.rangeFunction = rangeFunction;
        this.plotTitle = plotTitle;
        this.isPeakDetection = true;
        this.plotTitleSpan = document.getElementById("plot-title");
        if (this.plotTitle.length > 0) {
            this.plotTitleSpan.textContent = this.plotTitle;
            this.plotTitleSpan.style.display = "block";
        }
        else {
            this.plotTitleSpan.style.display = "none";
        }
        ;
        this.range_x = {};
        this.range_x.from = this.x_min;
        this.range_x.to = this.x_max;
        this.range_y = {};
        this.range_y.from = this.y_min;
        this.range_y.to = this.y_max;
        this.log_y = false;
        this.setPlot(this.range_x.from, this.range_x.to, this.range_y.from, this.range_y.to);
        this.rangeSelect(this.rangeFunction);
        this.dblClick(this.rangeFunction);
        this.onWheel(this.rangeFunction);
        this.showHoverPoint();
        this.showClickPoint();
        this.plotLeave();
        this.reset_range = true;
        this.hoverDatapointSpan = document.getElementById("hover-datapoint");
        this.hoverDatapoint = [];
        this.clickDatapointSpan = document.getElementById("click-datapoint");
        this.clickDatapoint = [];
        this.peakDatapointSpan = document.getElementById("peak-datapoint");
        this.plot_data = [];
        this.LogYaxisFormatter = function (val, axis) { };
        this.initUnitInputs();
        this.initPeakDetection();
    }
    PlotBasics.prototype.setPlot = function (x_min, x_max, y_min, y_max) {
        this.reset_range = false;
        this.options = {
            canvas: true,
            series: {
                shadowSize: 0 // Drawing is faster without shadows
            },
            yaxis: {
                min: y_min,
                max: y_max
            },
            xaxis: {
                min: x_min,
                max: x_max,
                show: true
            },
            grid: {
                margin: {
                    top: 0,
                    left: 0,
                },
                borderColor: "#d5d5d5",
                borderWidth: 1,
                clickable: true,
                hoverable: true,
                autoHighlight: true
            },
            selection: {
                mode: "xy"
            },
            colors: ["#019cd5", "#006400"],
            legend: {
                show: true,
                noColumns: 0,
                labelFormatter: function (label, series) {
                    return "<b style='font-size: 16px; color: #333'>" + label + "\t</b>";
                },
                margin: 0,
                position: "ne",
            }
        };
        // Axis labels are rendered by jquery.flot.axislabels.js.
        this.options.yaxis.axisLabel = "Spannung [V]";
        this.options.xaxis.axisLabel = "Zeit [us]";
    };
    PlotBasics.prototype.rangeSelect = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("plotselected", function (event, ranges) {
            // Clamp the zooming to prevent external zoom
            if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
                ranges.xaxis.to = ranges.xaxis.from + 0.00001;
            }
            if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
                ranges.yaxis.to = ranges.yaxis.from + 0.00001;
            }
            _this.range_x.from = ranges.xaxis.from;
            _this.range_x.to = ranges.xaxis.to;
            _this.range_y.from = ranges.yaxis.from;
            _this.range_y.to = ranges.yaxis.to;
            if (rangeFunction.length > 0) {
                _this.driver[rangeFunction](ranges.xaxis);
            }
            _this.reset_range = true;
        });
    };
    // A double click on the plot resets to full span
    PlotBasics.prototype.dblClick = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("dblclick", function (evt) {
            _this.range_x.from = _this.x_min;
            _this.range_x.to = _this.x_max;
            _this.range_y = {};
            if (rangeFunction.length > 0) {
                _this.driver[rangeFunction](_this.range_x);
            }
            _this.reset_range = true;
        });
    };
    PlotBasics.prototype.setRangeX = function (from, to) {
        this.range_x.from = from;
        this.range_x.to = to;
        this.reset_range = true;
    };
    PlotBasics.prototype.resetView = function (xFrom, xTo) {
        this.range_x.from = (xFrom !== undefined) ? xFrom : this.x_min;
        this.range_x.to = (xTo !== undefined) ? xTo : this.x_max;
        this.range_y.from = this.y_min;
        this.range_y.to = this.y_max;
        this.reset_range = true;
    };
    PlotBasics.prototype.updateDatapointSpan = function (datapoint, datapointSpan) {
        var positionX = (this.plot.pointOffset({ x: datapoint[0], y: datapoint[1] })).left;
        var positionY = (this.plot.pointOffset({ x: datapoint[0], y: datapoint[1] })).top;
        datapointSpan.innerHTML = "(" + (datapoint[0].toFixed(2)).toString() + "," + datapoint[1].toFixed(2).toString() + ")";
        if (datapoint[0] < (this.range_x.from + this.range_x.to) / 2) {
            datapointSpan.style.left = (positionX + 5).toString() + "px";
        }
        else {
            datapointSpan.style.left = (positionX - 140).toString() + "px";
        }
        if (datapoint[1] < ((this.range_y.from + this.range_y.to) / 2)) {
            datapointSpan.style.top = (positionY - 50).toString() + "px";
        }
        else {
            datapointSpan.style.top = (positionY + 5).toString() + "px";
        }
    };
    PlotBasics.prototype.redraw = function (plot_data, n_pts, peakDatapoint, ylabel, callback) {
        var _this = this;
        var plt_data = [{ label: ylabel, data: plot_data }];
        if (this.reset_range) {
            if (this.log_y) {
                // /!\ Cannot set ticks lower than 1 /!\
                this.options.yaxis.ticks = [1, 10, 100, 1E3, 1E4, 1E5, 1E6, 1E7, 1E8, 1E9];
                this.options.yaxis.tickDecimals = 0;
                this.options.yaxis.transform = function (v) { return v > 0 ? Math.log10(v) : null; };
                this.options.yaxis.inverseTransform = function (v) { return v != null ? Math.pow(10, v) : 0.0; };
                this.options.yaxis.tickFormatter = this.LogYaxisFormatter;
            }
            else {
                this.options.yaxis = {
                    min: this.range_y.from,
                    max: this.range_y.to
                };
            }
            this.options.xaxis.min = this.range_x.from;
            this.options.xaxis.max = this.range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.range_y.from = this.plot.getAxes().yaxis.min;
            this.range_y.to = this.plot.getAxes().yaxis.max;
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        var localData = this.plot.getData();
        setTimeout(function () { _this.plot.unhighlight(); }, 100);
        if (this.clickDatapoint.length > 0) {
            var i = void 0;
            for (i = 0; i < plot_data.length; i++) {
                if (localData[0]['data'][i][0] > this.clickDatapoint[0]) {
                    break;
                }
            }
            var p1 = localData[0]['data'][i - 1];
            var p2 = localData[0]['data'][i];
            if ((p1 === null) || (p1 === undefined)) {
                this.clickDatapoint[1] = p2[1];
            }
            else if ((p2 === null) || (p2 === undefined)) {
                this.clickDatapoint[1] = p1[1];
            }
            else {
                this.clickDatapoint[1] = p1[1] + (p2[1] - p1[1]) * (this.clickDatapoint[0] - p1[0]) / (p2[0] - p1[0]);
            }
            if (this.range_x.from < this.clickDatapoint[0] && this.clickDatapoint[0] < this.range_x.to
                && this.range_y.from < this.clickDatapoint[1] && this.clickDatapoint[1] < this.range_y.to) {
                this.updateDatapointSpan(this.clickDatapoint, this.clickDatapointSpan);
                this.clickDatapointSpan.style.display = "inline-block";
                this.plot.highlight(localData[0], this.clickDatapoint);
            }
            else {
                this.clickDatapointSpan.style.display = "none";
            }
        }
        if (this.isPeakDetection && peakDatapoint.length > 0) {
            for (var i = 0; i < plot_data.length; i++) {
                if (peakDatapoint[1] < plot_data[i][1]) {
                    peakDatapoint[0] = plot_data[i][0];
                    peakDatapoint[1] = plot_data[i][1];
                }
            }
            this.plot.unhighlight(localData[0], peakDatapoint);
            if (this.range_x.from < peakDatapoint[0] && peakDatapoint[0] < this.range_x.to
                && this.range_y.from < peakDatapoint[1] && peakDatapoint[1] < this.range_y.to) {
                this.updateDatapointSpan(peakDatapoint, this.peakDatapointSpan);
                this.plot.highlight(localData[0], peakDatapoint);
                this.peakDatapointSpan.style.display = "inline-block";
            }
            else {
                this.plot.unhighlight(localData[0], peakDatapoint);
                this.peakDatapointSpan.style.display = "none";
            }
        }
        else {
            this.plot.unhighlight(localData[0], peakDatapoint);
            this.peakDatapointSpan.style.display = "none";
        }
        callback();
    };
    PlotBasics.prototype.redrawRange = function (data, range_x, ylabel, callback) {
        var plt_data = [{ label: ylabel, data: data }];
        if (data.length == 0) {
            callback();
            return;
        }
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.redrawTwoChannels = function (ch0, ch1, range_x, label1, label2, is_channel_1, is_channel_2, callback) {
        if (ch0.length === 0 || ch1.length === 0) {
            callback();
            return;
        }
        var plotCh0 = [];
        var plotCh1 = [];
        if (is_channel_1 && is_channel_2) {
            plotCh0 = ch0;
            plotCh1 = ch1;
            // plotData = [ch0, ch1];
        }
        else if (is_channel_1 && !is_channel_2) {
            plotCh0 = ch0;
            plotCh1 = [];
        }
        else if (!is_channel_1 && is_channel_2) {
            plotCh0 = [];
            plotCh1 = ch1;
        }
        else {
            plotCh0 = [];
            plotCh1 = [];
        }
        var plt_data = [{ label: label1, data: plotCh0 }, { label: label2, data: plotCh1 }];
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.redrawSeries = function (series, range_x, callback) {
        if (series.length === 0) {
            if (this.plot) {
                this.plot.setData([]);
                this.plot.draw();
            }
            callback();
            return;
        }
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, series, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(series);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.onWheel = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("wheel", function (evt) {
            var delta = evt.originalEvent.deltaX
                + evt.originalEvent.deltaY;
            delta /= Math.abs(delta);
            var zoomRatio = 0.2;
            if (evt.originalEvent.shiftKey) { // Zoom Y
                var positionY = evt.originalEvent.pageY - _this.plot.offset().top;
                var y0 = _this.plot.getAxes().yaxis.c2p(positionY);
                _this.range_y = {
                    from: y0 - (1 + zoomRatio * delta) * (y0 - _this.plot.getAxes().yaxis.min),
                    to: y0 - (1 + zoomRatio * delta) * (y0 - _this.plot.getAxes().yaxis.max)
                };
                _this.reset_range = true;
                return false;
            }
            else if (evt.originalEvent.altKey) { // Zoom X
                var positionX = evt.originalEvent.pageX - _this.plot.offset().left;
                var x0 = _this.plot.getAxes().xaxis.c2p(positionX);
                if (x0 < 0 || x0 > _this.x_max) {
                    return;
                }
                _this.range_x = {
                    from: Math.max(x0 - (1 + zoomRatio * delta) * (x0 - _this.plot.getAxes().xaxis.min), 0),
                    to: Math.min(x0 - (1 + zoomRatio * delta) * (x0 - _this.plot.getAxes().xaxis.max), _this.x_max)
                };
                if (rangeFunction.length > 0) {
                    _this.driver[rangeFunction](_this.range_x);
                }
                _this.reset_range = true;
                return false;
            }
            return true;
        });
    };
    PlotBasics.prototype.initUnitInputs = function () {
        var _this = this;
        var unitInputs = document.getElementsByClassName("unit-input");
        for (var i = 0; i < unitInputs.length; i++) {
            unitInputs[i].addEventListener('change', function (event) {
                _this.reset_range = true;
            });
        }
    };
    PlotBasics.prototype.initPeakDetection = function () {
        var _this = this;
        var peakInputs = document.getElementsByClassName("peak-input");
        for (var i = 0; i < peakInputs.length; i++) {
            peakInputs[i].addEventListener('change', function (event) {
                if (_this.isPeakDetection) {
                    _this.isPeakDetection = false;
                }
                else {
                    _this.isPeakDetection = true;
                }
            });
        }
    };
    PlotBasics.prototype.showHoverPoint = function () {
        var _this = this;
        this.plot_placeholder.bind("plothover", function (event, pos, item) {
            if (item) {
                _this.hoverDatapoint[0] = item.datapoint[0];
                _this.hoverDatapoint[1] = item.datapoint[1];
                _this.hoverDatapointSpan.style.display = "inline-block";
                _this.updateDatapointSpan(_this.hoverDatapoint, _this.hoverDatapointSpan);
            }
            else {
                _this.hoverDatapointSpan.style.display = "none";
            }
        });
    };
    PlotBasics.prototype.showClickPoint = function () {
        var _this = this;
        this.plot_placeholder.bind("plotclick", function (event, pos, item) {
            if (item) {
                _this.clickDatapoint[0] = item.datapoint[0];
                _this.clickDatapoint[1] = item.datapoint[1];
                _this.clickDatapointSpan.style.display = "inline-block";
                _this.updateDatapointSpan(_this.clickDatapoint, _this.clickDatapointSpan);
                _this.plot.unhighlight();
                _this.plot.highlight(item.series, _this.clickDatapoint);
            }
        });
    };
    PlotBasics.prototype.plotLeave = function () {
        var _this = this;
        this.plot_placeholder.bind("mouseleave", function (event, pos, item) {
            _this.hoverDatapointSpan.style.display = "none";
        });
    };
    return PlotBasics;
}());
