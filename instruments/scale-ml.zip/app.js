"use strict";
// Websocket based client for koheron-server...
// (c) Koheron
var Driver = /** @class */ (function () {
    function Driver(name, id, cmds) {
        this.name = name;
        this.id = id;
        this.cmds = cmds;
    }
    Driver.prototype.getCmdRef = function (cmdName) {
        for (var _i = 0, _a = this.cmds; _i < _a.length; _i++) {
            var cmd = _a[_i];
            if (cmdName === cmd.name) {
                return cmd.id;
            }
        }
        throw new ReferenceError(cmdName + ': command not found');
    };
    Driver.prototype.getCmds = function () {
        var cmdsDict = {};
        for (var _i = 0, _a = this.cmds; _i < _a.length; _i++) {
            var cmd = _a[_i];
            cmdsDict[cmd.name] = cmd;
        }
        return cmdsDict;
    };
    return Driver;
}());
var WebSocketPool = /** @class */ (function () {
    function WebSocketPool(poolSize, url, onOpenCallback) {
        var _this = this;
        this.poolSize = poolSize;
        this.url = url;
        this.onOpenCallback = onOpenCallback;
        this.poolSize = poolSize;
        this.url = url;
        this.pool = [];
        this.freeSockets = [];
        this.dedicatedSockets = [];
        this.socketCounter = 0;
        this.exiting = false;
        for (var i = 0, end = this.poolSize - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            var websocket = this._newWebSocket();
            this.pool.push(websocket);
            websocket.onopen = function (evt) {
                return _this.waitForConnection(websocket, 100, function () {
                    console.assert(websocket.readyState === 1, 'Websocket not ready');
                    _this.freeSockets.push(_this.socketCounter);
                    if (_this.socketCounter === 0) {
                        onOpenCallback();
                    }
                    websocket.ID = _this.socketCounter;
                    websocket.onclose = function (evt) {
                        setTimeout(function () { location.reload(); }, 1000);
                    };
                    websocket.onerror = function (evt) {
                        console.error("error: ".concat(evt.data, "\n"));
                        return websocket.close();
                    };
                    return _this.socketCounter++;
                });
            };
        }
    }
    WebSocketPool.prototype._newWebSocket = function () {
        var websocket;
        if (typeof window !== 'undefined' && window !== null) {
            websocket = new WebSocket(this.url);
        }
        else { // Node
            var clientConfig = {};
            clientConfig.fragmentOutgoingMessages = false;
            var __WebSocket = require('websocket').w3cwebsocket;
            websocket = new __WebSocket(this.url, null, null, null, null, clientConfig);
        }
        websocket.binaryType = 'arraybuffer';
        return websocket;
    };
    WebSocketPool.prototype.waitForConnection = function (websocket, interval, callback) {
        var _this = this;
        if (websocket.readyState === 1) {
            // If the client has been set to exit while establishing the connection
            // we don't initialize the socket
            if (this.exiting) {
                return;
            }
            return callback();
        }
        else {
            return setTimeout(function () {
                return _this.waitForConnection(websocket, interval, callback);
            }, interval);
        }
    };
    WebSocketPool.prototype.getSocket = function (sockid) {
        if (this.exiting) {
            return null;
        }
        if (!(this.freeSockets.some(function (x) { return x == sockid; })) && (sockid >= 0) && (sockid < this.poolSize)) {
            return this.pool[sockid];
        }
        else {
            throw new ReferenceError("Socket ID ".concat(sockid.toString(), " not available"));
        }
    };
    // Obtain a socket for a dedicated task.
    // This function is provided for long term use.
    // A new socket is opened and returned to the caller.
    // This socket is not shared and can be used for a
    // dedicated task.
    // TODO: Caller close dedicated socket
    WebSocketPool.prototype.getDedicatedSocket = function (callback) {
        var _this = this;
        var websocket = this._newWebSocket();
        this.dedicatedSockets.push(websocket);
        return websocket.onopen = function (evt) {
            return _this.waitForConnection(websocket, 100, function () {
                console.assert(websocket.readyState === 1, 'Websocket not ready');
                websocket.onclose = function (evt) {
                    var idx = _this.dedicatedSockets.indexOf(websocket);
                    if (idx > -1) {
                        return _this.dedicatedSockets.splice(idx, 1);
                    }
                };
                websocket.onerror = function (evt) {
                    console.error("error: ".concat(evt.data, "\n"));
                    return websocket.close();
                };
                return callback(websocket);
            });
        };
    };
    // Retrieve a socket from the pool.
    // This function is provided for short term socket use
    // and the socket must be given back to the pool by
    // calling freeeSocket.
    WebSocketPool.prototype.requestSocket = function (callback) {
        var _this = this;
        if (this.exiting) {
            callback(-1);
            return;
        }
        if ((this.freeSockets != null) && (this.freeSockets.length > 0)) {
            var sockid_1 = this.freeSockets[this.freeSockets.length - 1];
            this.freeSockets.pop();
            return this.waitForConnection(this.pool[sockid_1], 100, function () {
                console.assert(_this.pool[sockid_1].readyState === 1, 'Websocket not ready');
                return callback(sockid_1);
            });
        }
        else { // All sockets are busy. We wait a bit and retry.
            console.assert(this.freeSockets.length === 0, 'Non empty freeSockets');
            return setTimeout(function () {
                return _this.requestSocket(callback);
            }, 100);
        }
    };
    // Give back a socket to the pool
    WebSocketPool.prototype.freeSocket = function (sockid) {
        if (this.exiting) {
            return;
        }
        if (!(this.freeSockets.some(function (x) { return x == sockid; })) && (sockid >= 0) && (sockid < this.poolSize)) {
            return this.freeSockets.push(sockid);
        }
        else {
            if (sockid != null) {
                return console.error("Invalid Socket ID ".concat(sockid.toString()));
            }
            else {
                return console.error('Undefined Socket ID');
            }
        }
    };
    WebSocketPool.prototype.exit = function () {
        this.exiting = true;
        this.freeSockets = [];
        this.socketCounter = 0;
        for (var _i = 0, _a = this.pool; _i < _a.length; _i++) {
            var websocket = _a[_i];
            websocket.close();
        }
        return this.dedicatedSockets.map(function (socket) {
            return socket.close();
        });
    };
    return WebSocketPool;
}());
// === Helper functions to build binary buffer ===
var appendInt8 = function (buffer, value) {
    buffer.push(value & 0xff);
    return 1;
};
var appendUint8 = function (buffer, value) {
    buffer.push(value & 0xff);
    return 1;
};
var appendInt16 = function (buffer, value) {
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 2;
};
var appendUint16 = function (buffer, value) {
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 2;
};
var appendInt32 = function (buffer, value) {
    buffer.push((value >> 24) & 0xff);
    buffer.push((value >> 16) & 0xff);
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 4;
};
var appendUint32 = function (buffer, value) {
    buffer.push((value >> 24) & 0xff);
    buffer.push((value >> 16) & 0xff);
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 4;
};
var floatToBytes = function (f) {
    var buf = new ArrayBuffer(4);
    (new Float32Array(buf))[0] = f;
    return (new Uint32Array(buf))[0];
};
var bytesTofloat = function (bytes) {
    var buffer = new ArrayBuffer(4);
    (new Uint32Array(buffer))[0] = bytes;
    return new Float32Array(buffer)[0];
};
var appendFloat32 = function (buffer, value) { return appendUint32(buffer, floatToBytes(value)); };
var appendFloat64 = function (buffer, value) {
    var buf = new ArrayBuffer(8);
    (new Float64Array(buf))[0] = value;
    appendUint32(buffer, (new Uint32Array(buf, 4))[0]);
    appendUint32(buffer, (new Uint32Array(buf, 0))[0]);
    console.assert(buf.byteLength === 8, 'Invalid float64 size');
    return buf.byteLength;
};
var appendArray = function (buffer, array) {
    var bytes = new Uint8Array(array.buffer);
    return bytes.map(function (_byte) { return buffer.push(_byte); });
};
var appendVector = function (buffer, array) {
    appendUint32(buffer, array.buffer.byteLength);
    var bytes = new Uint8Array(array.buffer);
    return bytes.map(function (_byte) { return buffer.push(_byte); });
};
var appendString = function (buffer, str) {
    appendUint32(buffer, str.length);
    for (var i = 0; i < str.length; i++) {
        buffer.push(str.charCodeAt(i));
    }
};
var isStdArray = function (type) { return type.split('<')[0].trim() === 'std::array'; };
var isStdVector = function (type) { return type.split('<')[0].trim() === 'std::vector'; };
var isStdString = function (type) { return type.trim() === 'std::string'; };
var isStdTuple = function (type) { return type.split('<')[0].trim() === 'std::tuple'; };
var getStdVectorType = function (type) { return type.split('<')[1].split('>')[0].trim(); };
function Command(devId, cmd) {
    var params = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        params[_i - 2] = arguments[_i];
    }
    var buffer = [];
    appendUint32(buffer, 0); // RESERVED
    appendUint16(buffer, devId);
    appendUint16(buffer, cmd.id);
    if (cmd.args.length === 0) {
        return {
            devid: devId,
            cmd: cmd,
            data: new Uint8Array(buffer)
        };
    }
    if (cmd.args.length !== params.length) {
        throw new Error("Invalid number of arguments. Expected ".concat(cmd.args.length, " receive ").concat(params.length, "."));
    }
    var buildPayload = function (args, params) {
        if (args == null) {
            args = [];
        }
        var payload = [];
        for (var i = 0; i < args.length; i++) {
            var arg = args[i];
            switch (arg.type) {
                case 'uint8_t':
                    appendUint8(payload, params[i]);
                    break;
                case 'int8_t':
                    appendInt8(payload, params[i]);
                    break;
                case 'uint16_t':
                    appendUint16(payload, params[i]);
                    break;
                case 'int16_t':
                    appendInt16(payload, params[i]);
                    break;
                case 'uint32_t':
                    appendUint32(payload, params[i]);
                    break;
                case 'int32_t':
                    appendInt32(payload, params[i]);
                    break;
                case 'float':
                    appendFloat32(payload, params[i]);
                    break;
                case 'double':
                    appendFloat64(payload, params[i]);
                    break;
                case 'bool':
                    if (params[i]) {
                        appendUint8(payload, 1);
                    }
                    else {
                        appendUint8(payload, 0);
                    }
                    break;
                default:
                    if (isStdArray(arg.type)) {
                        appendArray(payload, params[i]);
                    }
                    else if (isStdVector(arg.type)) {
                        appendVector(payload, params[i]);
                    }
                    else if (isStdString(arg.type)) {
                        appendString(payload, params[i]);
                    }
                    else {
                        throw new TypeError("Unknown type ".concat(arg.type));
                    }
            }
        }
        return payload;
    };
    return {
        devid: devId,
        cmd: cmd,
        data: new Uint8Array(buffer.concat(buildPayload(cmd.args, params)))
    };
}
var Client = /** @class */ (function () {
    function Client(IP, websockPoolSize) {
        this.IP = IP;
        this.websockPoolSize = websockPoolSize;
        if (websockPoolSize == null) {
            websockPoolSize = 5;
        }
        this.websockPoolSize = websockPoolSize;
        this.url = "ws://".concat(IP, ":8080");
        this.driversList = [];
    }
    Client.prototype.init = function (callback) {
        return this.websockpool = new WebSocketPool(this.websockPoolSize, this.url, (function () {
            return this.loadCmds(callback);
        }.bind(this)));
    };
    Client.prototype.exit = function () {
        this.websockpool.exit();
        return delete this.websockpool;
    };
    // ------------------------
    //  Send
    // ------------------------
    Client.prototype.send = function (cmd) {
        var _this = this;
        if (this.websockpool === null || typeof this.websockpool === 'undefined') {
            return;
        }
        this.websockpool.requestSocket(function (sockid) {
            if (sockid < 0) {
                return;
            }
            var websocket = _this.websockpool.getSocket(sockid);
            websocket.send(cmd.data);
            if (_this.websockpool !== null && typeof _this.websockpool !== 'undefined') {
                _this.websockpool.freeSocket(sockid);
            }
        });
    };
    // ------------------------
    //  Receive
    // ------------------------
    Client.prototype.redirectError = function (errTest, errMsg, onSuccess, onError) {
        if (errTest) {
            if (onError === null) {
                throw new TypeError(errMsg);
            }
            else {
                return onError(errMsg);
            }
        }
        else {
            return onSuccess();
        }
    };
    Client.prototype.getPayload = function (mode, evt) {
        var buffer, dvBuff, i, len;
        var dv = new DataView(evt.data);
        var reserved = dv.getUint32(0);
        var classId = dv.getUint16(4);
        var funcId = dv.getUint16(6);
        if (mode === 'static') {
            len = dv.byteLength - 8;
            buffer = new ArrayBuffer(len);
            dvBuff = new DataView(buffer);
            for (i = 0, end = len - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
                var asc, end;
                dvBuff.setUint8(i, dv.getUint8(8 + i));
            }
        }
        else { // 'dynamic'
            len = dv.getUint32(8);
            console.assert(dv.byteLength === (len + 12));
            buffer = new ArrayBuffer(len);
            dvBuff = new DataView(buffer);
            for (i = 0, end1 = len - 1, asc1 = 0 <= end1; asc1 ? i <= end1 : i >= end1; asc1 ? i++ : i--) {
                var asc1, end1;
                dvBuff.setUint8(i, dv.getUint8(12 + i));
            }
        }
        return [dvBuff, classId, funcId];
    };
    Client.prototype._readBase = function (mode, cmd, fn) {
        var _this = this;
        if ((this.websockpool === null || typeof (this.websockpool) === 'undefined')) {
            return fn(null);
        }
        this.websockpool.requestSocket(function (sockid) {
            if (sockid < 0) {
                return fn(null);
            }
            var websocket = _this.websockpool.getSocket(sockid);
            websocket.send(cmd.data);
            websocket.onmessage = function (evt) {
                fn(_this.getPayload(mode, evt)[0]);
                if (_this.websockpool !== null && typeof _this.websockpool !== 'undefined') {
                    _this.websockpool.freeSocket(sockid);
                }
            };
        });
    };
    Client.prototype.readUint32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Uint32Array(data.buffer));
        });
    };
    Client.prototype.readInt32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Int32Array(data.buffer));
        });
    };
    Client.prototype.readFloat32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Float32Array(data.buffer));
        });
    };
    Client.prototype.readFloat64Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Float64Array(data.buffer));
        });
    };
    Client.prototype.readUint32Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Uint32Array(data.buffer));
        });
    };
    Client.prototype.readFloat32Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Float32Array(data.buffer));
        });
    };
    Client.prototype.readFloat64Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Float64Array(data.buffer));
        });
    };
    Client.prototype.readUint32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getUint32(0));
        });
    };
    Client.prototype.readInt32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getInt32(0));
        });
    };
    Client.prototype.readFloat32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getFloat32(0));
        });
    };
    Client.prototype.readFloat64 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getFloat64(0));
        });
    };
    Client.prototype.readBool = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getUint8(0) === 1);
        });
    };
    Client.prototype.readTuple = function (cmd, fmt, fn) {
        var _this = this;
        this._readBase('static', cmd, function (data) {
            fn(_this.deserialize(fmt, data));
        });
    };
    Client.prototype.deserialize = function (fmt, dv, onError) {
        if (onError == null) {
            onError = null;
        }
        var tuple = [];
        var offset = 0;
        for (var i = 0, end = fmt.length - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            switch (fmt[i]) {
                case 'B':
                    tuple.push(dv.getUint8(offset));
                    offset += 1;
                    break;
                case 'b':
                    tuple.push(dv.getInt8(offset));
                    offset += 1;
                    break;
                case 'H':
                    tuple.push(dv.getUint16(offset));
                    offset += 2;
                    break;
                case 'h':
                    tuple.push(dv.getInt16(offset));
                    offset += 2;
                    break;
                case 'I':
                    tuple.push(dv.getUint32(offset));
                    offset += 4;
                    break;
                case 'i':
                    tuple.push(dv.getInt32(offset));
                    offset += 4;
                    break;
                case 'f':
                    tuple.push(dv.getFloat32(offset));
                    offset += 4;
                    break;
                case 'd':
                    tuple.push(dv.getFloat64(offset));
                    offset += 8;
                    break;
                case '?':
                    if (dv.getUint8(offset) === 0) {
                        tuple.push(false);
                    }
                    else {
                        tuple.push(true);
                    }
                    offset += 1;
                    break;
                default:
                    this.redirectError(true, "Unknown or unsupported type ".concat(fmt[i]), (function () { }), onError);
            }
        }
        return tuple;
    };
    Client.prototype.parseString = function (data, offset) {
        if (offset == null) {
            offset = 0;
        }
        return (__range__(0, data.byteLength - offset - 1, true).map(function (i) { return (String.fromCharCode(data.getUint8(offset + i))); })).join('');
    };
    Client.prototype.readString = function (cmd, fn) {
        var _this = this;
        this._readBase('dynamic', cmd, function (data) {
            fn(_this.parseString(data));
        });
    };
    Client.prototype.readJSON = function (cmd, fn) {
        this.readString(cmd, function (str) {
            fn(JSON.parse(str));
        });
    };
    // ------------------------
    //  Drivers
    // ------------------------
    Client.prototype.loadCmds = function (callback) {
        var _this = this;
        this.readJSON(Command(1, { 'id': 1, 'args': [] }), function (data) {
            for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
                var driver = data_1[_i];
                var dev = new Driver(driver.class, driver.id, driver.functions);
                // dev.show()
                _this.driversList.push(dev);
            }
            callback();
        });
    };
    Client.prototype.getDriver = function (name) {
        for (var _i = 0, _a = this.driversList; _i < _a.length; _i++) {
            var driver = _a[_i];
            if (driver.name === name) {
                return driver;
            }
        }
        throw new Error("Driver ".concat(name, " not found"));
    };
    Client.prototype.getDriverById = function (id) {
        for (var _i = 0, _a = this.driversList; _i < _a.length; _i++) {
            var driver = _a[_i];
            if (driver.id === id) {
                return driver;
            }
        }
        throw new ReferenceError("Driver ID ".concat(id, " not found"));
    };
    return Client;
}());
;
function __range__(left, right, inclusive) {
    var range = [];
    var ascending = left < right;
    var end = !inclusive ? right : ascending ? right + 1 : right - 1;
    for (var i = left; ascending ? i < end : i > end; ascending ? i++ : i--) {
        range.push(i);
    }
    return range;
}
var Imports = /** @class */ (function () {
    function Imports(document) {
        this.importLinks = document.querySelectorAll('link[rel="import"]');
        for (var i = 0; i < this.importLinks.length; i++) {
            var template = this.importLinks[i].import.querySelector('.template');
            var clone = document.importNode(template.content, true);
            var parentId = this.importLinks[i].dataset.parent;
            document.getElementById(parentId).appendChild(clone);
        }
    }
    return Imports;
}());
var App = /** @class */ (function () {
    function App(window, document, ip, plot_placeholder) {
        var _this = this;
        this.tareOffset = 0;
        this.calibrationFactor = 0.0005;
        this.calibrationOffset = 0;
        this.runtimeModel = null;
        this.out1Cache = [];
        this.out2Cache = [];
        this.mlSamples = [];
        this.mlSelectedSampleId = null;
        this.mlModel = null;
        this.nextSampleId = 1;
        this.mlWorkflowEnabled = false;
        this.sampleRateHz = 125000000;
        this.lastPlotRangeUs = { from: 0, to: 0 };
        this.curveVisible = {
            in1: true,
            in2: true,
            out1: true,
            out2: true,
            weight: false
        };
        var client = new Client(ip, 5);
        window.addEventListener('HTMLImportsLoaded', function () {
            client.init(function () {
                _this.injectInstrumentTabs(window, document);
                _this.imports = new Imports(document);
                _this.connector = new Connector(client);
                _this.plotBasics = new PlotBasics(document, plot_placeholder, 4096, 0, 4096, -11, 11, _this.connector, '', '');
                _this.bindControls(document);
                _this.bindLegendToggle(document, plot_placeholder);
                _this.bindPlotActions(document);
                _this.bindScaleTools(document);
                _this.updateDiagnosticsPlot();
                _this.updateScaleLoop();
            });
        }, false);
        window.onbeforeunload = function () {
            client.exit();
        };
    }
    App.prototype.injectInstrumentTabs = function (window, document) {
        var main = document.getElementById('main');
        if (!main || document.getElementById('scale-ml-tabs')) {
            return;
        }
        var pathname = (window.location.pathname || '').toLowerCase();
        var page = pathname.substring(pathname.lastIndexOf('/') + 1);
        var isMlPage = page === 'ml.html';
        var tabs = document.createElement('ul');
        tabs.id = 'scale-ml-tabs';
        tabs.className = 'nav nav-tabs';
        tabs.style.marginBottom = '12px';
        var scaleTab = document.createElement('li');
        if (!isMlPage) {
            scaleTab.className = 'active';
        }
        var scaleLink = document.createElement('a');
        scaleLink.href = 'scale.html';
        scaleLink.textContent = 'Scale';
        scaleTab.appendChild(scaleLink);
        var mlTab = document.createElement('li');
        if (isMlPage) {
            mlTab.className = 'active';
        }
        var mlLink = document.createElement('a');
        mlLink.href = 'ml.html';
        mlLink.textContent = 'ML';
        mlTab.appendChild(mlLink);
        tabs.appendChild(scaleTab);
        tabs.appendChild(mlTab);
        main.insertBefore(tabs, main.firstChild);
    };
    App.prototype.bindControls = function (document) {
        var _this = this;
        this.signalModeSelect = document.getElementById('signal-mode');
        this.frequencySlider = document.getElementById('slider1');
        this.frequencyValueEl = document.getElementById('freq-value');
        var applySignal = function () {
            var signalType = Number(_this.signalModeSelect.value);
            var freq = Number(_this.frequencySlider.value);
            _this.connector.setFunction(signalType, freq);
            _this.frequencyValueEl.innerText = freq.toString();
        };
        this.signalModeSelect.addEventListener('change', function () { return applySignal(); });
        this.frequencySlider.addEventListener('input', function () { return applySignal(); });
        this.bindCurveToggle(document, 'curve-in1', 'in1');
        this.bindCurveToggle(document, 'curve-in2', 'in2');
        this.bindCurveToggle(document, 'curve-out1', 'out1');
        this.bindCurveToggle(document, 'curve-out2', 'out2');
        this.bindCurveToggle(document, 'curve-weight', 'weight');
        applySignal();
    };
    App.prototype.bindCurveToggle = function (document, elementId, key) {
        var _this = this;
        var checkbox = document.getElementById(elementId);
        checkbox.checked = this.curveVisible[key];
        checkbox.addEventListener('change', function () {
            _this.curveVisible[key] = checkbox.checked;
        });
    };
    App.prototype.bindLegendToggle = function (document, plotPlaceholder) {
        var _this = this;
        plotPlaceholder.on('click', '.legendLabel', function (event) {
            var label = ($(event.currentTarget).text() || '').trim();
            var key = _this.getSeriesKeyFromLabel(label);
            if (!key) {
                return;
            }
            _this.curveVisible[key] = !_this.curveVisible[key];
            _this.setCheckboxFromKey(document, key, _this.curveVisible[key]);
        });
    };
    App.prototype.bindPlotActions = function (document) {
        var _this = this;
        var resetBtn = document.getElementById('btn-plot-reset-view');
        if (!resetBtn) {
            return;
        }
        resetBtn.addEventListener('click', function () {
            _this.plotBasics.resetView(_this.lastPlotRangeUs.from, _this.lastPlotRangeUs.to);
        });
    };
    App.prototype.getSeriesKeyFromLabel = function (label) {
        if (label === 'IN1')
            return 'in1';
        if (label === 'IN2')
            return 'in2';
        if (label === 'OUT1')
            return 'out1';
        if (label === 'OUT2')
            return 'out2';
        if (label === 'Weight (kg)')
            return 'weight';
        return null;
    };
    App.prototype.setCheckboxFromKey = function (document, key, checked) {
        var elementMap = {
            in1: 'curve-in1',
            in2: 'curve-in2',
            out1: 'curve-out1',
            out2: 'curve-out2',
            weight: 'curve-weight'
        };
        var elementId = elementMap[key];
        if (!elementId) {
            return;
        }
        var checkbox = document.getElementById(elementId);
        if (checkbox) {
            checkbox.checked = checked;
        }
    };
    App.prototype.bindScaleTools = function (document) {
        var _this = this;
        this.adc0ValueEl = document.getElementById('adc0-value');
        this.adc1ValueEl = document.getElementById('adc1-value');
        this.dac0ValueEl = document.getElementById('dac0-value');
        this.dac1ValueEl = document.getElementById('dac1-value');
        this.weightEl = document.getElementById('weight-value');
        this.rmsIn1El = document.getElementById('rms-in1');
        this.rmsIn2El = document.getElementById('rms-in2');
        this.rmsOut1El = document.getElementById('rms-out1');
        this.rmsOut2El = document.getElementById('rms-out2');
        var calibrationInput = document.getElementById('input-calibration');
        var calibrationOffsetInput = document.getElementById('input-calibration-offset');
        var saveScaleBtn = document.getElementById('btn-save-scale');
        var tareBtn = document.getElementById('btn-tare');
        this.calibrationFactor = this.parseNumber(calibrationInput.value, this.calibrationFactor);
        if (calibrationOffsetInput) {
            this.calibrationOffset = this.parseNumber(calibrationOffsetInput.value, this.calibrationOffset);
        }
        saveScaleBtn.onclick = function () {
            _this.calibrationFactor = _this.parseNumber(calibrationInput.value, _this.calibrationFactor);
            if (calibrationOffsetInput) {
                _this.calibrationOffset = _this.parseNumber(calibrationOffsetInput.value, _this.calibrationOffset);
            }
            _this.runtimeModel = null;
        };
        tareBtn.onclick = function () {
            _this.connector.getAdcRawData(16, function (adc0, _) {
                _this.tareOffset = adc0;
            });
        };
        var mlRealWeightInputEl = document.getElementById('input-ml-real-weight');
        var mlMeasureAddBtnEl = document.getElementById('btn-ml-measure-add');
        if (!mlRealWeightInputEl || !mlMeasureAddBtnEl) {
            this.mlWorkflowEnabled = false;
            return;
        }
        this.mlRealWeightInput = mlRealWeightInputEl;
        this.mlMeasureAddBtn = mlMeasureAddBtnEl;
        this.mlLastMeasuredWeightEl = document.getElementById('ml-last-measured-weight');
        this.mlLastAdcEl = document.getElementById('ml-last-adc');
        this.mlSamplesBodyEl = document.getElementById('ml-samples-body');
        this.mlResetValuesBtn = document.getElementById('btn-ml-reset-values');
        this.mlRecommendedFactorEl = document.getElementById('ml-recommended-factor');
        this.mlRecommendedOffsetEl = document.getElementById('ml-recommended-offset');
        this.mlRecommendedModelEl = document.getElementById('ml-recommended-model');
        this.mlRecommendedUsedSamplesEl = document.getElementById('ml-recommended-used-samples');
        this.mlRecommendedMaeEl = document.getElementById('ml-recommended-mae');
        this.mlRecommendedRmseEl = document.getElementById('ml-recommended-rmse');
        this.mlRecommendedMaxErrorEl = document.getElementById('ml-recommended-max-error');
        this.mlRecommendedR2El = document.getElementById('ml-recommended-r2');
        this.mlApplyRecommendedBtn = document.getElementById('btn-ml-apply-recommended');
        this.mlSampleSelectEl = document.getElementById('ml-sample-select');
        this.mlSelectedDetailsEl = document.getElementById('ml-selected-details');
        this.mlPlotPlaceholder = $('#ml-plot-placeholder');
        this.mlModelSelectEl = document.getElementById('ml-model-select');
        this.mlCriterionSelectEl = document.getElementById('ml-criterion-select');
        this.mlSampleScopeSelectEl = document.getElementById('ml-fit-sample-scope');
        this.mlOutlierSigmaInput = document.getElementById('ml-outlier-sigma');
        this.mlRidgeLambdaInput = document.getElementById('ml-ridge-lambda');
        this.mlReferenceDeltaInput = document.getElementById('ml-factor-ref-delta');
        this.mlAvgCountInput = document.getElementById('ml-avg-count');
        this.mlInverseModeEl = document.getElementById('ml-inverse-mode');
        this.mlSignalFeatureSelectEl = document.getElementById('ml-signal-feature');
        this.mlRefAInput = document.getElementById('ml-ref-a');
        this.mlRefBInput = document.getElementById('ml-ref-b');
        this.mlRefC0Input = document.getElementById('ml-ref-c0');
        this.mlLiveCapacityEl = document.getElementById('ml-live-capacity');
        this.mlLiveWeightFromCapacityEl = document.getElementById('ml-live-weight-from-capacity');
        if (!this.mlLastMeasuredWeightEl || !this.mlLastAdcEl || !this.mlSamplesBodyEl || !this.mlResetValuesBtn ||
            !this.mlRecommendedFactorEl || !this.mlRecommendedOffsetEl || !this.mlRecommendedModelEl ||
            !this.mlRecommendedUsedSamplesEl || !this.mlRecommendedMaeEl || !this.mlRecommendedRmseEl ||
            !this.mlRecommendedMaxErrorEl || !this.mlRecommendedR2El || !this.mlApplyRecommendedBtn ||
            !this.mlSampleSelectEl || !this.mlSelectedDetailsEl || this.mlPlotPlaceholder.length === 0 ||
            !this.mlModelSelectEl || !this.mlCriterionSelectEl || !this.mlSampleScopeSelectEl ||
            !this.mlOutlierSigmaInput || !this.mlRidgeLambdaInput || !this.mlReferenceDeltaInput ||
            !this.mlAvgCountInput || !this.mlInverseModeEl || !this.mlSignalFeatureSelectEl ||
            !this.mlRefAInput || !this.mlRefBInput || !this.mlRefC0Input || !this.mlLiveCapacityEl ||
            !this.mlLiveWeightFromCapacityEl) {
            this.mlWorkflowEnabled = false;
            return;
        }
        this.mlWorkflowEnabled = true;
        var retrain = function () {
            _this.recomputeMlModel();
            _this.renderMlTable();
            _this.renderMlDetails();
            _this.renderMlPlot();
        };
        this.mlModelSelectEl.onchange = retrain;
        this.mlCriterionSelectEl.onchange = retrain;
        this.mlSampleScopeSelectEl.onchange = retrain;
        this.mlOutlierSigmaInput.onchange = retrain;
        this.mlRidgeLambdaInput.onchange = retrain;
        this.mlReferenceDeltaInput.onchange = retrain;
        this.mlInverseModeEl.onchange = retrain;
        this.mlSignalFeatureSelectEl.onchange = retrain;
        this.mlRefAInput.onchange = retrain;
        this.mlRefBInput.onchange = retrain;
        this.mlRefC0Input.onchange = retrain;
        this.mlMeasureAddBtn.onclick = function () {
            var realWeightG = _this.parseNumber(_this.mlRealWeightInput.value, NaN);
            if (!isFinite(realWeightG) || realWeightG < 0) {
                return;
            }
            var avgCount = _this.getMlAverageCount();
            _this.connector.getAdcRawData(avgCount, function (adc0, _) {
                var deltaCounts = adc0 - _this.tareOffset;
                var signalFeatureValue = _this.extractSignalFeatureValue(adc0, deltaCounts);
                var referenceCapacityPf = _this.capacityFromReferenceModel(realWeightG);
                var predictedCapacityPf = _this.predictCapacityFromRuntime(adc0, deltaCounts);
                var measuredWeightG = _this.weightFromReferenceCapacity(predictedCapacityPf);
                var sample = {
                    id: _this.nextSampleId++,
                    timestamp: new Date().toISOString(),
                    realWeightG: realWeightG,
                    measuredWeightG: measuredWeightG,
                    adcRaw: adc0,
                    deltaCounts: deltaCounts,
                    signalFeatureValue: signalFeatureValue,
                    signalFeatureKey: _this.getSelectedSignalFeature(),
                    referenceCapacityPf: referenceCapacityPf,
                    predictedCapacityPf: predictedCapacityPf,
                    predictedWeightG: measuredWeightG,
                    tareAtMeasurement: _this.tareOffset,
                    calibrationAtMeasurement: _this.calibrationFactor,
                    calibrationOffsetAtMeasurement: _this.calibrationOffset,
                    modelSelectionAtMeasurement: _this.getCurrentModelTag()
                };
                _this.mlSamples.push(sample);
                _this.mlSelectedSampleId = sample.id;
                _this.mlLastMeasuredWeightEl.innerText = measuredWeightG.toFixed(3);
                _this.mlLastAdcEl.innerText = adc0.toString();
                _this.mlLiveCapacityEl.innerText = predictedCapacityPf.toFixed(4);
                _this.mlLiveWeightFromCapacityEl.innerText = measuredWeightG.toFixed(3);
                _this.recomputeMlModel();
                _this.renderMlTable();
                _this.renderMlSampleSelect();
                _this.renderMlDetails();
                _this.renderMlPlot();
            });
        };
        this.mlResetValuesBtn.onclick = function () {
            _this.mlSamples = [];
            _this.mlSelectedSampleId = null;
            _this.mlModel = null;
            _this.nextSampleId = 1;
            _this.mlLastMeasuredWeightEl.innerText = '-';
            _this.mlLastAdcEl.innerText = '-';
            _this.mlLiveCapacityEl.innerText = '-';
            _this.mlLiveWeightFromCapacityEl.innerText = '-';
            _this.renderMlTable();
            _this.renderMlSampleSelect();
            _this.renderMlModel();
            _this.renderMlDetails();
            _this.renderMlPlot();
        };
        this.mlApplyRecommendedBtn.onclick = function () {
            if (!_this.mlModel) {
                return;
            }
            _this.runtimeModel = _this.cloneModel(_this.mlModel);
        };
        this.mlSampleSelectEl.onchange = function () {
            var selected = _this.parseNumber(_this.mlSampleSelectEl.value, NaN);
            _this.mlSelectedSampleId = isFinite(selected) ? selected : null;
            _this.renderMlDetails();
            _this.renderMlPlot();
            _this.highlightSelectedTableRow();
        };
        this.renderMlTable();
        this.renderMlSampleSelect();
        this.renderMlModel();
        this.renderMlDetails();
        this.renderMlPlot();
    };
    App.prototype.recomputeMlModel = function () {
        this.mlModel = this.trainSelectedModel();
        this.renderMlModel();
    };
    App.prototype.trainSelectedModel = function () {
        var selection = this.getSelectedModelSelection();
        var criterion = this.getSelectedCriterion();
        var inverse = this.isInverseModeEnabled();
        var trainingSamples = this.getTrainingSamples(selection);
        if (trainingSamples.length === 0) {
            return null;
        }
        var candidates = [];
        var modelKeys = [selection];
        for (var i = 0; i < modelKeys.length; i++) {
            var candidate = this.fitModel(modelKeys[i], trainingSamples, this.mlSamples.length, inverse);
            if (candidate) {
                candidates.push(candidate);
            }
        }
        if (candidates.length === 0) {
            return null;
        }
        var best = candidates[0];
        for (var i = 1; i < candidates.length; i++) {
            if (this.isBetterModel(candidates[i], best, criterion)) {
                best = candidates[i];
            }
        }
        return best;
    };
    App.prototype.fitModel = function (modelKey, samples, totalSamples, inverse) {
        var coeffs = this.solveCoefficients(modelKey, samples, inverse);
        if (!coeffs) {
            return null;
        }
        var sigma = this.getOutlierSigma();
        var usedSamples = samples.slice();
        if (sigma > 0 && samples.length >= 4) {
            var filtered = this.filterOutliers(modelKey, coeffs, samples, sigma, inverse);
            if (filtered.length >= this.minSamplesForModel(modelKey)) {
                usedSamples = filtered;
                var refit = this.solveCoefficients(modelKey, usedSamples, inverse);
                if (refit) {
                    return this.evaluateModel(modelKey, refit, usedSamples, totalSamples, inverse);
                }
            }
        }
        return this.evaluateModel(modelKey, coeffs, usedSamples, totalSamples, inverse);
    };
    App.prototype.solveCoefficients = function (modelKey, samples, inverse) {
        if (modelKey === 'exponential') {
            return this.fitNonlinearModel(modelKey, samples, inverse);
        }
        var design = this.getModelDesign(modelKey);
        if (samples.length < design.length) {
            return null;
        }
        var lambda = this.getRidgeLambda();
        var normal = [];
        var rhs = [];
        for (var i = 0; i < design.length; i++) {
            normal.push(new Array(design.length).fill(0));
            rhs.push(0);
        }
        for (var n = 0; n < samples.length; n++) {
            var x = this.transformInput(samples[n].signalFeatureValue, inverse);
            var row = this.buildFeatures(x, modelKey);
            var y = samples[n].referenceCapacityPf;
            for (var i = 0; i < design.length; i++) {
                rhs[i] += row[i] * y;
                for (var j = 0; j < design.length; j++) {
                    normal[i][j] += row[i] * row[j];
                }
            }
        }
        for (var i = 0; i < design.length; i++) {
            normal[i][i] += lambda;
        }
        return this.solveLinearSystem(normal, rhs);
    };
    App.prototype.evaluateModel = function (modelKey, coeffs, samples, totalSamples, inverse) {
        var mae = 0;
        var mse = 0;
        var maxAbsError = 0;
        var sumY = 0;
        for (var i = 0; i < samples.length; i++) {
            sumY += samples[i].referenceCapacityPf;
        }
        var yMean = samples.length > 0 ? sumY / samples.length : 0;
        var tss = 0;
        for (var i = 0; i < samples.length; i++) {
            var predicted = this.predictByModel(modelKey, coeffs, samples[i].signalFeatureValue, inverse);
            var err = predicted - samples[i].referenceCapacityPf;
            var absErr = Math.abs(err);
            mae += absErr;
            mse += err * err;
            maxAbsError = Math.max(maxAbsError, absErr);
            var dy = samples[i].referenceCapacityPf - yMean;
            tss += dy * dy;
        }
        mae /= samples.length;
        var rmse = Math.sqrt(mse / samples.length);
        var r2 = tss > 1e-12 ? (1 - (mse / tss)) : (mse <= 1e-12 ? 1 : 0);
        var ref = this.getReferenceDeltaCounts();
        var factor = this.localFactorAt(modelKey, coeffs, ref, inverse);
        var offset = this.predictByModel(modelKey, coeffs, 0, inverse);
        return {
            key: modelKey,
            label: this.getModelLabel(modelKey) + (inverse ? ' + Inverse' : ''),
            inverse: inverse,
            factor: factor,
            offset: offset,
            coefficients: coeffs.slice(),
            usedSamples: samples.length,
            totalSamples: totalSamples,
            maxAbsError: maxAbsError,
            r2: r2,
            referenceDeltaCounts: ref,
            mae: mae,
            rmse: rmse
        };
    };
    App.prototype.renderMlModel = function () {
        if (!this.mlModel) {
            this.mlRecommendedModelEl.innerText = '-';
            this.mlRecommendedUsedSamplesEl.innerText = '-';
            this.mlRecommendedFactorEl.innerText = '-';
            this.mlRecommendedOffsetEl.innerText = '-';
            this.mlRecommendedMaeEl.innerText = '-';
            this.mlRecommendedRmseEl.innerText = '-';
            this.mlRecommendedMaxErrorEl.innerText = '-';
            this.mlRecommendedR2El.innerText = '-';
            return;
        }
        this.mlRecommendedModelEl.innerText = this.mlModel.label;
        this.mlRecommendedUsedSamplesEl.innerText = this.mlModel.usedSamples.toString() + ' / ' + this.mlModel.totalSamples.toString();
        this.mlRecommendedFactorEl.innerText = this.mlModel.factor.toFixed(8);
        this.mlRecommendedOffsetEl.innerText = this.mlModel.offset.toFixed(6);
        this.mlRecommendedMaeEl.innerText = this.mlModel.mae.toFixed(6);
        this.mlRecommendedRmseEl.innerText = this.mlModel.rmse.toFixed(6);
        this.mlRecommendedMaxErrorEl.innerText = this.mlModel.maxAbsError.toFixed(6);
        this.mlRecommendedR2El.innerText = this.mlModel.r2.toFixed(6);
    };
    App.prototype.renderMlTable = function () {
        var _this = this;
        this.mlSamplesBodyEl.innerHTML = '';
        var _loop_1 = function (i) {
            var sample = this_1.mlSamples[i];
            var activeCapacity = this_1.mlModel
                ? this_1.predictByModel(this_1.mlModel.key, this_1.mlModel.coefficients, sample.signalFeatureValue, this_1.mlModel.inverse)
                : sample.predictedCapacityPf;
            var activeWeight = this_1.weightFromReferenceCapacity(activeCapacity);
            var capacityError = activeCapacity - sample.referenceCapacityPf;
            var weightError = activeWeight - sample.realWeightG;
            var tr = document.createElement('tr');
            tr.dataset.sampleId = sample.id.toString();
            tr.style.cursor = 'pointer';
            tr.innerHTML =
                '<td>' + (i + 1).toString() + '</td>' +
                    '<td>' + sample.realWeightG.toFixed(1) + '</td>' +
                    '<td>' + sample.referenceCapacityPf.toFixed(4) + '</td>' +
                    '<td>' + activeCapacity.toFixed(4) + '</td>' +
                    '<td>' + activeWeight.toFixed(1) + '</td>' +
                    '<td>' + sample.adcRaw.toString() + '</td>' +
                    '<td>' + sample.deltaCounts.toString() + '</td>' +
                    '<td>' + sample.signalFeatureValue.toFixed(4) + '</td>' +
                    '<td>' + this_1.getModelDisplayForSelection(sample.modelSelectionAtMeasurement) + '</td>' +
                    '<td>' + capacityError.toFixed(4) + '</td>' +
                    '<td>' + weightError.toFixed(1) + '</td>';
            tr.onclick = function () {
                _this.mlSelectedSampleId = sample.id;
                _this.mlSampleSelectEl.value = sample.id.toString();
                _this.renderMlDetails();
                _this.renderMlPlot();
                _this.highlightSelectedTableRow();
            };
            this_1.mlSamplesBodyEl.appendChild(tr);
        };
        var this_1 = this;
        for (var i = 0; i < this.mlSamples.length; i++) {
            _loop_1(i);
        }
        this.highlightSelectedTableRow();
    };
    App.prototype.highlightSelectedTableRow = function () {
        var rows = this.mlSamplesBodyEl.querySelectorAll('tr');
        for (var i = 0; i < rows.length; i++) {
            var row = rows.item(i);
            if (!row || !row.dataset.sampleId) {
                continue;
            }
            var isSelected = this.mlSelectedSampleId !== null && row.dataset.sampleId === this.mlSelectedSampleId.toString();
            row.style.backgroundColor = isSelected ? '#d9edf7' : '';
        }
    };
    App.prototype.renderMlSampleSelect = function () {
        var selectedValue = this.mlSelectedSampleId !== null ? this.mlSelectedSampleId.toString() : '';
        this.mlSampleSelectEl.innerHTML = '<option value="">Keine Messung ausgewählt</option>';
        for (var i = 0; i < this.mlSamples.length; i++) {
            var sample = this.mlSamples[i];
            var opt = document.createElement('option');
            opt.value = sample.id.toString();
            opt.text = '#' + (i + 1).toString() + ' | Real ' + sample.realWeightG.toFixed(1) + ' g | Cref ' + sample.referenceCapacityPf.toFixed(3) + ' pF';
            this.mlSampleSelectEl.appendChild(opt);
        }
        if (selectedValue && this.mlSampleSelectEl.querySelector('option[value="' + selectedValue + '"]')) {
            this.mlSampleSelectEl.value = selectedValue;
        }
        else {
            this.mlSampleSelectEl.value = '';
        }
    };
    App.prototype.renderMlDetails = function () {
        var _this = this;
        if (this.mlSelectedSampleId === null) {
            this.mlSelectedDetailsEl.innerText = 'Keine Messung ausgewählt.';
            return;
        }
        var sample = this.mlSamples.find(function (s) { return s.id === _this.mlSelectedSampleId; });
        if (!sample) {
            this.mlSelectedDetailsEl.innerText = 'Keine Messung ausgewählt.';
            return;
        }
        var predicted = this.mlModel
            ? this.predictByModel(this.mlModel.key, this.mlModel.coefficients, sample.signalFeatureValue, this.mlModel.inverse)
            : NaN;
        var predictedWeightG = isFinite(predicted) ? this.weightFromReferenceCapacity(predicted) : NaN;
        var lines = [
            'Messung #' + sample.id.toString(),
            'Zeit: ' + sample.timestamp,
            'Referenzgewicht: ' + sample.realWeightG.toFixed(3) + ' g',
            'Referenzkapazität (aus C(m)): ' + sample.referenceCapacityPf.toFixed(6) + ' pF',
            'Gespeicherte C-Vorhersage: ' + sample.predictedCapacityPf.toFixed(6) + ' pF',
            'Gespeicherte m-Vorhersage: ' + sample.predictedWeightG.toFixed(3) + ' g',
            'ADC Rohwert: ' + sample.adcRaw.toString(),
            'ADC Delta (zu Tara): ' + sample.deltaCounts.toString(),
            'Signal-Feature [' + sample.signalFeatureKey + ']: ' + sample.signalFeatureValue.toFixed(6),
            'Tara bei Messung: ' + sample.tareAtMeasurement.toString(),
            'Kalibrierfaktor bei Messung: ' + sample.calibrationAtMeasurement.toFixed(8),
            'Kalibrieroffset bei Messung: ' + sample.calibrationOffsetAtMeasurement.toFixed(8),
            'Modellwahl bei Messung: ' + this.getModelDisplayForSelection(sample.modelSelectionAtMeasurement)
        ];
        if (isFinite(predicted)) {
            lines.push('Aktive C-Vorhersage: ' + predicted.toFixed(6) + ' pF');
            lines.push('Aktiver C-Fehler: ' + (predicted - sample.referenceCapacityPf).toFixed(6) + ' pF');
            lines.push('Aktive m-Vorhersage aus C: ' + predictedWeightG.toFixed(3) + ' g');
            lines.push('Aktiver m-Fehler: ' + (predictedWeightG - sample.realWeightG).toFixed(3) + ' g');
        }
        this.mlSelectedDetailsEl.innerHTML = lines.join('<br>');
    };
    App.prototype.renderMlPlot = function () {
        var _this = this;
        var groupedBySelection = {};
        var xMin = 0;
        var xMax = 0;
        for (var i = 0; i < this.mlSamples.length; i++) {
            var x = this.mlSamples[i].signalFeatureValue;
            var y = this.mlSamples[i].referenceCapacityPf;
            var selection = this.mlSamples[i].modelSelectionAtMeasurement;
            if (!groupedBySelection[selection]) {
                groupedBySelection[selection] = [];
            }
            groupedBySelection[selection].push([x, y]);
            if (i === 0) {
                xMin = x;
                xMax = x;
            }
            else {
                xMin = Math.min(xMin, x);
                xMax = Math.max(xMax, x);
            }
        }
        var series = [];
        var selectionKeys = Object.keys(groupedBySelection);
        var palette = ['#1f77b4', '#2ca02c', '#ff7f0e', '#8c564b', '#17becf', '#9467bd'];
        for (var i = 0; i < selectionKeys.length; i++) {
            var key = selectionKeys[i];
            series.push({
                label: 'Messpunkte [' + this.getModelDisplayForSelection(key) + ']',
                data: groupedBySelection[key],
                points: { show: true, radius: 4 },
                lines: { show: false },
                color: palette[i % palette.length]
            });
        }
        if (this.mlModel && this.mlSamples.length >= 1) {
            if (xMin === xMax) {
                xMin -= 1;
                xMax += 1;
            }
            series.push({
                label: 'ML Fit [' + this.mlModel.label + ']',
                data: [
                    [xMin, this.predictByModel(this.mlModel.key, this.mlModel.coefficients, xMin, this.mlModel.inverse)],
                    [xMax, this.predictByModel(this.mlModel.key, this.mlModel.coefficients, xMax, this.mlModel.inverse)]
                ],
                points: { show: false },
                lines: { show: true, lineWidth: 2 },
                color: '#d62728'
            });
        }
        if (this.mlSelectedSampleId !== null) {
            var selected = this.mlSamples.find(function (s) { return s.id === _this.mlSelectedSampleId; });
            if (selected) {
                series.push({
                    label: 'Ausgewählte Messung',
                    data: [[selected.signalFeatureValue, selected.referenceCapacityPf]],
                    points: { show: true, radius: 7 },
                    lines: { show: false },
                    color: '#2ca02c'
                });
            }
        }
        var mlPlotOptions = {
            grid: {
                hoverable: true,
                clickable: true,
                borderWidth: 1
            },
            legend: {
                position: 'nw'
            },
            xaxis: { axisLabel: 'Signal-Feature x' },
            yaxis: { axisLabel: 'Kapazität C [pF]' }
        };
        $.plot(this.mlPlotPlaceholder, series, mlPlotOptions);
    };
    App.prototype.getSelectedModelSelection = function () {
        var value = this.mlModelSelectEl ? this.mlModelSelectEl.value : 'linear';
        if (value === 'linear' || value === 'quadratic' || value === 'exponential') {
            return value;
        }
        return 'linear';
    };
    App.prototype.isInverseModeEnabled = function () {
        return !!(this.mlInverseModeEl && this.mlInverseModeEl.checked);
    };
    App.prototype.getCurrentModelTag = function () {
        return this.makeModelTag(this.getSelectedModelSelection(), this.isInverseModeEnabled(), this.getSelectedSignalFeature());
    };
    App.prototype.makeModelTag = function (selection, inverse, feature) {
        return selection + '|inv=' + (inverse ? '1' : '0') + '|feat=' + feature;
    };
    App.prototype.getSelectedCriterion = function () {
        var value = this.mlCriterionSelectEl ? this.mlCriterionSelectEl.value : 'rmse';
        if (value === 'rmse' || value === 'mae' || value === 'maxerr' || value === 'r2') {
            return value;
        }
        return 'rmse';
    };
    App.prototype.getSelectedSampleScope = function () {
        var value = this.mlSampleScopeSelectEl ? this.mlSampleScopeSelectEl.value : 'all';
        if (value === 'all' || value === 'active_model') {
            return value;
        }
        return 'all';
    };
    App.prototype.getReferenceDeltaCounts = function () {
        return this.parseNumber(this.mlReferenceDeltaInput ? this.mlReferenceDeltaInput.value : '0', 0);
    };
    App.prototype.getOutlierSigma = function () {
        var sigma = this.parseNumber(this.mlOutlierSigmaInput ? this.mlOutlierSigmaInput.value : '0', 0);
        return Math.max(0, sigma);
    };
    App.prototype.getRidgeLambda = function () {
        var lambda = this.parseNumber(this.mlRidgeLambdaInput ? this.mlRidgeLambdaInput.value : '0', 0);
        return Math.max(0, lambda);
    };
    App.prototype.getMlAverageCount = function () {
        var parsed = this.parseNumber(this.mlAvgCountInput ? this.mlAvgCountInput.value : '16', 16);
        var rounded = Math.round(parsed);
        return Math.max(1, rounded);
    };
    App.prototype.getSelectedSignalFeature = function () {
        var value = this.mlSignalFeatureSelectEl ? this.mlSignalFeatureSelectEl.value : 'delta';
        if (value === 'delta' || value === 'abs_delta' || value === 'adc_raw' || value === 'log_abs_delta') {
            return value;
        }
        return 'delta';
    };
    App.prototype.extractSignalFeatureValue = function (adcRaw, deltaCounts) {
        var key = this.getSelectedSignalFeature();
        if (key === 'adc_raw') {
            return adcRaw;
        }
        if (key === 'abs_delta') {
            return Math.abs(deltaCounts);
        }
        if (key === 'log_abs_delta') {
            return Math.log(Math.abs(deltaCounts) + 1);
        }
        return deltaCounts;
    };
    App.prototype.getReferenceA = function () {
        return this.parseNumber(this.mlRefAInput ? this.mlRefAInput.value : '2.95', 2.95);
    };
    App.prototype.getReferenceB = function () {
        return this.parseNumber(this.mlRefBInput ? this.mlRefBInput.value : '0.00162', 0.00162);
    };
    App.prototype.getReferenceC0 = function () {
        return this.parseNumber(this.mlRefC0Input ? this.mlRefC0Input.value : '14.59', 14.59);
    };
    App.prototype.capacityFromReferenceModel = function (weightG) {
        var a = this.getReferenceA();
        var b = this.getReferenceB();
        var c0 = this.getReferenceC0();
        return (a * Math.exp(b * weightG)) + c0;
    };
    App.prototype.weightFromReferenceCapacity = function (capacityPf) {
        var a = this.getReferenceA();
        var b = this.getReferenceB();
        var c0 = this.getReferenceC0();
        var eps = 1e-12;
        var arg = (capacityPf - c0) / (Math.abs(a) > eps ? a : eps);
        return Math.log(Math.abs(arg) + eps) / (Math.abs(b) > eps ? b : eps);
    };
    App.prototype.getModelLabel = function (key) {
        if (key === 'linear')
            return 'Linear';
        if (key === 'quadratic')
            return 'Quadratisch';
        if (key === 'exponential')
            return 'Exponentiell';
        return key;
    };
    App.prototype.getModelDisplayForSelection = function (selection) {
        if (selection.indexOf('|inv=') >= 0) {
            var parts = selection.split('|');
            var base = parts.length > 0 ? parts[0] : '';
            var invPart = parts.find(function (p) { return p.indexOf('inv=') === 0; }) || 'inv=0';
            var featPart = parts.find(function (p) { return p.indexOf('feat=') === 0; }) || 'feat=delta';
            var inv = invPart === 'inv=1';
            var feat = featPart.replace('feat=', '');
            if (base === 'linear' || base === 'quadratic' || base === 'exponential') {
                return this.getModelLabel(base) + (inv ? ' + Inverse' : '') + ' [' + feat + ']';
            }
        }
        if (selection === 'linear' || selection === 'quadratic' || selection === 'exponential') {
            return this.getModelLabel(selection);
        }
        return selection;
    };
    App.prototype.getTrainingSamples = function (selection) {
        var scope = this.getSelectedSampleScope();
        if (scope !== 'active_model') {
            return this.mlSamples.slice();
        }
        var currentTag = this.makeModelTag(selection, this.isInverseModeEnabled(), this.getSelectedSignalFeature());
        return this.mlSamples.filter(function (sample) { return sample.modelSelectionAtMeasurement === currentTag; });
    };
    App.prototype.minSamplesForModel = function (modelKey) {
        return this.getModelDesign(modelKey).length;
    };
    App.prototype.getModelDesign = function (modelKey) {
        if (modelKey === 'linear')
            return ['x'];
        if (modelKey === 'quadratic')
            return ['x2', 'x'];
        if (modelKey === 'exponential')
            return ['a', 'b'];
        return ['x'];
    };
    App.prototype.buildFeatures = function (x, modelKey) {
        if (modelKey === 'linear')
            return [x];
        if (modelKey === 'quadratic')
            return [x * x, x];
        return [x];
    };
    App.prototype.solveLinearSystem = function (aIn, bIn) {
        var n = aIn.length;
        var a = aIn.map(function (row) { return row.slice(); });
        var b = bIn.slice();
        for (var i = 0; i < n; i++) {
            var pivot = i;
            var pivotAbs = Math.abs(a[i][i]);
            for (var r = i + 1; r < n; r++) {
                var v = Math.abs(a[r][i]);
                if (v > pivotAbs) {
                    pivotAbs = v;
                    pivot = r;
                }
            }
            if (pivotAbs < 1e-12) {
                return null;
            }
            if (pivot !== i) {
                var tmpRow = a[i];
                a[i] = a[pivot];
                a[pivot] = tmpRow;
                var tmpB = b[i];
                b[i] = b[pivot];
                b[pivot] = tmpB;
            }
            var diag = a[i][i];
            for (var c = i; c < n; c++) {
                a[i][c] /= diag;
            }
            b[i] /= diag;
            for (var r = 0; r < n; r++) {
                if (r === i) {
                    continue;
                }
                var factor = a[r][i];
                for (var c = i; c < n; c++) {
                    a[r][c] -= factor * a[i][c];
                }
                b[r] -= factor * b[i];
            }
        }
        return b;
    };
    App.prototype.fitNonlinearModel = function (modelKey, samples, inverse) {
        if (samples.length < 3) {
            return null;
        }
        var minX = this.transformInput(samples[0].signalFeatureValue, inverse);
        var maxX = this.transformInput(samples[0].signalFeatureValue, inverse);
        var minY = samples[0].referenceCapacityPf;
        var maxY = samples[0].referenceCapacityPf;
        for (var i = 0; i < samples.length; i++) {
            var x = this.transformInput(samples[i].signalFeatureValue, inverse);
            var y = samples[i].referenceCapacityPf;
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        }
        var spanX = Math.max(1e-6, maxX - minX);
        var spanY = Math.max(1e-6, maxY - minY);
        var params = [Math.max(spanY, 1e-3), 1 / spanX];
        var learningRate = 1e-3;
        var bestParams = params.slice();
        var bestLoss = this.nonlinearLoss(modelKey, bestParams, samples, inverse);
        var _loop_2 = function (iter) {
            var grad = this_2.numericalGradient(modelKey, params, samples, inverse);
            var candidate = params.map(function (p, i) { return p - learningRate * grad[i]; });
            var candidateLoss = this_2.nonlinearLoss(modelKey, candidate, samples, inverse);
            if (isFinite(candidateLoss) && candidateLoss <= bestLoss) {
                params = candidate;
                bestLoss = candidateLoss;
                bestParams = candidate.slice();
                learningRate = Math.min(1e-1, learningRate * 1.03);
            }
            else {
                learningRate *= 0.5;
                if (learningRate < 1e-10) {
                    return "break";
                }
            }
        };
        var this_2 = this;
        for (var iter = 0; iter < 1200; iter++) {
            var state_1 = _loop_2(iter);
            if (state_1 === "break")
                break;
        }
        if (!isFinite(bestLoss)) {
            return null;
        }
        return bestParams;
    };
    App.prototype.nonlinearLoss = function (modelKey, params, samples, inverse) {
        var mse = 0;
        for (var i = 0; i < samples.length; i++) {
            var yHat = this.predictByModel(modelKey, params, samples[i].signalFeatureValue, inverse);
            if (!isFinite(yHat)) {
                return 1e30;
            }
            var err = yHat - samples[i].referenceCapacityPf;
            mse += err * err;
        }
        return mse / samples.length;
    };
    App.prototype.numericalGradient = function (modelKey, params, samples, inverse) {
        var grad = new Array(params.length).fill(0);
        var baseLoss = this.nonlinearLoss(modelKey, params, samples, inverse);
        for (var i = 0; i < params.length; i++) {
            var step = Math.abs(params[i]) * 1e-4 + 1e-7;
            var pPlus = params.slice();
            var pMinus = params.slice();
            pPlus[i] += step;
            pMinus[i] -= step;
            var lossPlus = this.nonlinearLoss(modelKey, pPlus, samples, inverse);
            var lossMinus = this.nonlinearLoss(modelKey, pMinus, samples, inverse);
            if (isFinite(lossPlus) && isFinite(lossMinus)) {
                grad[i] = (lossPlus - lossMinus) / (2 * step);
            }
            else if (isFinite(lossPlus)) {
                grad[i] = (lossPlus - baseLoss) / step;
            }
            else if (isFinite(lossMinus)) {
                grad[i] = (baseLoss - lossMinus) / step;
            }
            else {
                grad[i] = 0;
            }
        }
        return grad;
    };
    App.prototype.filterOutliers = function (modelKey, coeffs, samples, sigma, inverse) {
        var residuals = [];
        var mean = 0;
        for (var i = 0; i < samples.length; i++) {
            var err = this.predictByModel(modelKey, coeffs, samples[i].signalFeatureValue, inverse) - samples[i].referenceCapacityPf;
            residuals.push(err);
            mean += err;
        }
        mean /= residuals.length;
        var variance = 0;
        for (var i = 0; i < residuals.length; i++) {
            var d = residuals[i] - mean;
            variance += d * d;
        }
        variance /= residuals.length;
        var std = Math.sqrt(variance);
        if (std < 1e-12) {
            return samples.slice();
        }
        var threshold = sigma * std;
        return samples.filter(function (_, idx) { return Math.abs(residuals[idx] - mean) <= threshold; });
    };
    App.prototype.isBetterModel = function (candidate, current, criterion) {
        if (criterion === 'mae') {
            return candidate.mae < current.mae;
        }
        if (criterion === 'maxerr') {
            return candidate.maxAbsError < current.maxAbsError;
        }
        if (criterion === 'r2') {
            return candidate.r2 > current.r2;
        }
        return candidate.rmse < current.rmse;
    };
    App.prototype.transformInput = function (x, inverse) {
        if (!inverse) {
            return x;
        }
        var eps = 1e-12;
        var sign = x >= 0 ? 1 : -1;
        return sign / (Math.abs(x) + eps);
    };
    App.prototype.predictByModel = function (modelKey, coeffs, x, inverse) {
        var u = this.transformInput(x, inverse);
        if (modelKey === 'linear') {
            return coeffs[0] * u;
        }
        if (modelKey === 'quadratic') {
            return coeffs[0] * u * u + coeffs[1] * u;
        }
        if (modelKey === 'exponential') {
            return coeffs[0] * Math.exp(coeffs[1] * u);
        }
        return 0;
    };
    App.prototype.localFactorAt = function (modelKey, coeffs, x, inverse) {
        if (inverse) {
            var h = Math.max(1e-6, Math.abs(x) * 1e-3);
            var y1 = this.predictByModel(modelKey, coeffs, x + h, true);
            var y0 = this.predictByModel(modelKey, coeffs, x - h, true);
            return (y1 - y0) / (2 * h);
        }
        if (modelKey === 'linear') {
            return coeffs[0];
        }
        if (modelKey === 'exponential') {
            return coeffs[0] * coeffs[1] * Math.exp(coeffs[1] * x);
        }
        return (2 * coeffs[0] * x) + coeffs[1];
    };
    App.prototype.predictCapacityFromRuntime = function (adcRaw, deltaCounts) {
        if (this.runtimeModel) {
            var feature = this.extractSignalFeatureValue(adcRaw, deltaCounts);
            return this.predictByModel(this.runtimeModel.key, this.runtimeModel.coefficients, feature, this.runtimeModel.inverse);
        }
        var fallbackWeightG = deltaCounts * this.calibrationFactor + this.calibrationOffset;
        return this.capacityFromReferenceModel(fallbackWeightG);
    };
    App.prototype.predictWeightFromRuntime = function (adcRaw, deltaCounts) {
        var capPf = this.predictCapacityFromRuntime(adcRaw, deltaCounts);
        return this.weightFromReferenceCapacity(capPf);
    };
    App.prototype.cloneModel = function (model) {
        return {
            key: model.key,
            label: model.label,
            inverse: model.inverse,
            factor: model.factor,
            offset: model.offset,
            coefficients: model.coefficients.slice(),
            usedSamples: model.usedSamples,
            totalSamples: model.totalSamples,
            maxAbsError: model.maxAbsError,
            r2: model.r2,
            referenceDeltaCounts: model.referenceDeltaCounts,
            mae: model.mae,
            rmse: model.rmse
        };
    };
    App.prototype.updateDiagnosticsPlot = function () {
        var _this = this;
        this.connector.getDecimatedDataChannel(0, function (in1) {
            _this.connector.getDecimatedDataChannel(1, function (in2) {
                var out1 = _this.out1Cache;
                var out2 = _this.out2Cache;
                var in1Counts = in1.map(function (v) { return Math.round(v * 819.2); });
                var in2Counts = in2.map(function (v) { return Math.round(v * 819.2); });
                var weightSeries = _this.countsToKg(in1Counts);
                var range = {
                    from: 0,
                    to: _this.sampleIndexToMicroseconds(Math.max(1, in1.length - 1))
                };
                _this.lastPlotRangeUs = range;
                var allSeries = {
                    in1: { label: 'IN1', data: _this.toPlotData(in1), color: '#1f77b4' },
                    in2: { label: 'IN2', data: _this.toPlotData(in2), color: '#ff7f0e' },
                    out1: { label: 'OUT1', data: _this.toPlotData(out1), color: '#2ca02c' },
                    out2: { label: 'OUT2', data: _this.toPlotData(out2), color: '#d62728' },
                    weight: { label: 'Weight (kg)', data: _this.toPlotData(weightSeries), color: '#9467bd' }
                };
                var series = [];
                for (var key in allSeries) {
                    if (_this.curveVisible[key]) {
                        series.push(allSeries[key]);
                    }
                }
                _this.plotBasics.redrawSeries(series, range, function () {
                    requestAnimationFrame(function () { return _this.updateDiagnosticsPlot(); });
                });
                if (in1.length > 0) {
                    _this.adc0ValueEl.innerText = in1Counts[in1Counts.length - 1].toString();
                    _this.adc1ValueEl.innerText = in2Counts[in2Counts.length - 1].toString();
                    _this.rmsIn1El.innerText = _this.computeRms(in1).toFixed(3);
                    _this.rmsIn2El.innerText = _this.computeRms(in2).toFixed(3);
                }
                if (out1.length > 0 && out2.length > 0) {
                    _this.dac0ValueEl.innerText = out1[out1.length - 1].toFixed(3);
                    _this.dac1ValueEl.innerText = out2[out2.length - 1].toFixed(3);
                    _this.rmsOut1El.innerText = _this.computeRms(out1).toFixed(3);
                    _this.rmsOut2El.innerText = _this.computeRms(out2).toFixed(3);
                }
                else {
                    _this.dac0ValueEl.innerText = 'n/a';
                    _this.dac1ValueEl.innerText = 'n/a';
                    _this.rmsOut1El.innerText = 'n/a';
                    _this.rmsOut2El.innerText = 'n/a';
                }
                // Refresh DAC caches independently so plot/UI keeps running even if DAC command lags.
                _this.connector.getDecimatedDacDataChannel(0, function (newOut1) {
                    _this.connector.getDecimatedDacDataChannel(1, function (newOut2) {
                        _this.out1Cache = newOut1;
                        _this.out2Cache = newOut2;
                    });
                });
            });
        });
    };
    App.prototype.updateScaleLoop = function () {
        var _this = this;
        this.connector.getAdcRawData(this.getMlAverageCount(), function (adc0, _) {
            if (_this.mlWorkflowEnabled) {
                var delta = adc0 - _this.tareOffset;
                var weightG = _this.predictWeightFromRuntime(adc0, delta);
                _this.weightEl.innerText = (weightG / 1000).toFixed(3);
                if (_this.mlLiveCapacityEl) {
                    _this.mlLiveCapacityEl.innerText = _this.predictCapacityFromRuntime(adc0, delta).toFixed(4);
                }
                if (_this.mlLiveWeightFromCapacityEl) {
                    _this.mlLiveWeightFromCapacityEl.innerText = weightG.toFixed(3);
                }
            }
            else {
                var weightKg = (adc0 - _this.tareOffset) * _this.calibrationFactor;
                _this.weightEl.innerText = weightKg.toFixed(3);
            }
            setTimeout(function () {
                _this.updateScaleLoop();
            }, 100);
        });
    };
    App.prototype.countsToKg = function (values) {
        var _this = this;
        if (this.mlWorkflowEnabled) {
            return values.map(function (v) { return _this.predictWeightFromRuntime(v, v - _this.tareOffset) / 1000; });
        }
        return values.map(function (v) { return (v - _this.tareOffset) * _this.calibrationFactor; });
    };
    App.prototype.computeRms = function (values) {
        if (values.length === 0) {
            return 0;
        }
        var sum = 0;
        for (var i = 0; i < values.length; i++) {
            sum += values[i] * values[i];
        }
        return Math.sqrt(sum / values.length);
    };
    App.prototype.toPlotData = function (values) {
        var targetPts = 2048;
        var step = Math.max(1, Math.ceil(values.length / targetPts));
        var points = [];
        for (var i = 0; i < values.length; i += step) {
            points.push([this.sampleIndexToMicroseconds(i), values[i]]);
        }
        return points;
    };
    App.prototype.sampleIndexToMicroseconds = function (sampleIndex) {
        return (sampleIndex / this.sampleRateHz) * 1e6;
    };
    App.prototype.parseNumber = function (raw, fallback) {
        var parsed = parseFloat(raw);
        if (isNaN(parsed)) {
            return fallback;
        }
        return parsed;
    };
    return App;
}());
var app = new App(window, document, location.hostname, $('#plot-placeholder'));
var Connector = /** @class */ (function () {
    function Connector(client) {
        this.client = client;
        this.driver = this.client.getDriver('AdcDacBram');
        this.cmds = this.driver.getCmds();
        this.client.send(Command(this.driver.id, this.cmds['set_dac_function'], 0, 1000.0));
        this.channel = 0;
    }
    Connector.prototype.setRange = function (rangeVal) {
    };
    Connector.prototype.setChannel = function (chn) {
        this.channel = chn;
    };
    Connector.prototype.setFunction = function (data, freq) {
        this.client.send(Command(this.driver.id, this.cmds['set_dac_function'], data, freq));
    };
    Connector.prototype.getDecimatedData = function (callback) {
        this.client.readFloat32Vector(Command(this.driver.id, this.cmds['get_decimated_data'], this.channel), function (array) {
            var data = [];
            var range;
            data = new Array(array.length);
            for (var i = 0; i < array.length; i++) {
                data[i] = [i, array[i]];
            }
            range = {
                from: 0,
                to: (array.length - 1)
            };
            callback(data, range);
        });
    };
    Connector.prototype.getDecimatedDataChannel = function (channel, callback) {
        this.client.readFloat32Vector(Command(this.driver.id, this.cmds['get_decimated_data'], channel), function (array) { return callback(Array.prototype.slice.call(array)); });
    };
    Connector.prototype.getDecimatedDacDataChannel = function (channel, callback) {
        this.client.readFloat32Vector(Command(this.driver.id, this.cmds['get_decimated_dac_data'], channel), function (array) { return callback(Array.prototype.slice.call(array)); });
    };
    Connector.prototype.getAdcRawData = function (nAvg, callback) {
        this.client.readTuple(Command(this.driver.id, this.cmds['get_adc_raw_data'], nAvg), 'ii', function (tup) {
            callback(tup[0], tup[1]);
        });
    };
    Connector.prototype.getAdcSnapshot = function (callback) {
        this.client.readUint32Vector(Command(this.driver.id, this.cmds['get_adc_snapshot']), function (array) { return callback(array); });
    };
    Connector.prototype.getDacSnapshot = function (callback) {
        this.client.readUint32Vector(Command(this.driver.id, this.cmds['get_dac_snapshot']), function (array) { return callback(array); });
    };
    return Connector;
}());
// Plot widget
// (c) Koheron
var PlotBasics = /** @class */ (function () {
    function PlotBasics(document, plot_placeholder, n_pts, x_min, x_max, y_min, y_max, driver, rangeFunction, plotTitle) {
        this.plot_placeholder = plot_placeholder;
        this.n_pts = n_pts;
        this.x_min = x_min;
        this.x_max = x_max;
        this.y_min = y_min;
        this.y_max = y_max;
        this.driver = driver;
        this.rangeFunction = rangeFunction;
        this.plotTitle = plotTitle;
        this.isPeakDetection = true;
        this.plotTitleSpan = document.getElementById("plot-title");
        if (this.plotTitle.length > 0) {
            this.plotTitleSpan.textContent = this.plotTitle;
            this.plotTitleSpan.style.display = "block";
        }
        else {
            this.plotTitleSpan.style.display = "none";
        }
        ;
        this.range_x = {};
        this.range_x.from = this.x_min;
        this.range_x.to = this.x_max;
        this.range_y = {};
        this.range_y.from = this.y_min;
        this.range_y.to = this.y_max;
        this.log_y = false;
        this.setPlot(this.range_x.from, this.range_x.to, this.range_y.from, this.range_y.to);
        this.rangeSelect(this.rangeFunction);
        this.dblClick(this.rangeFunction);
        this.onWheel(this.rangeFunction);
        this.showHoverPoint();
        this.showClickPoint();
        this.plotLeave();
        this.reset_range = true;
        this.hoverDatapointSpan = document.getElementById("hover-datapoint");
        this.hoverDatapoint = [];
        this.clickDatapointSpan = document.getElementById("click-datapoint");
        this.clickDatapoint = [];
        this.peakDatapointSpan = document.getElementById("peak-datapoint");
        this.plot_data = [];
        this.LogYaxisFormatter = function (val, axis) { };
        this.initUnitInputs();
        this.initPeakDetection();
    }
    PlotBasics.prototype.setPlot = function (x_min, x_max, y_min, y_max) {
        this.reset_range = false;
        this.options = {
            canvas: true,
            series: {
                shadowSize: 0 // Drawing is faster without shadows
            },
            yaxis: {
                min: y_min,
                max: y_max
            },
            xaxis: {
                min: x_min,
                max: x_max,
                show: true
            },
            grid: {
                margin: {
                    top: 0,
                    left: 0,
                },
                borderColor: "#d5d5d5",
                borderWidth: 1,
                clickable: true,
                hoverable: true,
                autoHighlight: true
            },
            selection: {
                mode: "xy"
            },
            colors: ["#019cd5", "#006400"],
            legend: {
                show: true,
                noColumns: 0,
                labelFormatter: function (label, series) {
                    return "<b style='font-size: 16px; color: #333'>" + label + "\t</b>";
                },
                margin: 0,
                position: "ne",
            }
        };
        // Axis labels are rendered by jquery.flot.axislabels.js.
        this.options.yaxis.axisLabel = "Spannung [V]";
        this.options.xaxis.axisLabel = "Zeit [us]";
    };
    PlotBasics.prototype.rangeSelect = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("plotselected", function (event, ranges) {
            // Clamp the zooming to prevent external zoom
            if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
                ranges.xaxis.to = ranges.xaxis.from + 0.00001;
            }
            if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
                ranges.yaxis.to = ranges.yaxis.from + 0.00001;
            }
            _this.range_x.from = ranges.xaxis.from;
            _this.range_x.to = ranges.xaxis.to;
            _this.range_y.from = ranges.yaxis.from;
            _this.range_y.to = ranges.yaxis.to;
            if (rangeFunction.length > 0) {
                _this.driver[rangeFunction](ranges.xaxis);
            }
            _this.reset_range = true;
        });
    };
    // A double click on the plot resets to full span
    PlotBasics.prototype.dblClick = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("dblclick", function (evt) {
            _this.range_x.from = _this.x_min;
            _this.range_x.to = _this.x_max;
            _this.range_y = {};
            if (rangeFunction.length > 0) {
                _this.driver[rangeFunction](_this.range_x);
            }
            _this.reset_range = true;
        });
    };
    PlotBasics.prototype.setRangeX = function (from, to) {
        this.range_x.from = from;
        this.range_x.to = to;
        this.reset_range = true;
    };
    PlotBasics.prototype.resetView = function (xFrom, xTo) {
        this.range_x.from = (xFrom !== undefined) ? xFrom : this.x_min;
        this.range_x.to = (xTo !== undefined) ? xTo : this.x_max;
        this.range_y.from = this.y_min;
        this.range_y.to = this.y_max;
        this.reset_range = true;
    };
    PlotBasics.prototype.setLogX = function () {
        this.options.xaxis.ticks = [0.001, 0.01, 0.1, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000];
        this.options.xaxis.tickDecimals = 0;
        this.options.xaxis.transform = function (v) { return v > 0 ? Math.log10(v) : null; };
        this.options.xaxis.inverseTransform = function (v) { return v != null ? Math.pow(10, v) : 0.0; };
        this.options.xaxis.tickFormatter = function (val, axis) {
            if (val >= 1E6) {
                return (val / 1E6).toFixed(axis.tickDecimals) + "M";
            }
            else if (val >= 1E3) {
                return (val / 1E3).toFixed(axis.tickDecimals) + "k";
            }
            else {
                return val.toFixed(axis.tickDecimals);
            }
        };
    };
    PlotBasics.prototype.setLogY = function () {
        this.log_y = true;
        this.range_y = {};
        this.reset_range = true;
    };
    PlotBasics.prototype.setLinY = function () {
        this.log_y = false;
        this.range_y = {};
        this.reset_range = true;
    };
    PlotBasics.prototype.updateDatapointSpan = function (datapoint, datapointSpan) {
        var positionX = (this.plot.pointOffset({ x: datapoint[0], y: datapoint[1] })).left;
        var positionY = (this.plot.pointOffset({ x: datapoint[0], y: datapoint[1] })).top;
        datapointSpan.innerHTML = "(" + (datapoint[0].toFixed(2)).toString() + "," + datapoint[1].toFixed(2).toString() + ")";
        if (datapoint[0] < (this.range_x.from + this.range_x.to) / 2) {
            datapointSpan.style.left = (positionX + 5).toString() + "px";
        }
        else {
            datapointSpan.style.left = (positionX - 140).toString() + "px";
        }
        if (datapoint[1] < ((this.range_y.from + this.range_y.to) / 2)) {
            datapointSpan.style.top = (positionY - 50).toString() + "px";
        }
        else {
            datapointSpan.style.top = (positionY + 5).toString() + "px";
        }
    };
    PlotBasics.prototype.redraw = function (plot_data, n_pts, peakDatapoint, ylabel, callback) {
        var _this = this;
        var plt_data = [{ label: ylabel, data: plot_data }];
        if (this.reset_range) {
            if (this.log_y) {
                // /!\ Cannot set ticks lower than 1 /!\
                this.options.yaxis.ticks = [1, 10, 100, 1E3, 1E4, 1E5, 1E6, 1E7, 1E8, 1E9];
                this.options.yaxis.tickDecimals = 0;
                this.options.yaxis.transform = function (v) { return v > 0 ? Math.log10(v) : null; };
                this.options.yaxis.inverseTransform = function (v) { return v != null ? Math.pow(10, v) : 0.0; };
                this.options.yaxis.tickFormatter = this.LogYaxisFormatter;
            }
            else {
                this.options.yaxis = {
                    min: this.range_y.from,
                    max: this.range_y.to
                };
            }
            this.options.xaxis.min = this.range_x.from;
            this.options.xaxis.max = this.range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.range_y.from = this.plot.getAxes().yaxis.min;
            this.range_y.to = this.plot.getAxes().yaxis.max;
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        var localData = this.plot.getData();
        setTimeout(function () { _this.plot.unhighlight(); }, 100);
        if (this.clickDatapoint.length > 0) {
            var i = void 0;
            for (i = 0; i < plot_data.length; i++) {
                if (localData[0]['data'][i][0] > this.clickDatapoint[0]) {
                    break;
                }
            }
            var p1 = localData[0]['data'][i - 1];
            var p2 = localData[0]['data'][i];
            if ((p1 === null) || (p1 === undefined)) {
                this.clickDatapoint[1] = p2[1];
            }
            else if ((p2 === null) || (p2 === undefined)) {
                this.clickDatapoint[1] = p1[1];
            }
            else {
                this.clickDatapoint[1] = p1[1] + (p2[1] - p1[1]) * (this.clickDatapoint[0] - p1[0]) / (p2[0] - p1[0]);
            }
            if (this.range_x.from < this.clickDatapoint[0] && this.clickDatapoint[0] < this.range_x.to
                && this.range_y.from < this.clickDatapoint[1] && this.clickDatapoint[1] < this.range_y.to) {
                this.updateDatapointSpan(this.clickDatapoint, this.clickDatapointSpan);
                this.clickDatapointSpan.style.display = "inline-block";
                this.plot.highlight(localData[0], this.clickDatapoint);
            }
            else {
                this.clickDatapointSpan.style.display = "none";
            }
        }
        if (this.isPeakDetection && peakDatapoint.length > 0) {
            for (var i = 0; i < plot_data.length; i++) {
                if (peakDatapoint[1] < plot_data[i][1]) {
                    peakDatapoint[0] = plot_data[i][0];
                    peakDatapoint[1] = plot_data[i][1];
                }
            }
            this.plot.unhighlight(localData[0], peakDatapoint);
            if (this.range_x.from < peakDatapoint[0] && peakDatapoint[0] < this.range_x.to
                && this.range_y.from < peakDatapoint[1] && peakDatapoint[1] < this.range_y.to) {
                this.updateDatapointSpan(peakDatapoint, this.peakDatapointSpan);
                this.plot.highlight(localData[0], peakDatapoint);
                this.peakDatapointSpan.style.display = "inline-block";
            }
            else {
                this.plot.unhighlight(localData[0], peakDatapoint);
                this.peakDatapointSpan.style.display = "none";
            }
        }
        else {
            this.plot.unhighlight(localData[0], peakDatapoint);
            this.peakDatapointSpan.style.display = "none";
        }
        callback();
    };
    PlotBasics.prototype.redrawRange = function (data, range_x, ylabel, callback) {
        var plt_data = [{ label: ylabel, data: data }];
        if (data.length == 0) {
            callback();
            return;
        }
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.redrawTwoChannels = function (ch0, ch1, range_x, label1, label2, is_channel_1, is_channel_2, callback) {
        if (ch0.length === 0 || ch1.length === 0) {
            callback();
            return;
        }
        var plotCh0 = [];
        var plotCh1 = [];
        if (is_channel_1 && is_channel_2) {
            plotCh0 = ch0;
            plotCh1 = ch1;
            // plotData = [ch0, ch1];
        }
        else if (is_channel_1 && !is_channel_2) {
            plotCh0 = ch0;
            plotCh1 = [];
        }
        else if (!is_channel_1 && is_channel_2) {
            plotCh0 = [];
            plotCh1 = ch1;
        }
        else {
            plotCh0 = [];
            plotCh1 = [];
        }
        var plt_data = [{ label: label1, data: plotCh0 }, { label: label2, data: plotCh1 }];
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.redrawSeries = function (series, range_x, callback) {
        if (series.length === 0) {
            if (this.plot) {
                this.plot.setData([]);
                this.plot.draw();
            }
            callback();
            return;
        }
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, series, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(series);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.onWheel = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("wheel", function (evt) {
            var delta = evt.originalEvent.deltaX
                + evt.originalEvent.deltaY;
            delta /= Math.abs(delta);
            var zoomRatio = 0.2;
            if (evt.originalEvent.shiftKey) { // Zoom Y
                var positionY = evt.originalEvent.pageY - _this.plot.offset().top;
                var y0 = _this.plot.getAxes().yaxis.c2p(positionY);
                _this.range_y = {
                    from: y0 - (1 + zoomRatio * delta) * (y0 - _this.plot.getAxes().yaxis.min),
                    to: y0 - (1 + zoomRatio * delta) * (y0 - _this.plot.getAxes().yaxis.max)
                };
                _this.reset_range = true;
                return false;
            }
            else if (evt.originalEvent.altKey) { // Zoom X
                var positionX = evt.originalEvent.pageX - _this.plot.offset().left;
                var x0 = _this.plot.getAxes().xaxis.c2p(positionX);
                if (x0 < 0 || x0 > _this.x_max) {
                    return;
                }
                _this.range_x = {
                    from: Math.max(x0 - (1 + zoomRatio * delta) * (x0 - _this.plot.getAxes().xaxis.min), 0),
                    to: Math.min(x0 - (1 + zoomRatio * delta) * (x0 - _this.plot.getAxes().xaxis.max), _this.x_max)
                };
                if (rangeFunction.length > 0) {
                    _this.driver[rangeFunction](_this.range_x);
                }
                _this.reset_range = true;
                return false;
            }
            return true;
        });
    };
    PlotBasics.prototype.initUnitInputs = function () {
        var _this = this;
        var unitInputs = document.getElementsByClassName("unit-input");
        for (var i = 0; i < unitInputs.length; i++) {
            unitInputs[i].addEventListener('change', function (event) {
                _this.reset_range = true;
            });
        }
    };
    PlotBasics.prototype.initPeakDetection = function () {
        var _this = this;
        var peakInputs = document.getElementsByClassName("peak-input");
        for (var i = 0; i < peakInputs.length; i++) {
            peakInputs[i].addEventListener('change', function (event) {
                if (_this.isPeakDetection) {
                    _this.isPeakDetection = false;
                }
                else {
                    _this.isPeakDetection = true;
                }
            });
        }
    };
    PlotBasics.prototype.showHoverPoint = function () {
        var _this = this;
        this.plot_placeholder.bind("plothover", function (event, pos, item) {
            if (item) {
                _this.hoverDatapoint[0] = item.datapoint[0];
                _this.hoverDatapoint[1] = item.datapoint[1];
                _this.hoverDatapointSpan.style.display = "inline-block";
                _this.updateDatapointSpan(_this.hoverDatapoint, _this.hoverDatapointSpan);
            }
            else {
                _this.hoverDatapointSpan.style.display = "none";
            }
        });
    };
    PlotBasics.prototype.showClickPoint = function () {
        var _this = this;
        this.plot_placeholder.bind("plotclick", function (event, pos, item) {
            if (item) {
                _this.clickDatapoint[0] = item.datapoint[0];
                _this.clickDatapoint[1] = item.datapoint[1];
                _this.clickDatapointSpan.style.display = "inline-block";
                _this.updateDatapointSpan(_this.clickDatapoint, _this.clickDatapointSpan);
                _this.plot.unhighlight();
                _this.plot.highlight(item.series, _this.clickDatapoint);
            }
        });
    };
    PlotBasics.prototype.plotLeave = function () {
        var _this = this;
        this.plot_placeholder.bind("mouseleave", function (event, pos, item) {
            _this.hoverDatapointSpan.style.display = "none";
        });
    };
    return PlotBasics;
}());
